// Copyright (c) 2006-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//

#include <eikstart.h> 

#include "ControlFrameworkApplication.h"
#include "ControlFrameworkGlobals.h"
#include "ControlFrameworkDocument.h"


//Standard DLL entry point function.
TInt E32Main()
	{
	return EikStart::RunApplication( CControlFrameworkApplication::NewApplication );
	}

CControlFrameworkApplication::CControlFrameworkApplication()
	{
	}


CControlFrameworkApplication::~CControlFrameworkApplication()
	{
	}

TUid CControlFrameworkApplication::AppDllUid() const
	{
	return KUidControlFrameworkAppUid;
	}


//Creates and returns an instance of the CApaApplication-derived class.
CApaApplication* CControlFrameworkApplication::NewApplication()
	{
	return new CControlFrameworkApplication();
	}

CApaDocument* CControlFrameworkApplication::CreateDocumentL()
	{
	return CControlFrameworkDocument::NewL(*this);
	}
