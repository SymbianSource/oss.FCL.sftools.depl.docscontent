// Copyright (c) 2005-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//



#ifndef __APPHOLDER_H
#define __APPHOLDER_H

#include <coeccntx.h>

#include <eikenv.h>
#include <eikappui.h>
#include <eikapp.h>
#include <eikdoc.h>
#include <eikmenup.h>

#include <eikon.hrh>


const TUid KUidAppholder = { 0xE8000057 };

class CWsClient;

//
// CAppholderAppUi
//

class CAppholderAppUi : public CEikAppUi
	{
public:
	void ConstructL();
	~CAppholderAppUi();
private: // from CEikAppUi
	void HandleCommandL(TInt aCommand);
private:
	CWsClient* iClient;
	};


//
// CAppholderDocument
//

class CAppholderDocument : public CEikDocument
	{
public:
	// construct/destruct
	CAppholderDocument(CEikApplication& aApp);
	~CAppholderDocument();
private: // from CEikDocument
	CEikAppUi* CreateAppUiL();
	};


//
// CAppholderApplication
//

class CAppholderApplication : public CEikApplication
	{
private: // from CApaApplication
	CApaDocument* CreateDocumentL();
	TUid AppDllUid() const;
	};

#endif
