// Copyright (c) 2005-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//

#ifndef __SMSEXAMPLE_H__
#define __SMSEXAMPLE_H__
 
#include <txtrich.h>
#include <txtfmlyr.h>
#include <mtclreg.h>
#include <msventry.h>
#include <smuthdr.h>
#include <e32cons.h>

/**
 * CExampleActive is used for asynchronous requests.
 */
class CExampleActive : public CActive
    {
public:
    CExampleActive();
   ~CExampleActive();
    void StartL();
protected:
    void DoCancel();
    void RunL();
    };

/**
 * CSessionObserver is just declared to make use of it while creating a session.
 */
class CSessionObserver : public MMsvSessionObserver
    {
    public:
        virtual void HandleSessionEventL(TMsvSessionEvent /*aEvent*/, TAny* /*aArg1*/, TAny* /*aArg2*/, TAny* /*aArg3*/){};
    };

/**
 * CSmsExample is used to create an SMS service, create an SMS message, send an SMS message, display SMS messages.
 */    
class CSmsExample : public CBase
    {
public:
    CSmsExample();
    static CSmsExample* NewLC();
    ~CSmsExample();
    void SendReceiveSmsL();
private:
    void ConstructL();
    void CreateSmsServiceL();    // create an SMS Service
    void ServiceIdL(TUid aMtm, TMsvId& aFirstId, CMsvEntrySelection* aServiceIds = NULL);
    void CreateMessageL(); // create an SMS message
    void DeleteMessagesL(TMsvId aFolder);
    void SetRecipientsL(CSmsHeader& aHeader);
    void DisplayMessagesL(TMsvId aId);
    void SendMessageL(); // send a message
    void ReceiveMessagesL(); // read the messages in the inbox
    
    TBuf<220> GetUserInput();
public:
    CMsvSession* iSession;
    CSessionObserver* iSessionObserver;
    CMsvEntry* iMsvEntry;
    CMsvOperation* iOperation;
    TMsvId iMessageId;
    CMsvServerEntry*        iServerEntry;
    CExampleActive* iActive;
    TMsvId              iSmsServiceId;
    CRichText*          iRichText;
    CSmsSettings*       iServiceSettings;
    CSmsNumber* ircpt;
    CParaFormatLayer*   iParaFormat;
    CCharFormatLayer*   iCharFormat;
    CConsoleBase* iConsole;
    }; 
#endif  // __SMSEXAMPLE_H__
