// Copyright (c) 2005-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//

#include "smsexample.h"
#include <msvuids.h>
#include <csmsaccount.h>

/**
 * CExampleActive class is used to make any asynchornous requests
 */
CExampleActive::CExampleActive()
: CActive(0)
    {
    CActiveScheduler::Add(this);
    }
/**
 * CExampleActive destructor cancels any pending requests
 */
CExampleActive::~CExampleActive()
    {
    Cancel();
    }

/**
 * CExampleActive DoCancel API is used to cancel the asynchronous request issued.
 */
void CExampleActive::DoCancel()
    {
    TRequestStatus* s=&iStatus;
    User::RequestComplete(s, KErrCancel);
    }

/**
 * CExampleActive StartL Api is used to call SetActive
 */
void CExampleActive::StartL()
    {
    SetActive();
    }

/**
 * RunL gets called as soon as the asynchronous request finishes.
 */
void CExampleActive::RunL() 
    {
    CActiveScheduler::Stop();
    }

/**
 * NewLC is used to create the instance of CSmsExample class using 2 phase construction.
 */
CSmsExample* CSmsExample::NewLC()
    {
    CSmsExample* self=new(ELeave)CSmsExample();
    CleanupStack::PushL(self);
    self->ConstructL();
    return self;
    }

/**
 * Construct all the required member data of the classes using the ConstructL function.
 */
void CSmsExample::ConstructL()
	{
	iParaFormat = CParaFormatLayer::NewL();
	iCharFormat = CCharFormatLayer::NewL();
	iRichText = CRichText::NewL(iParaFormat, iCharFormat);
	}  

/**
 * Initialise all the member data.
 */
CSmsExample::CSmsExample()
    {
    iSmsServiceId = KMsvNullIndexEntryId;
    }

/**
 * This function deletes all the member data and will free the memory used by them,as soon as you exit the application.
 */
CSmsExample::~CSmsExample()
    {
    delete iServiceSettings;
    delete iRichText;
    delete iCharFormat;
    delete iParaFormat;
    delete iMsvEntry;
    delete iSessionObserver;
    delete iSession;
    delete iOperation;
    delete iActive;
    delete iServerEntry;
    delete ircpt;
    delete iConsole;
    }
/**
Takes input from the console and returns the TBuf value. 
*/
TBuf<220> CSmsExample::GetUserInput()
    {
    TBuf<220> buf;
    TKeyCode ch = iConsole->Getch();
    while(ch != EKeyEnter)
        {
        _LIT(KChar, "%c");
        iConsole->Printf(KChar,ch);
        if(ch!= EKeyBackspace)
            {
            buf.Append(ch);
            }
        ch=iConsole->Getch();               
        }
    return buf;
    }

/**
 * ServiceIdL Api is used to get the ServiceID for the SMS type messages.
 */
void CSmsExample::ServiceIdL(TUid aMtm, TMsvId& aFirstId, CMsvEntrySelection* aServiceIds)
    {
    //Returns the Service IDs of MTM aMtm
    TMsvSelectionOrdering ordering;  
    iSessionObserver = new (ELeave) CSessionObserver();
    iSession = CMsvSession::OpenSyncL(*iSessionObserver); 
    iMsvEntry = CMsvEntry::NewL(*iSession, KMsvGlobalInBoxIndexEntryIdValue,ordering);
    aFirstId = KMsvNullIndexEntryId;
    iMsvEntry->SetEntryL(KMsvRootIndexEntryId);

    TMsvSelectionOrdering order;
    order.SetShowInvisibleEntries(ETrue);
    iMsvEntry->SetSortTypeL(order);
    
    //Get the children on the Root Index Entry
    CMsvEntrySelection* selection = iMsvEntry->ChildrenWithTypeL(KUidMsvServiceEntry);
    CleanupStack::PushL(selection);
    
    TInt count = selection->Count();
    
    //Find an entry for MTM aMtm
    for (TInt curChild = 0; curChild < count && (aFirstId == KMsvNullIndexEntryId || aServiceIds); curChild++)
        {
        iMsvEntry->SetEntryL(selection->At(curChild));
    
        if (iMsvEntry->Entry().iMtm == aMtm)
            {
            TMsvId id = iMsvEntry->Entry().Id();
    
            if (aFirstId == KMsvNullIndexEntryId)
                {
                aFirstId = id;
                }
    
            if (aServiceIds)
                {
                aServiceIds->AppendL(id);
                }
            }
        }

    //Leave if no Service Entry found for MTM aMtm
    if (aFirstId == KMsvNullIndexEntryId)
        {
        CleanupStack::PopAndDestroy(); //selection
        User::Leave(KErrNotFound);
        }
    CleanupStack::PopAndDestroy(selection); //selection
    }

/**
 * Create the SMS service. Create an SMS account for yourself and give the details of the service centre for your 
 * service settings.
 */
void  CSmsExample::CreateSmsServiceL()
    {
    // create service in root
    TInt err = KErrNone;
    iSmsServiceId = 0;
    TRAP(err, ServiceIdL(KUidMsgTypeSMS, iSmsServiceId));
    TMsvSelectionOrdering ordering;   
    // service settings.

    CSmsAccount* account = CSmsAccount::NewLC();
    iServiceSettings = CSmsSettings::NewL();
    account->LoadSettingsL(*iServiceSettings);
                                
    // Remove the default service centres from the service settings
    TInt count = iServiceSettings->ServiceCenterCount();
    while( count-- )
        {
        iServiceSettings->RemoveServiceCenter(count);
        }
    
    _LIT(KTxtServiceCenter,"Add Service Center\n");
    _LIT(KTxtServiceCenterLimit,"Service Center Name and Number should not be more than 15 characters\n");
    _LIT(KTxtServiceCenterName,"Name is : ");
    _LIT(KTxtServiceCenterNumber,"\nNumber : ");
    iConsole->Printf(KTxtServiceCenterLimit);
    iConsole->Printf(KTxtServiceCenter);
    iConsole->Printf(KTxtServiceCenterName);  
    TBuf<15> name = GetUserInput();
    iConsole->Printf(KTxtServiceCenterNumber);
    TBuf<15> number = GetUserInput();
    // Add the Vodafone service centre - store the settings.
    iServiceSettings->AddServiceCenterL(name, number);

    // Set delivery options - do matching and make reports visible. 
    iServiceSettings->SetDeliveryReport(ETrue);
    iServiceSettings->SetStatusReportHandling(CSmsSettings::EMoveReportToInboxVisibleAndMatch);
    account->SaveSettingsL(*iServiceSettings);
    
    //Get the service centre information.
    CSmsServiceCenter* serviceCenter = CSmsServiceCenter::NewL(iServiceSettings->GetServiceCenter(0));
    TPtrC name1 = serviceCenter->Name(); //Name of the service center
    TPtrC number1 = serviceCenter->Address(); //Address details of the service center
    _LIT(KTxtDisplayServiceCenterDetails,"\nService centre name is %S \n Number is %S \n");
    iConsole->Printf(KTxtDisplayServiceCenterDetails,&name1,&number1);
    CleanupStack::PopAndDestroy(account);
    
    //used for asynchronous calls
    iActive=new(ELeave) CExampleActive;
    delete serviceCenter;
    }

/**
 * Set the receipent number
 */
void CSmsExample::SetRecipientsL(CSmsHeader& aHeader)
    {
    _LIT(KTxtSetReceipent,"\nGive the receipent number\n");
    iConsole->Printf(KTxtSetReceipent);   
    CSmsNumber* ircpt = CSmsNumber::NewL();
    _LIT(KTxtReceipentNumberLimit,"Receipent Number should not be more than 15 characters :\n");
    iConsole->Printf(KTxtReceipentNumberLimit);
    TBuf<15> receipent = GetUserInput();
    ircpt->SetAddressL(receipent);
    aHeader.Recipients().AppendL(ircpt);
    }

/**
 * Create a SMS Message.
 */
void CSmsExample::CreateMessageL()
    {  
    _LIT(KTxtCreateMessage,"Creating message...\n");
    iConsole->Printf(KTxtCreateMessage);
    TMsvEntry entry;
    entry.SetVisible(ETrue); 
    entry.SetInPreparation(ETrue); 
    entry.iServiceId = iSmsServiceId; //iSmsServiceId
    entry.iType = KUidMsvMessageEntry; 
    entry.iMtm = KUidMsgTypeSMS; 
    entry.iDate.HomeTime(); 
    entry.iSize = 0; 
    entry.iDescription.Set(KNullDesC); 
    entry.iDetails.Set(KNullDesC); 
    entry.SetSendingState(KMsvSendStateScheduled);
   
    // Create the SMS header object...
    CSmsHeader* header = CSmsHeader::NewL(CSmsPDU::ESmsSubmit, *iRichText);

    // Set the body text...
    iRichText->Reset();
    _LIT(KMessageData, "Write the Message description\n");
    iConsole->Printf(KMessageData);
    
    _LIT(KTxtMessageLimit,"Total number of characters in the message should not be more than 220 :\n");
    iConsole->Printf(KTxtMessageLimit);
    TBuf<220> message = GetUserInput();
    iRichText->InsertL(0, message);
    
    // Copy the message settings...
    header->SetSmsSettingsL(*iServiceSettings); 
    
    // Set the service centre
    TInt defaultIndex = iServiceSettings->DefaultServiceCenter();
    header->SetServiceCenterAddressL(iServiceSettings->GetServiceCenter(defaultIndex).Address());

    // Set recipient - ask derived class
    SetRecipientsL(*header);
    
    // Update entry description and details...
    CArrayPtrFlat<CSmsNumber>& recipient = header->Recipients();
    entry.iDetails.Set(recipient[0]->Address());
    entry.iDescription.Set(iRichText->Read(0, iServiceSettings->DescriptionLength()));
    entry.SetInPreparation(EFalse);
    
    // Create the entry - set context to the global outbox.
    iMsvEntry->SetEntryL(KMsvGlobalOutBoxIndexEntryId);
    iMsvEntry->CreateL(entry);
    
    // Create new store and save header information 
    iMsvEntry->SetEntryL(entry.Id()); 
    CMsvStore* store = iMsvEntry->EditStoreL(); 
    CleanupStack::PushL(store); 
    header->StoreL(*store);
    store->StoreBodyTextL(*iRichText);
    store->CommitL(); 
    delete header;
    CleanupStack::PopAndDestroy(store); 
    iMessageId = entry.Id();
    }

/**
 * Display the messages in your INBOX,Outbox,Sent etc.
 */
void CSmsExample::DisplayMessagesL(TMsvId aFolder)
    {
    iMsvEntry->SetEntryL(aFolder);
    CMsvEntrySelection* sel = iMsvEntry->ChildrenL();
    TInt count = sel->Count();
    for(TInt i=0;i<count;i++)
          {
          iMsvEntry->SetEntryL(sel->At(i));
          TMsvEntry sel = iMsvEntry->Entry();
          _LIT(KTxtMessageDescription,"\nMessage Description is : %S\n");
          iConsole->Printf(KTxtMessageDescription,&sel.iDescription);
          _LIT(KTxtMessageDetails,"\nMessage Details are :  %S\n");
          iConsole->Printf(KTxtMessageDetails,&sel.iDetails);
          }
    delete sel;
    } 

/**
 * Send the SMS message to the receipent.
 * 
 * Note: Modem bearer setting should be done and the the receipent phone should be switched ON for a message to
 * be successfully sent in a real scenario. We are not doing any bearer settings here, We are just demonstrating the
 * use cases and the APIs used to send a SMS.
 */    
void CSmsExample::SendMessageL()
    {
    _LIT(KTxtSendingMessage,"\nSending message...\n");
    iConsole->Printf(KTxtSendingMessage);
    delete iOperation;
    iOperation = NULL;
    CMsvEntrySelection* sel = new (ELeave) CMsvEntrySelection();
    CleanupStack::PushL(sel);
    sel->AppendL(iMessageId);
    iMsvEntry->SetEntryL(KMsvGlobalOutBoxIndexEntryId);
    /**
     * In a real scenario with the necessary bearer settings done,Second argument will be 
     * KMsvGlobalOutBoxIndexEntryId. The esock layer sends the messages from outbox to the receipent mentioned in the
     * Message header, It re-schedules the sending of messages if the first attempt fails.
     */
    iOperation = iMsvEntry->CopyL(*sel, KMsvSentEntryId,iActive->iStatus);  
    iActive->StartL();
    CActiveScheduler::Start();  
    CleanupStack::PopAndDestroy(sel);
    }

/**
 * Delete the messages in your INBOX,Outbox,Sent etc.
 */
void CSmsExample::DeleteMessagesL(TMsvId aFolder)
    {
    iMsvEntry->SetEntryL(aFolder);
    CMsvEntrySelection* sel = iMsvEntry->ChildrenL();
    TInt count = sel->Count();
    while (count--)
        {
        iMsvEntry->DeleteL(sel->At(count));
        }
   delete sel; //delete selection
    }

/**
 * Receiving a SMS Message.
 */    
void CSmsExample::ReceiveMessagesL()
    {
    _LIT(KTxtReceivingMessage,"Receiving message...\n");   
    /*
     * Messaging framework receives the messages from the Watchers. The watchers place them in the
     * INBOX. For this example, as the network simulation is not present, we are moving the message from 
     * OutBox to INBOX and reading it. 
     */
    iConsole->Printf(KTxtReceivingMessage);
    delete iOperation;
    iOperation = NULL;
    CMsvEntrySelection* sel = new (ELeave) CMsvEntrySelection();
    CleanupStack::PushL(sel);
    sel->AppendL(iMessageId);
    iMsvEntry->SetEntryL(KMsvGlobalOutBoxIndexEntryId);
    iOperation = iMsvEntry->CopyL(*sel, KMsvGlobalInBoxIndexEntryId,iActive->iStatus);  
    iActive->StartL();
    CActiveScheduler::Start();  
    DisplayMessagesL(KMsvGlobalInBoxIndexEntryId);
    CleanupStack::PopAndDestroy(sel);
    }

/**
 * Create an SMS service, create a SMS message, send it and read it from the sent items.
 */
void CSmsExample::SendReceiveSmsL()
    {   
    // Create and install the active scheduler
    CActiveScheduler* scheduler= new (ELeave) CActiveScheduler();
    CleanupStack::PushL(scheduler);
    CActiveScheduler::Install(scheduler); 
    _LIT(KTxtExampleCode,"SMS Example \n");
    iConsole= Console::NewL(KTxtExampleCode,TSize(KConsFullScreen,KConsFullScreen));
    iConsole->Printf(KTxtExampleCode);
    _LIT(KTxtEsc,"Press ESC to exit the example\n");
    _LIT(KTxtPressAnyKey,"Press any key to continue\n");
    _LIT(KFormat,"************************************************************************************\n");   
    _LIT(KTxtSmsExampleInfo1,"Create an SMS service by giving the service center details like name and number.\n \
            \nCreate a SMS message, with message details and recipient number...\n \
            \nOnce you have added a service center, you will use this to send messages.\n");    
    _LIT(KTxtSmsExampleInfo2,"\nAll options will allow you to create a service ID if required. \n \
         The send and receive options allow you to create a message if required.\n");
    _LIT(KTxtSmsExampleInfo3,"\nSo the options do not need to be selected sequentially.\n");  
    iConsole->Printf(KFormat);
    iConsole->Printf(KTxtSmsExampleInfo1);
    iConsole->Printf(KTxtSmsExampleInfo2);
    iConsole->Printf(KTxtSmsExampleInfo3);
    iConsole->Printf(KFormat);
    iConsole->Printf(KTxtPressAnyKey);
    iConsole->Printf(KTxtEsc);
    TBool serviceCreated = EFalse;
    TBool messageCreated = EFalse;
    TBool messageSent = EFalse;
    TChar tchar = iConsole->Getch();
    iConsole->ClearScreen();
    //make a choice
    while (tchar != EKeyEscape)
        {
        _LIT(KCreateSmsService,"Option 1 : Create an SMS Service \n");
        _LIT(KCreateSms,"Option 2 : Create an SMS message \n");
        _LIT(KCreateSendSMS,"Option 3 : Send the message \n");
        _LIT(KCreateReceiveSMS,"Option 4 : Receive the message \n");
        _LIT(KTxtOptionNotSupported," Option is not supported \n");
        iConsole->Printf(KFormat);
        iConsole->Printf(KCreateSmsService);
        iConsole->Printf(KCreateSms);
        iConsole->Printf(KCreateSendSMS);
        iConsole->Printf(KCreateReceiveSMS);
        iConsole->Printf(KFormat);
        TChar option = iConsole->Getch(); 
        switch(option)
            {
            case '1':
                {
                if(!serviceCreated)
                    {
                    CreateSmsServiceL();
                    serviceCreated = ETrue;
                    }
                else
                    {
                    _LIT(KTxtServiceCenterAlreadyExists,"Service center already exists\n");
                    iConsole->Printf(KTxtServiceCenterAlreadyExists);
                    }
                break;
                }
            case '2':
                {
                if(!serviceCreated)
                    {
                    serviceCreated = ETrue;
                    CreateSmsServiceL();
                    }
                messageCreated = ETrue;
                DeleteMessagesL(KMsvGlobalOutBoxIndexEntryId);
                DeleteMessagesL(KMsvSentEntryId);
                CreateMessageL();
                DisplayMessagesL(KMsvGlobalOutBoxIndexEntryId);
                break;
                }
            case '3':
                {
                if(!serviceCreated)
                    {
                    serviceCreated = ETrue;
                    CreateSmsServiceL();
                    }
                if(!messageCreated)
                    {
                    messageCreated = ETrue;
                    DeleteMessagesL(KMsvGlobalOutBoxIndexEntryId);
                    DeleteMessagesL(KMsvSentEntryId);         
                    CreateMessageL();
                    DisplayMessagesL(KMsvGlobalOutBoxIndexEntryId);
                    }
                messageSent = ETrue;
                SendMessageL();
                DisplayMessagesL(KMsvSentEntryId);
                break;
                }
            case '4':
                {
                if(!serviceCreated)
                    {
                    serviceCreated = ETrue;
                    CreateSmsServiceL();
                    }
                if(!messageCreated)
                    {
                    messageCreated = ETrue;
                    DeleteMessagesL(KMsvGlobalOutBoxIndexEntryId);
                    DeleteMessagesL(KMsvSentEntryId);         
                    CreateMessageL();
                    DisplayMessagesL(KMsvGlobalOutBoxIndexEntryId);
                    }
                if(!messageSent)
                    {
                    messageSent = ETrue;
                    SendMessageL();
                    DisplayMessagesL(KMsvSentEntryId);
                    }
                DeleteMessagesL(KMsvGlobalInBoxIndexEntryId);
                ReceiveMessagesL();
                break;
                }
            default:
                {
                iConsole->Printf(KTxtOptionNotSupported);
                break;
                }
            }
        iConsole->Printf(KTxtPressAnyKey);
        iConsole->Printf(KTxtEsc);
        tchar = iConsole->Getch();
        }
    CleanupStack::PopAndDestroy(scheduler);
    }

/**
 * Initialise and call example code under cleanup stack.
 */
void callExampleL() 
    {
    CSmsExample* sendreceive = CSmsExample::NewLC();
    sendreceive->SendReceiveSmsL();
    CleanupStack::PopAndDestroy(sendreceive);
    }

extern TInt E32Main()
    {
    __UHEAP_MARK;
    CTrapCleanup* cleanup=CTrapCleanup::New(); // Create clean-up stack.
    if(cleanup!=NULL)
        {
        TRAPD (error,callExampleL());
        _LIT(KTxtSmsExample,"SMS Example");
        __ASSERT_ALWAYS(!error,User::Panic(KTxtSmsExample,error));
        }
    delete cleanup; // Delete clean-up stack.
    __UHEAP_MARKEND;
    return KErrNone;
    }
