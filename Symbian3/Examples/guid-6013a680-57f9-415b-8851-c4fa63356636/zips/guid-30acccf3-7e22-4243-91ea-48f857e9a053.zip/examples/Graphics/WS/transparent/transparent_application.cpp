// Copyright (c) 2007-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//

#include "transparent.h"
const TUid KUidTransparent = { 0xE80000AF };

/**
Called by the UI framework to get the application's UID
*/
TUid CTransparentApplication::AppDllUid() const
	{
	return KUidTransparent ;
	}

/**
Called by the UI framework at application start-up to
create an instance of the document class.
*/
CApaDocument* CTransparentApplication::CreateDocumentL()
	{
	return new (ELeave) CTransparentDocument(*this);
	}
