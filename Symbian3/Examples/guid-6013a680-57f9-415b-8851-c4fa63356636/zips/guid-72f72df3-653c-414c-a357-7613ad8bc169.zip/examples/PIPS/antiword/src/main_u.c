/*
 * main_u.c
 *
 * Released under GPL
 *
 * Copyright (C) 1998-2004 A.J. van Os
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Description:
 * The main program of 'antiword' (Unix version)
 */
#ifdef SYMBIAN
//GCCE header
//#include <staticlibinit_gcce.h>
#include <string.h>
#endif /*SYMBIAN*/

#include <stdio.h>
#include <stdlib.h>
#if defined(__dos)
#include <fcntl.h>
#include <io.h>
#endif /* __dos */
#if defined(__CYGWIN__) || defined(__CYGMING__)
#  ifdef X_LOCALE
#    include <X11/Xlocale.h>
#  else
#    include <locale.h>
#  endif
#else
#include <locale.h>
#endif /* __CYGWIN__ || __CYGMING__ */
#if defined(N_PLAT_NLM)
#if !defined(_VA_LIST)
#include "NW-only/nw_os.h"
#endif /* !_VA_LIST */
#include "getopt.h"
#endif /* N_PLAT_NLM */
#include "version.h"
#include "antiword.h"
#include <unistd.h> 

/* The name of this program */
static const char	*szTask = NULL;


static void
vUsage(void)
{
	fprintf(stderr, "\tName: %s\n", szTask);
	fprintf(stderr, "\tPurpose: "PURPOSESTRING"\n");
	fprintf(stderr, "\tAuthor: "AUTHORSTRING"\n");
	fprintf(stderr, "\tVersion: "VERSIONSTRING);
#if defined(__dos)
	fprintf(stderr, VERSIONSTRING2);
#endif /* __dos */
	fprintf(stderr, "\n");
	fprintf(stderr, "\tStatus: "STATUSSTRING"\n");
	fprintf(stderr,
		"\tUsage: %s [switches] wordfile1 [wordfile2 ...]\n", szTask);
	fprintf(stderr,
		"\tSwitches: [-f|-t|-a papersize|-p papersize|-x dtd]"
		"[-m mapping][-w #][-i #][-Ls]\n");
	fprintf(stderr, "\t-f formatted text output\n");
	fprintf(stderr, "\t-t text output (default)\n");
	fprintf(stderr, "\t-a <paper size name> Adobe PDF output\n");
	fprintf(stderr, "\t-p <paper size name> PostScript output\n");
	fprintf(stderr, "\t   paper size like: a4, letter or legal\n");
	fprintf(stderr, "\t-x <dtd> XML output\n");
	fprintf(stderr, "\t   like: db (DocBook)\n");
	fprintf(stderr, "\t-m <mapping> character mapping file\n");
	fprintf(stderr, "\t-w <width> in characters of text output\n");
	fprintf(stderr, "\t-i <level> image level (PostScript only)\n");
	fprintf(stderr, "\t-L use landscape mode (PostScript only)\n");
	fprintf(stderr, "\t-r Show removed text\n");
	fprintf(stderr, "\t-s Show hidden (by Word) text\n");
} /* end of vUsage */

/*
 * pStdin2TmpFile - save stdin in a temporary file
 *
 * returns: the pointer to the temporary file or NULL
 */
static FILE *
pStdin2TmpFile(long *lFilesize)
{
	FILE	*pTmpFile;
	size_t	tSize;
	BOOL	bFailure;
	UCHAR	aucBytes[BUFSIZ];

	DBG_MSG("pStdin2TmpFile");

	fail(lFilesize == NULL);

	/* Open the temporary file */
	pTmpFile = tmpfile();
	if (pTmpFile == NULL) {
		return NULL;
	}

#if defined(__dos)
	/* Stdin must be read as a binary stream */
	setmode(fileno(stdin), O_BINARY);
#endif /* __dos */

	/* Copy stdin to the temporary file */
	*lFilesize = 0;
	bFailure = TRUE;
	for (;;) {
		tSize = fread(aucBytes, 1, sizeof(aucBytes), stdin);
		if (tSize == 0) {
			bFailure = feof(stdin) == 0;
			break;
		}
		if (fwrite(aucBytes, 1, tSize, pTmpFile) != tSize) {
			bFailure = TRUE;
			break;
		}
		*lFilesize += (long)tSize;
	}

#if defined(__dos)
	/* Switch stdin back to a text stream */
	setmode(fileno(stdin), O_TEXT);
#endif /* __dos */

	/* Deal with the result of the copy action */
	if (bFailure) {
		*lFilesize = 0;
		(void)fclose(pTmpFile);
		return NULL;
	}
	rewind(pTmpFile);
	return pTmpFile;
} /* end of pStdin2TmpFile */

/*
 * bProcessFile - process a single file
 *
 * returns: TRUE when the given file is a supported Word file, otherwise FALSE
 */
#ifndef SYMBIAN 
static BOOL
bProcessFile(const char *szFilename )
#else
static BOOL
bProcessFile(const char *szFilename, FILE *ofp)
#endif /*SYMBIAN*/
{
	FILE		*pFile;
	diagram_type	*pDiag;
	long		lFilesize;
	int		iWordVersion;
	BOOL		bResult;

	fail(szFilename == NULL || szFilename[0] == '\0');

	DBG_MSG(szFilename);

	if (szFilename[0] == '-' && szFilename[1] == '\0') {
		pFile = pStdin2TmpFile(&lFilesize);
		if (pFile == NULL) {
			werr(0, "I can't save the standard input to a file");
			return FALSE;
		}
	} else {
		pFile = fopen(szFilename, "rb");
		if (pFile == NULL) {
			werr(0, "I can't open '%s' for reading", szFilename);
			return FALSE;
		}

		lFilesize = lGetFilesize(szFilename);
		if (lFilesize < 0) {
			(void)fclose(pFile);
			werr(0, "I can't get the size of '%s'", szFilename);
			return FALSE;
		}
	}

	iWordVersion = iGuessVersionNumber(pFile, lFilesize);
	if (iWordVersion < 0 || iWordVersion == 3) {
		if (bIsRtfFile(pFile)) {
			werr(0, "%s is not a Word Document."
				" It is probably a Rich Text Format file",
				szFilename);
		} if (bIsWordPerfectFile(pFile)) {
			werr(0, "%s is not a Word Document."
				" It is probably a Word Perfect file",
				szFilename);
		} else {
#if defined(__dos)
			werr(0, "%s is not a Word Document or the filename"
				" is not in the 8+3 format.", szFilename);
#else
			werr(0, "%s is not a Word Document.", szFilename);
#endif /* __dos */
		}
		(void)fclose(pFile);
		return FALSE;
	}
	/* Reset any reading done during file testing */
	rewind(pFile);
	
	#ifndef SYMBIAN
	pDiag = pCreateDiagram(szTask, szFilename);
	#else
	pDiag = pCreateDiagram(szTask, szFilename, ofp );
	#endif /*SYMBIAN*/
	if (pDiag == NULL) {
		(void)fclose(pFile);
		return FALSE;
	}

	bResult = bWordDecryptor(pFile, lFilesize, pDiag);
	vDestroyDiagram(pDiag);

	(void)fclose(pFile);
	return bResult;
} /* end of bProcessFile */


#ifdef SYMBIAN
int fillArg( char **argv, char *inpStr)
{
	int count =0;
	const char *search = " ";
	
	char *token = strtok( inpStr, search);
	argv[0] = token;
	count = 1;
	while( token != NULL )
	{
		token = strtok( NULL, search);
		argv[count++] = token;
	}
	return count-1;
}
#endif /*SYMBIAN*/
int
main(int argc, char **argv)
{
	#ifdef SYMBIAN
	FILE *ofp = NULL;
	char *buf;
	#endif /*SYMBIAN*/
	
	options_type	tOptions;
	const char	*szWordfile;
	int	iFirst, iIndex, iGoodCount;
	BOOL	bUsage, bMultiple, bUseTXT, bUseXML;

	if (argc <= 0) {
		return EXIT_FAILURE;
	}

	#ifdef SYMBIAN
	//Adding HOME environment Variable explicitly
	
    buf = (char *)malloc(FILENAME_MAX);
    // get path to the private folder
    getcwd(buf, FILENAME_MAX);
	#ifndef __WINS__
	// acquire installation location and get the drive letter 
	buf[0] = argv[0][0]; // argv[0] contains full path to exe including drive
	#endif

    strcat(buf, "\\Resources\\");
	if (setenv("HOME", buf, 1) != 0) {
		return EXIT_FAILURE;
	}
    free(buf);
	#endif /*SYMBIAN*/

	szTask = szBasename(argv[0]);

	if (argc <= 1) {
#ifdef SYMBIAN
		char* inpStr = (char*) malloc(_POSIX_ARG_MAX);
		/*If there is no command-line input, Prompt for it!*/
		vUsage();
		
		fprintf(stdout, "\n\nEnter the input Command String:");
		fgets( inpStr, _POSIX_ARG_MAX, stdin );
		
		argc = fillArg( argv, inpStr);
		/* Check whether the first argument is valid or not */
		if ( strcasecmp ( "antiword", argv[0]))
		{
			fprintf(stdout, "\nInvalid command syntax, Please read the syntax properly\n\n\n");
			bUsage = TRUE;
			getchar();
		}
		else
		{
			iFirst = iReadOptions(argc, argv);
			bUsage = iFirst <= 0;
		}
		#else 
		bUsage = TRUE;
		iFirst = 1;
		free(inputStr);
#endif /*SYMBIAN*/
	} else {
		iFirst = iReadOptions(argc, argv);
		bUsage = iFirst <= 0;
	}
	if (bUsage) {
		vUsage();
		#ifdef SYMBIAN
		getchar();
		#endif /*SYMBIAN*/
		return iFirst < 0 ? EXIT_FAILURE : EXIT_SUCCESS;
	}

#if defined(N_PLAT_NLM) && !defined(_VA_LIST)
	nwinit();
#endif /* N_PLAT_NLM && !_VA_LIST */

	vGetOptions(&tOptions);

#if !defined(__dos)
	if (is_locale_utf8()) {
#if defined(__STDC_ISO_10646__)
		/*
		 * If the user wants UTF-8 and the envirionment variables
		 * support UTF-8, than set the locale accordingly
		 */
		if (tOptions.eEncoding == encoding_utf_8) {
			if (setlocale(LC_CTYPE, "") == NULL) {
				werr(1, "Can't set the UTF-8 locale! "
					"Check LANG, LC_CTYPE, LC_ALL.");
			}
			DBG_MSG("The UTF-8 locale has been set");
		} else {
			(void)setlocale(LC_CTYPE, "C");
		}
#endif /* __STDC_ISO_10646__ */
	} else {
		if (setlocale(LC_CTYPE, "") == NULL) {
			werr(0, "Can't set the locale! Will use defaults");
			(void)setlocale(LC_CTYPE, "C");
		}
		DBG_MSG("The locale has been set");
	}
#endif /* !__dos */

	bMultiple = argc - iFirst > 1;
	bUseTXT = tOptions.eConversionType == conversion_text ||
		tOptions.eConversionType == conversion_fmt_text;
	bUseXML = tOptions.eConversionType == conversion_xml;
	iGoodCount = 0;

#if defined(__dos)
	if (tOptions.eConversionType == conversion_pdf) {
		/* PDF must be written as a binary stream */
		setmode(fileno(stdout), O_BINARY);
	}
#endif /* __dos */

	if (bUseXML) {
		fprintf(stdout,
	"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
	"<!DOCTYPE %s PUBLIC \"-//OASIS//DTD DocBook XML V4.1.2//EN\"\n"
	"\t\"http://www.oasis-open.org/docbook/xml/4.1.2/docbookx.dtd\">\n",
		bMultiple ? "set" : "book");
		if (bMultiple) {
			fprintf(stdout, "<set>\n");
		}
	}

	//Output file
	#ifdef SYMBIAN
	ofp = fopen( argv[argc-1], "w");
	if ( ofp == NULL)
		{
			printf("Unable to open the output file: %s\n",argv[argc-1]);
			exit(0);
		}
	#endif /*SYMBIAN*/

	for (iIndex = iFirst; iIndex < argc-1; iIndex++) {
		if (bMultiple && bUseTXT) {
			szWordfile = szBasename(argv[iIndex]);
			fprintf(stdout, "::::::::::::::\n");
			fprintf(stdout, "%s\n", szWordfile);
			fprintf(stdout, "::::::::::::::\n");
		}
		#ifndef SYMBIAN
		if (bProcessFile(argv[iIndex])) {
		#else
		if (bProcessFile(argv[iIndex],ofp )) {
		#endif  /*SYMBIAN*/
		
			iGoodCount++;
		}
	}

	if (bMultiple && bUseXML) {
		fprintf(stdout, "</set>\n");
	}

	DBG_DEC(iGoodCount);
	#ifdef SYMBIAN
	fclose(ofp);
	fprintf(stdout, "\n\nConversion is successful!!, check out this file : %s\n", argv[argc-1]);
	getchar();
	#endif /*SYMBIAN*/
	
	return iGoodCount <= 0 ? EXIT_FAILURE : EXIT_SUCCESS;
} /* end of main */
