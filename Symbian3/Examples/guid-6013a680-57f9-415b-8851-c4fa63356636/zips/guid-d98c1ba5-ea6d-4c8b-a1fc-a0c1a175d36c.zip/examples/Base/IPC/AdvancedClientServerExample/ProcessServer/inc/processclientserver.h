// Copyright (c) 2007-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
// shared client/server definitions
//

#include <e32std.h>

#ifndef __PROCESS_CLIENT_SERVER_H__
#define __PROCESS_CLIENT_SERVER_H__



const TInt KMaxMessageLen=100;

/**
	Enumeration of the different server requests
*/
enum TProcessServerRequest
	{
	ELoadDeviceDriver,
	EUnloadDeviceDriver,
	EOpenDriver,
	EDummyLDDSendData,
	EDummyLDDSendDataCancel,
	EDummyLDDReceiveData,
	EDummyLDDReceiveDataCancel
	};

_LIT(KDriver1LddFileName,"DRIVER1_LDD");
_LIT(KDriver1PddFileName,"DRIVER1_PDD");

_LIT(KProcessServerName,"ProcessServer");

_LIT(KProcessServerServerImg, "ProcessServer");

const TUint KProcessServerVersion=8;
const TUint KProcessServerMinorVersionNumber=0;
const TUint KProcessServerBuildVersionNumber=1;

#endif //__PROCESS_CLIENT_SERVER_H__
