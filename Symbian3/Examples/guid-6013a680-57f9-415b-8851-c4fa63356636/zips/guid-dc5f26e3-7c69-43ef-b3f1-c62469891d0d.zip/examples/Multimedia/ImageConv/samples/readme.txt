\bmp
	symbian1.bmp		1-bit depth image
	symbian4.bmp		4-bit depth image
	symbian8.bmp		8-bit depth image
	symbian24.bmp		24-bit depth image

\gif
	symbian-basic.gif	non-interlaced gif
	symbian-interlaced.gif	interlaced gif
	symbian-transparent.gif	gif with transparent background

\ico
	symbian.ico		ico (Windows icon) image

\jpg
	symbian15quality.jpg	15% quality (PaintShopPro) JPG
	symbian75quality.jpg	75% quality (PaintShopPro) JPG

\mbm
	symbian1.mbm		mbm with 2 1-bit depth images
	symbian24.mbm		mbm with 2 24-bit depth images

\ota
	sy.ota			OTA image

\png
	symbian-basic.png	non-interlaced png
	symbian-interlaced.png	interlaced png

\tiff
	symbian-fax3.tif	fax-ccitt 3

\wbmp
	symbian.wbmp		WAP image

\wmf
	symbian.wmf		WMF image
