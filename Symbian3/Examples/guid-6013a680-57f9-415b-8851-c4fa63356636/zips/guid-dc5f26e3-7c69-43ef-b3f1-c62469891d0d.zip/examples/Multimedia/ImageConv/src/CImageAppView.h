// Copyright (c) 2001-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//

#ifndef CIMAGEAPPVIEW
#define CIMAGEAPPVIEW

#include <coecntrl.h> 
#include <fbs.h>

#include "CImageAppUi.h"

// Application view: displays the bitmap
class CImageAppView : public CCoeControl, public MCoeControlBrushContext
    {
public:
    void ConstructL(const TRect& aRect);
	
	// Get display mode
	TDisplayMode DisplayMode() const;
	// Draw view
	void DrawBitmapNow();
	// Clear view
	void Clear();
	// Set bitmap to draw
	void SetBitmap(CFbsBitmap* aBitmap);

private:
	// from CCoeControl
	void Draw(const TRect& /*aRect*/) const;

private:
	CFbsBitmap* iBitmap;
    };

#endif

