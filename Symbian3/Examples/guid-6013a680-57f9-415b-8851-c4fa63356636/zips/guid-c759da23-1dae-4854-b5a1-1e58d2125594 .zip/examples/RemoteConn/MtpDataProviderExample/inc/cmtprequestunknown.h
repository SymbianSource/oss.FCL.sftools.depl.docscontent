// Copyright (c) 2010 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//

#ifndef __CMTPREQUESTUNKNOWN_H__
#define __CMTPREQUESTUNKNOWN_H__

#include "cmtpexampledprequestprocessor.h"

/** 
 Defines device data provider OpenSession request processor
 */
class CMTPRequestUnknown : public CMTPExampleDpRequestProcessor
    {
public:
    static MMTPExampleDpRequestProcessor* NewL(
                                    MMTPDataProviderFramework& aFramework,
                                    MMTPConnection& aConnection);   
    ~CMTPRequestUnknown();
        
    
protected:  
    CMTPRequestUnknown(
                    MMTPDataProviderFramework& aFramework,
                    MMTPConnection& aConnection);

protected:  //from CMTPExampleDpRequestProcessor
    virtual void ServiceL();
    virtual TBool Match(const TMTPTypeRequest& aRequest, MMTPConnection& aConnection) const;       
    };
    
#endif

