// Copyright (c) 2010 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//

#ifndef CMTPEXAMPLEDPCONST_H_
#define CMTPEXAMPLEDPCONST_H_

#include <e32std.h>

#include <mtp/mtpprotocolconstants.h>

/**
 Define all the operations that are supported by the example data provider
 */

enum MTPExampleDPOpCode
    {
    EMTPOpVendorDefined1  = 0x9205,     //Vendor defined operations.
    EMTPOpVendorDefined2  = 0x9206,
    };

static const TUint16 KMTPExampleDpSupportedOperations[] = 
    {         
    EMTPOpVendorDefined1,
    EMTPOpVendorDefined2
    };
    

#endif /* CMTPEXAMPLEDPCONST_H_ */
