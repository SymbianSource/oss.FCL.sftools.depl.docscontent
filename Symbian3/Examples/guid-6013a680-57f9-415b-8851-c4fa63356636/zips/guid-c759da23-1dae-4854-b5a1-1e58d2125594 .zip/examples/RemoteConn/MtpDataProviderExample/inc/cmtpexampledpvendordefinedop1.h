// Copyright (c) 2010 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//


#ifndef CMTPEXAMPLEDPVENDORDEFINEDOP1_H_
#define CMTPEXAMPLEDPVENDORDEFINEDOP1_H_

#include "cmtpexampledprequestprocessor.h"

class CMTPExampleDpVendorDefinedOp1 : public CMTPExampleDpRequestProcessor
    {
public:
    static MMTPExampleDpRequestProcessor* NewL(MMTPDataProviderFramework& aFramework, MMTPConnection& aConnection);    
    ~CMTPExampleDpVendorDefinedOp1(); 
    
private: // From CMTPExampleDpRequestProcessor

    void ServiceL();
     
private:
    void ConstructL();
    CMTPExampleDpVendorDefinedOp1(MMTPDataProviderFramework& aFramework, MMTPConnection& aConnection);
    };

#endif /* CMTPEXAMPLEDPVENDORDEFINEDOP1 */
