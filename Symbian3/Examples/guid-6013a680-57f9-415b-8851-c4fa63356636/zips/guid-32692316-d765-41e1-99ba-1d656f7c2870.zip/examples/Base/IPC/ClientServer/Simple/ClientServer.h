// Copyright (c) 2000-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//

#include <e32base.h>


// server name

_LIT(KCountServerName,"CountServer");

// A version must be specified when creating a session with the server

const TUint KCountServMajorVersionNumber=0;
const TUint KCountServMinorVersionNumber=1;
const TUint KCountServBuildVersionNumber=1;

IMPORT_C TInt StartThread(RThread& aServerThread);


// Function codes (opcodes) used in message passing between client and server
enum TCountServRqst
	{
	ECountServCreate = 1,
	ECountServSetFromString,
	ECountServClose,
    ECountServUnsupportedRequest,
	ECountServIncrease,
	ECountServIncreaseBy,
	ECountServDecrease,
	ECountServDecreaseBy,
	ECountServValue,
	ECountServReset
	};

enum TCountServLeave
{
	ENonNumericString = 99
};
