// Copyright (c) 2000-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
// DLL example program (1) to demonstrate the use of Thread local storage.
//

#include <e32test.h>


class CSetter : public CBase
  	{
public:
	IMPORT_C CSetter(CConsoleBase& aConsole);
	~CSetter();          
	IMPORT_C void   SetStaticTextL(const TDesC& aString);
	IMPORT_C void   ShowStaticText() const;
private: 
	CConsoleBase& iConsole;    // Use the console (not owned)
	};


class CGeneral : public CBase
  	{
public:
	IMPORT_C      CGeneral(CConsoleBase& aConsole);
	IMPORT_C void ShowStaticText() const;
private:
	CConsoleBase& iConsole; // Use the console (not owned)
	};

