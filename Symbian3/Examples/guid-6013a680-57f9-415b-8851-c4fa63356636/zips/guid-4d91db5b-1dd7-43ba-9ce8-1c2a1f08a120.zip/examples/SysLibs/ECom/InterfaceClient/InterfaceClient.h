// Copyright (c) 2001-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//

#ifndef __CINTERFACECLIENT_H
#define __CINTERFACECLIENT_H

#include <interface.h>

// Example ECOM client that uses the InterfaceImplementation plug-ins
// through the InterfaceDefinition (CExampleInterface) interface
class TInterfaceClient
	{
public:
	// Gets the default implementation of CExampleInterface
	void GetDefaultL();

	// Gets a CExampleInterface implementation by requesting
	// a specific types of capability
	void GetBySpecificationL();

	// Gets all the CExampleInterface implementations
	void GetByDiscoveryL();
	};

#endif

