// Copyright (c) 2001-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//

#ifndef _CIMPLEMENTATIONCLASSONE__
#define _CIMPLEMENTATIONCLASSONE__

#include <interface.h>

// An implementation of the CExampleInterface definition
class CImplementationClassOne : public CExampleInterface
	{
public:
	// Standardised safe construction which leaves nothing the cleanup stack.
	static CImplementationClassOne* NewL(TAny* aInitParams);
	// Destructor	
	~CImplementationClassOne();

	// Implementation of CExampleInterface
	void DoMethodL(TDes& aString);

private:
	// Construction
	CImplementationClassOne(TAny* aParams);
	void ConstructL();

private:
	// Data to pass back from implementation to client
	HBufC* iDescriptor;
	// Parameters taken from client
	CExampleInterface::TExampleInterfaceInitParams* iInitParams;
	};  

#endif

