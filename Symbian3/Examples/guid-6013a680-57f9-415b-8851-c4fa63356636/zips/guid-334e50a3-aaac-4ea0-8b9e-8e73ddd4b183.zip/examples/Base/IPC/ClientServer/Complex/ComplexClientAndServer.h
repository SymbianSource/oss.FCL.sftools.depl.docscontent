// Copyright (c) 2000-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//

#if !defined(__ComplexClientAndServer_H__)
#define __ComplexClientAndServer_H__

#include <e32base.h>

//server name

_LIT(KCountServerName,"MultiCountServer");

//the server version. A version must be specifyed when creating a session with the server
const TUint KCountServMajorVersionNumber=0;
const TUint KCountServMinorVersionNumber=1;
const TUint KCountServBuildVersionNumber=1;

//
IMPORT_C TInt StartThread(RThread& aServerThread);


//opcodes used in message passing between client and server
enum TCountServRqst
	{
	ECountServCreateSubSession = 1,
	ECountServCloseSubSession,
	ECountServInitSubSession,
	ECountServCloseSession,
	ECountServIncrease,
	ECountServIncreaseBy,
	ECountServDecrease,
	ECountServDecreaseBy,
	ECountServValue,
	ECountServReset,
	ECountServResourceCountMarkStart,
	ECountServResourceCountMarkEnd,
	ECountServResourceCount
	};


enum TCountServLeave
    {
	ENonNumericString = 99
    };
    
#endif    
