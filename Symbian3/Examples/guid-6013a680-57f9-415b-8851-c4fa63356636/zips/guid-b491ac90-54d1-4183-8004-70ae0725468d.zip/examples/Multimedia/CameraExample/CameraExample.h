// Copyright (c) 2007-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
// Contains the CCameraApplication, CCameraAppView, CCameraAppUi, 
// and CCameraDocument  classes.
//



/**
 @file
*/

#ifndef __CAMERAEXAMPLE_H
#define __CAMERAEXAMPLE_H

#include <coeccntx.h>
#include <coecntrl.h>
#include <eikenv.h>
#include <eikappui.h>
#include <eikapp.h>
#include <eikdoc.h>
#include <eikstart.h> 
#include <eikon.hrh>

#include <ecam.h>

#include <cameraexample.rsg>
#include "CameraExample.hrh"

#include <ecamplugin.h>
#include <ecaminfoplugin.h>
#include <bitdev.h>
#include <ecamadvsettingsintf.h>
#include <ecamadvsettings.h>
#include <ecamadvsettingsintfuids.hrh>
#include <cameraoverlay.h>
#include <camerasnapshot.h>
#include <ecamdirectviewfinder.h>

_LIT( KControlLabel, "Control" );
_LIT( KSettingsLabel, "Settings" );

/**
CCameraApplication provides methods that fetch 
application specific UID and the document object.
*/
class CCameraApplication : public CEikApplication
	{
private: 
	// Inherited from class CApaApplication
	CApaDocument* CreateDocumentL();
	TUid AppDllUid() const;
	};
	
/**
CCameraAppView provides functions to construct and 
display information messages.
*/
class CCameraAppView : public CCoeControl
    {
public:
	static CCameraAppView* NewL( const TRect& aRect );
	CCameraAppView();
	~CCameraAppView();
    void ConstructL( const TRect& aRect );
   	void DrawImage(CFbsBitmap* aImage) const;
	TPoint DrawBorders(const TSize& aSize) const;

private:
	// from CCoeControl
	void Draw(const TRect& /*aRect*/) const;
	
private:
	HBufC*  iCameraText;
    };	
/**
CCameraAppUi handles application-wide aspects of the application's UI.
*/
class CCameraAppUi : public CEikAppUi,public MCameraObserver2

    {
public:
    void ConstructL();
	~CCameraAppUi();
	
	// Basic features
	void ViewFinderL();
	void CaptureImageL();
	void CaptureVideoL();
	// From MCameraObserver2
	virtual void HandleEvent(const TECAMEvent& aEvent);
	virtual void ViewFinderReady(MCameraBuffer& aCameraBuffer,TInt aError);
	virtual void ImageBufferReady(MCameraBuffer& aCameraBuffer,TInt aError);
	virtual void VideoBufferReady(MCameraBuffer& aCameraBuffer,TInt aError);
 
    // Advanced features
    void AdvancedCamFeaturesL();
	void SnapShotL();
	void DirectViewFinderL();
	void HistogramL();
	void OverLayL();
	void PresetL();
	void ImageProcessingL();
	
private:
    // Inherited from class CEikAppUi
	void HandleCommandL(TInt aCommand);
	void InfoMessage(TInt aError, const TDesC& aSuccessMsg, const TDesC& aErrMsg);
	void InfoMessage(const TDesC& aMsg);

private:
	/** Pointer to the console interface */
	CCameraAppView* iAppView;
	/** Pointer to the class that provides access to camera */
	CCamera* iCamera;
	/** File session object */
   	RFs ifsSession;
   	/** Pointer to the MCameraObserver2 interface */
   	MCameraObserver2* iObserver2;

	};

/**
CCameraDocument constructs the application UI object partially.
*/
class CCameraDocument : public CEikDocument
	{
public:
	static CCameraDocument* NewL(CEikApplication& aApp);
	CCameraDocument(CEikApplication& aApp);
	void ConstructL();

private: 
	// Inherited from CEikDocument
	CEikAppUi* CreateAppUiL();
	};


#endif


