// Copyright (c) 2007-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
// This provides functions to draw the view and control.
//



/**
 @file 
*/
#include "CameraExample.h"

CCameraAppView::CCameraAppView()
	{
	}
CCameraAppView* CCameraAppView::NewL(const TRect& aRect)
	{
	CCameraAppView* self = new(ELeave) CCameraAppView();
	CleanupStack::PushL(self);
	self->ConstructL(aRect);
	CleanupStack::Pop();
	return self;
	}

CCameraAppView::~CCameraAppView()
	{
	delete iCameraText;
	}

/**
Standard initialisation for a window-owning control.
*/
void CCameraAppView::ConstructL( const TRect& aRect )
    {
    
	// Fetch the text from the resource file.
	iCameraText= iEikonEnv->AllocReadResourceL( R_EXAMPLE_TEXT_BASICCAMERA );
	
	// The control is window-owning.
	CreateWindowL();
   
	// Extent of the control.
	SetRect(aRect);

	// The control is ready to draw, so notify the UI framework.
	ActivateL();
	}

/**
Gets the graphics context and draws the control.
*/
void CCameraAppView::DrawImage(CFbsBitmap* aImage) const
	{
	CWindowGc& gc = SystemGc();
	// Displays the window and enables it to receive events.
	gc.Activate(Window());
	TRect drawRect=Rect();
	TPoint pos;
	pos.iX = (3 * drawRect.iBr.iX / 4) - (aImage->SizeInPixels().iWidth / 2);
	pos.iY = (drawRect.iBr.iY - aImage->SizeInPixels().iWidth) / 2;
	// Perform a bitmap block transfer.
	gc.BitBlt(pos,aImage);
	TRect border(pos,aImage->SizeInPixels());
	// Grow the rectangle by 1 pixel left, right, top and botttom.
	border.Grow(1,1);
	// Draw and fill the rectangle.
	gc.DrawRect(border);
	gc.Deactivate();
	iCoeEnv->WsSession().Flush();
	}
 
/**
Draws the view
*/
void CCameraAppView::Draw(const TRect& /*aRect*/) const
	{
	// Window graphics context
	CWindowGc& gc = SystemGc();
	
	// Area in which we shall draw
	TRect drawRect = Rect();

	// Font used for drawing text
	const CFont*  fontUsed;

	gc.Clear();
	
	// Use the title font supplied by the UI
	fontUsed = iEikonEnv->TitleFont();
	gc.UseFont( fontUsed );

	// Draw the text in the rectangle 	
	gc.DrawText( *iCameraText,drawRect,60 + fontUsed->HeightInPixels(),CGraphicsContext::ECenter, 0 );
	
	// Discard the font.
	gc.DiscardFont();
	}

/**
Gets the graphics context and draws the border.
*/
TPoint CCameraAppView::DrawBorders(const TSize& aSize) const
	{
	CWindowGc& gc = SystemGc();
	// Displays the window and enables it to receive events.
	gc.Activate(Window());
	TRect drawRect(Rect());
	TPoint pos;
	pos.iX = (drawRect.iBr.iX / 4) - (aSize.iWidth / 2);
	pos.iY = (drawRect.iBr.iY - aSize.iWidth) / 2;
	TRect border(pos,aSize);
	// Grow the rectangle by 1 pixel left, right, top and botttom.
	border.Grow(1,1);
	gc.SetPenColor(KRgbBlack);
	gc.DrawRect(border);
	gc.Deactivate();
	iCoeEnv->WsSession().Flush();
	return pos;
	}
