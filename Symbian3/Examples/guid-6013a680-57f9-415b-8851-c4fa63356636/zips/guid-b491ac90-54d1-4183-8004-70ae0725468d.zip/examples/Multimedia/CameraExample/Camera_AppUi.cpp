// Copyright (c) 2007-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
// This  file handles application-wide aspects of the application's UI
// such as the menu bar, opening and closing files and 
// exiting the application cleanly.
// The code demonstrates how to perform basic and advanced operations on a camera using ECam.
// Symbian does not provide the plugins for implementation of camera API. So this example runs
// only if the kit you are using supports camera implementation.
//



/**
 @file
*/

#include "CameraExample.h"
#include <ecamuids.hrh>
#include <ecom/ecomresolverparams.h>
#include <ecamadvsettings.h>
#include <icl/imagedata.h>
#include <camerahistogram.h>

const TInt KMaxErrLength = 50;
TInt error;

// List of Info messages
_LIT(KErrorFormat,"Error - %d (%S)");
_LIT(KFeatureNotSupported, "This feature is not supported by the camera implementation");
_LIT(KError,"\n Could not create the camera object due to either insufficient memory, out of bounds camera index or capability");

_LIT(KNotSupported, "Not supported. So cannot be set. Try to set another value");
_LIT(KSupportedFocusModes, "Getting supported focus modes");

_LIT(KPrepareImageCaptureErr, "PrepareImageCaptureL() failed");
_LIT(KPrepareVideoCaptureErr, "PrepareVideoCaptureL() failed");
_LIT(KImageSize, "Capturing image of size %d x %d");
_LIT(KVideoCapture, "Capturing video with capture rate %f and size % d x %d");
_LIT(KErrMessage,"CCameraAppUi::ImageBufferReady");

_LIT(KFocusModeSet, "Setting the focus mode successful");
_LIT(KFocusModeRetrieval, "Retrieval of focus mode successful");
_LIT(KSupportedFocusRanges, "Getting supported focus ranges");

_LIT(KSupportedFocusTypes, "Getting the supported focus types");
_LIT(KFocusTypeSet, "Setting the focus type to auto");
_LIT(KFocusTypeRetrieval, "Retrieval of focus type successful");
_LIT(KFocusRangeAuto,  "Setting focus range to automatic");
_LIT(KFocusRangeRetrieval, "Retrieval of focus range successful");

_LIT(KSupportedDriveModes, "Getting supported drive modes");
_LIT(KDriveModeSet, "Setting drive mode");
_LIT(KDriveModeRetrieval, "Getting the set drive mode");
_LIT(KSupportedBracketModes, "Getting supported bracket modes");
_LIT(KBracketModeRetrieval, "Getting the set bracket mode");

_LIT(KSupportedSnapshotFormats, "Getting the supported formats for snapshot");
_LIT(KPrepareSnapshot, "Preparing the snapshot was successful");
_LIT(KPrepareSnapshotErr, "Prepare snapshot failed");
_LIT(KSnapshotFormat,"Set the snapshot format to  EFormatJpeg");
_LIT(KSnapshotFormatErr,"The format you are trying to set is not supported");
_LIT(KStartSnapshot, "Starting the snapshot successful");
_LIT(KStopSnapshot, "Snapshot stopped");

_LIT(KViewFinderInactive, "View finder state inactive");
_LIT(KViewFinderPause , "Pausing the view finder successful");
_LIT(KViewFinderPauseErr, "Pausing the view finder failed");
_LIT(KViewFinderStatePaused,  "View finder state paused");
_LIT(KViewFinderResume, "Resuming view finder was successful");
_LIT(KViewFinderResumeErr, "Resuming view finder failed");
_LIT(KViewFinderStateActive, "View finder state active");

_LIT(KCreateHistogram, "Creating the non-DSA histogram was successful");
_LIT(KHistStart,"Start Histogram Successful");
_LIT(KHistStartErr,"Start Histogram failed");
_LIT(KHistStop,"Stopping the histogram successful");
_LIT(KHistStopErr,"Stopping histogram failed");
_LIT(KDestroyHistogram, "Destruction of histogram successful");
_LIT(KDestroyHistogramErr, "Destruction of histogram failed");

_LIT(KCreateoverlay ,"Creating overlay successful");
_LIT(KCreateoverlayErr , "Creating overlay failed.Cannot proceed further");
_LIT(KOverLayMode,"Set the current mode to  EModeStillImage");
_LIT(KOverLayModeErr,"The mode you are trying to set is not supported");
_LIT(KCurrentTypeErr,"The type you are trying to set is not supported");
_LIT(KOverlayType,"Blending is set to per pixel basis");
_LIT(KSetoverlayBmp , "Setting the Overlay Bitmap successful");
_LIT(KSetoverlayBmpErr , "Setting the Overlay Bitmap failed");
_LIT(KGetoverlayBmp, "Getting Overlay Bitmap successful");
_LIT(KGetoverlayBmpErr, "Getting Overlay Bitmap failed");
_LIT(KGetoverlayParams , "Getting the Overlay Bitmap successful");
_LIT(KGetoverlayParamsErr , "Getting the Overlay Bitmap failed");
_LIT(KSetoverlayParams , "Setting Overlay Parameters successful");
_LIT(KSetoverlayParamsErr , "Setting Overlay Parameters failed");
_LIT(KGetAllOverlays, "Getting All Overlays successful");
_LIT(KGetAllOverlaysErr , "Getting All Overlays failed");
_LIT(KReleaseOverlay, "Releasing Overlay successful");
_LIT(KReleaseOverlayErr, "Releasing Overlay failed");

_LIT(KGetAffectedSettings, "Getting the affected settings successful");
_LIT(KGetAffectedSettingsErr, "Getting the affected settings failed");
_LIT(KSupportedPresets, "Getting the supported presets");
_LIT(KEmptyArray, "Getting the presets failed. The array of Uids is empty");
_LIT(KSetBrightness, "Adjusting brightness to maximum value");
_LIT(KImageEffect, "Set monochrome effect");


/**
Second phase constructor of the application UI class.
It creates and owns a single view.
*/
void CCameraAppUi::ConstructL()
    {
    
    CEikAppUi::ConstructL();
	iAppView = new(ELeave) CCameraAppView;
	iAppView->ConstructL(ClientRect());
	
	AddToStackL(iAppView);
	TRAP(error,iCamera = CCamera::NewL(*this,0,0));
	if (error != KErrNone)
		{
		iEikonEnv->InfoMsg(KError);
		User::Leave(error);
		}

	// Asynchronous function that performs any required initialization 
	// and reserves the camera for exclusive use.
	iCamera->Reserve();

	}

/**
The application UI class owns the view, and is responsible for destroying it.
*/
CCameraAppUi::~CCameraAppUi()
	{
	if (iCamera!=NULL)
		iCamera->Release();
	delete iCamera;
		
	if (iAppView)
		{
		RemoveFromStack(iAppView);
		delete iAppView;
		}
	ifsSession.Close();
	}


/**
Called by the UI framework when a command has been issued.
@param TInt aCommand	The ID of the command	
*/
void CCameraAppUi::HandleCommandL(TInt aCommand)
	{

	switch (aCommand)
		{
	case ETCamCmdPowerOn:
		iCamera->PowerOn();
		break;
	case ETCamCmdPowerOff:
		iCamera->PowerOff();
		break;
	case ETCamCmdViewFinder:
		ViewFinderL();
		break;
	case ETCamCmdCaptureImage:
		CaptureImageL();
		break;
	case ETCamCmdCaptureVideo:
		CaptureVideoL();
		break;
	case ETCamCmdIncBrightness:
		iCamera->SetBrightnessL(iCamera->Brightness() + 10);
		break;
	case ETCamCmdIncContrast:
		iCamera->SetContrastL(iCamera->Contrast() + 10);
		break;
	case ETCamCmdDecBrightness:
		iCamera->SetBrightnessL(iCamera->Brightness() - 10);
		break;
	case ETCamCmdDecContrast:
		iCamera->SetContrastL(iCamera->Contrast() - 10);
		break;
	case ETCamCmdAdvancedCamFeatures:
		AdvancedCamFeaturesL();	
		break;	
	case ETCamCmdSnapShot:
		SnapShotL();
		break;	
	case ETCamCmdDirectViewFinder:
		DirectViewFinderL();	
		break;	
	case ETCamCmdHistogram:
		HistogramL();	
		break;	
	case ETCamCmdOverLay:
		OverLayL();	
		break;	
	case ETCamCmdPreset:
		PresetL();	
		break;	
	case ETCamCmdImageProcessing:
		ImageProcessingL();		
		break;	
	case EEikCmdExit:
		Exit();
		break;
		}
	}

/**
Transfers the view finder data to the given portion of the screen using 
direct screen access and continues to transfer until its called again.
@leave KErrNotSupported
@leave KErrNotReady if Reserve() has not been called.
*/
void CCameraAppUi::ViewFinderL()
	{
	TSize imageSize;
	iCamera->EnumerateCaptureSizes(imageSize,1,CCamera::EFormatFbsBitmapColor16M);
	const TPoint pos = iAppView->DrawBorders(imageSize);
	
	TRect screenRect(pos,imageSize);
	TRect clipRect;

	if (!iCamera->ViewFinderActive())
		{
		iCamera->StartViewFinderDirectL(iCoeEnv->WsSession(),*iCoeEnv->ScreenDevice(),*iAppView->DrawableWindow(),screenRect,clipRect);		
		}
	else
		{
		iCamera->StopViewFinder();
		}
	}

/**
Request asynchronous still image capturing.
The MCameraObserver2::ImageBufferReady() will be called when request is completed.
@leave KErrNotSupported
@leave KErrNoMemory
@leave KErrInUse
@leave KErrNotReady.
*/
void CCameraAppUi::CaptureImageL()
	{
	TSize imageSize;
	iCamera->EnumerateCaptureSizes(imageSize,1,CCamera::EFormatFbsBitmapColor16M);
	TRAP(error, iCamera->PrepareImageCaptureL(CCamera::EFormatFbsBitmapColor16M,1));
	if(error!= KErrNone)
		{
		InfoMessage(KPrepareImageCaptureErr);
		User::Leave(error);	
		}
	
	iCamera->CaptureImage();
	
	// Displays the captured image size
	TBuf<100> buffer;
    buffer.Format(KImageSize,imageSize.iWidth,imageSize.iHeight);
	InfoMessage(buffer);
		
	}

/**
Captures video.
@leave KErrNotSupported, KErrNoMemory.
*/
void CCameraAppUi::CaptureVideoL()
	{
	TSize frameSize;
	TReal32 frameRate = 0;
	iCamera->EnumerateVideoFrameSizes(frameSize,0,CCamera::EFormatFbsBitmapColor16M);
	iCamera->EnumerateVideoFrameRates(frameRate,0,CCamera::EFormatFbsBitmapColor16M,0);
	
	if (!iCamera->VideoCaptureActive())
		{
		TRAP(error, iCamera->PrepareVideoCaptureL(CCamera::EFormatFbsBitmapColor16M,0,0,2,1));
		if(error!= KErrNone)
			{
			InfoMessage(KPrepareVideoCaptureErr);
			User::Leave(error);	
			}
		
		iCamera->StartVideoCapture();
		
		// Displays the captured video size and rate of capture
		TBuf<100> videoBuf;
    	videoBuf.Format(KVideoCapture,frameRate,frameSize.iWidth,frameSize.iHeight);
		InfoMessage(videoBuf);
		}
	else
		{
		iCamera->StopVideoCapture();
		}	
	}

/**
Indicates the completion of a camera event
Implementations of MCameraObserver2 should ignore events which 
are not recognised and should not leave.

@param  aEvent
	        A reference to a TECAMEvent. This can be completion of a call to Reserve() 
			or a call to PowerOn() or a notification that the client has lost control 
			of the camera.
			The event contains a uid identifying the event and an accompanying
			error code (KErrNone for the successful completion of a request).
			The error will be KErrNotReady for a request that was made out of the
			correct sequence.
			The error will be KErrAccessDenied for a Reserve() request that failed
			because a higher priority client already controls the camera.	

*/	

/**
Empty implementation of pure virtual function of MCameraObserver2	
*/
void CCameraAppUi::HandleEvent(const TECAMEvent& /*aEvent*/)
	{
	}
	

/**
Empty implementation of pure virtual function of MCameraObserver2
It is called if StartViewFinder is used, while the example uses 
the alternative StartViewFinderDirectL	
*/
void CCameraAppUi::ViewFinderReady(MCameraBuffer& /*aCameraBuffer*/,TInt /*aError*/)
	{
	
	}

/**
Called by the camera when image capture is complete. 
It draws the captured image as a bitmap to the application view
BitmapL() returns a picture that has been captured.
@param MCameraBuffer &aCameraBuffer 	A reference to an MCameraBuffer if successful, or NULL if not successful.
	   TInt aError 						KErrNone if successful, or an error code if not successful
*/	
void CCameraAppUi::ImageBufferReady(MCameraBuffer& aCameraBuffer,TInt aError)
	{
	if (iCamera->ViewFinderActive())
		{	
		iCamera->StopViewFinder();
		}
	TBuf<KMaxErrLength> msgBuffer;
	if(aError)
		{
		msgBuffer.Format(KErrorFormat,aError,&KErrMessage);
		iEikonEnv->InfoMsg(msgBuffer);
		return;
		}
		TRAPD(error,iAppView->DrawImage(&aCameraBuffer.BitmapL(0)));
		aCameraBuffer.Release();
	if (error)
		{
		msgBuffer.Format(KErrorFormat,aError,&KErrMessage);
		iEikonEnv->InfoMsg(msgBuffer);
		}
		
	}
/**
Called by the camera when video capture is complete. 
It draws the captured video as frames to the application view
BitmapL() returns the video that has been captured.
View finder is not stopped as in ImageBufferReady
in order to simulate continuous buffering of data during video capture 
as against freezing the view finder when an image is captured.

@param MCameraBuffer &aCameraBuffer 	A reference to an MCameraBuffer if successful, or NULL if not successful.
	   TInt aError 						KErrNone if successful, or an error code if not successful
*/		
void CCameraAppUi::VideoBufferReady(MCameraBuffer& aCameraBuffer,TInt aError)
	{
	TBuf<KMaxErrLength> msgBuffer;
	_LIT(KErrMessage,"CCameraAppUi::FrameBufferReady");
	if (aError)
		{
		msgBuffer.Format(KErrorFormat,aError,&KErrMessage);
		iEikonEnv->InfoMsg(msgBuffer);
		return;
		}
	TRAPD(error,iAppView->DrawImage(&aCameraBuffer.BitmapL(0)));
	aCameraBuffer.Release();
	if (error)
		{
		msgBuffer.Format(KErrorFormat,error,&KErrMessage);
		iEikonEnv->InfoMsg(msgBuffer);
		}	
	}

/**
Sets and gets some of the features supported by CCameraAdvancedSettings API 
for controlling digital camera advanced settings individually.
Settings change fire a corresponding Uid event to MCameraObserver2 client of the camera.
@leave KErrNotSupported
@leave KErrNoMemory
@leave KErrInUse
@leave KErrNotReady.
*/
void CCameraAppUi::AdvancedCamFeaturesL()
	{
	CCamera::CCameraAdvancedSettings* settings = NULL;
	settings = CCamera::CCameraAdvancedSettings::NewL(*iCamera);
	if (settings == NULL)
		{
		iEikonEnv->InfoMsg(KFeatureNotSupported);
		return;
		}
	CleanupStack::PushL(settings);
	
	// Assigns the focus mode to be set	
	CCamera::CCameraAdvancedSettings::TFocusMode focusMode = CCamera::CCameraAdvancedSettings::EFocusModeFixed;
	
	// Gets the supported modes
	TInt suppFocusModes = settings->SupportedFocusModes();
	InfoMessage(KSupportedFocusModes);
	
	// Checks if the focus mode is supported before setting it.
	if (focusMode & suppFocusModes)
	    {
	   	// Sets the focus mode if it is supported
	    settings->SetFocusMode(focusMode);
	    InfoMessage(KFocusModeSet);	 	
	    }
	else
	    {
	    InfoMessage(KNotSupported);
	   	// Set auto mode since other mode is not supported
	   	CCamera::CCameraAdvancedSettings::TFocusMode focusMode = CCamera::CCameraAdvancedSettings::EFocusModeAuto;
	   	settings->SetFocusMode(focusMode);   
	    }
	    
	// Retrieves the set focus mode	
	focusMode = settings->FocusMode();
	InfoMessage(KFocusModeRetrieval);   
	
	// Assigns the focus range to auto and checks if it is supported
	CCamera::CCameraAdvancedSettings::TFocusRange focusRange = CCamera::CCameraAdvancedSettings::EFocusRangeHyperfocal;
	    
	// Gets the supported ranges	    	
	TInt suppRanges = settings->SupportedFocusRanges();
	InfoMessage(KSupportedFocusRanges);
	
	// Checks if the focus range is supported before setting it.
	if (focusRange & suppRanges) 
	    {
	   	// Sets the focus range if it is supported
	    settings->SetFocusRange(focusRange);
	    InfoMessage(KFocusRangeAuto);
	    // Gets the set focus range	
	    focusRange = settings->FocusRange();
		InfoMessage(KFocusRangeRetrieval);	 	
	    }
	else
	    {
	    InfoMessage(KNotSupported);	
	    }
		
	// Assigns the focus type to EAutoFocusTypeOff
	CCamera::CCameraAdvancedSettings::TAutoFocusType focusType = CCamera::CCameraAdvancedSettings::EAutoFocusTypeOff;
	
	// Gets the supported focus types
	TInt suppFocusTypes = settings->SupportedAutoFocusTypes();
	InfoMessage(KSupportedFocusTypes);
	
	// Checks if the focus type is supported before setting it.
	if (focusType & suppFocusTypes)
	    {
	    // Sets the focus type if it is supported
	    settings->SetAutoFocusType(focusType);
	    InfoMessage(KFocusTypeSet);	 		
	    }
	else
	    {
	    InfoMessage(KNotSupported);
	   	// Sets another type if the above type is not supported
	   	CCamera::CCameraAdvancedSettings::TAutoFocusType autoFocusType = CCamera::CCameraAdvancedSettings::EAutoFocusTypeSingle;
	   	settings->SetAutoFocusType(autoFocusType);
	    
	    }
	    // Retrieves the set focus mode	
	    focusType = settings->AutoFocusType();
		InfoMessage(KFocusTypeRetrieval);  
		
	// Assigns the drive mode to the value you want to check	
	CCamera::CCameraAdvancedSettings::TDriveMode driveMode = CCamera::CCameraAdvancedSettings::EDriveModeSingleShot;
	
	// Gets the supported drive modes
	TInt suppDriveModes = settings->SupportedDriveModes();
	InfoMessage(KSupportedDriveModes);
	
	// Checks if the drive mode is supported before setting it.
	if (driveMode & suppDriveModes) 
	    {
	   	// Sets the drive mode.
	    settings->SetDriveMode(driveMode);
	    InfoMessage(KDriveModeSet);	 	
	    }
	else
	    {
	    InfoMessage(KNotSupported);
	   	// Sets auto mode if other type is not supported
	   	CCamera::CCameraAdvancedSettings::TDriveMode defaultDriveMode = CCamera::CCameraAdvancedSettings::EDriveModeAuto;
	   	settings->SetDriveMode(defaultDriveMode);	
	    }
	    
	// Retrieves the set drive mode	
	driveMode = settings->DriveMode();
	InfoMessage(KDriveModeRetrieval);  
	
	// Assigns bracket mode to EBracketMode3Image
	CCamera::CCameraAdvancedSettings::TBracketMode bracketMode = CCamera::CCameraAdvancedSettings::EBracketMode3Image;
	
	// Gets the supported bracket modes
	TInt suppBracketModes = settings->SupportedBracketModes();
	InfoMessage(KSupportedBracketModes);
	
	// Checks if the bracket mode is supported before setting it.
	if (bracketMode & suppBracketModes) 
	    {
	    settings->SetBracketMode(bracketMode);	
	 	// Retrieve the set bracket mode	
		bracketMode = settings->BracketMode();  
	    }
	    
	else
		{
	 	InfoMessage(KNotSupported);
	 	// Sets other mode since the previously set mode is not supported
	   	CCamera::CCameraAdvancedSettings::TBracketMode bracketMode = CCamera::CCameraAdvancedSettings::EBracketModeOff;
	   	settings->SetBracketMode(bracketMode);
	   	bracketMode = settings->BracketMode(); 
	   	InfoMessage(KBracketModeRetrieval);
	 	}
	 	
	TBool redEye = settings->RedEyeReduceOn();
	// If red eye reduction is turned off, turn it on
	if(redEye == EFalse)
		{
		settings->SetRedEyeReduceOn(ETrue);	
		}
	
	CleanupStack::PopAndDestroy(settings);
	}

/**
Requests snapshot data in a specified image format for both still images and video.
Selects snapshot parameters by calling PrepareSnapshotL(). 
Then starts and stops receiving notifications from the ECam server by calling StartSnapshot() and StopSnapshot().
@leave KErrNoMemory
@leave system-wide error codes
*/	
void CCameraAppUi::SnapShotL()
	{
	CCamera::CCameraSnapshot* snap = NULL;
 	TRAPD(error, snap  = CCamera::CCameraSnapshot::NewL(*iCamera));	
	if (snap == NULL)
		{
		iEikonEnv->InfoMsg(KFeatureNotSupported);
		return;
		}
	   
    CleanupStack::PushL(snap);    	
    // Gets the list of camera formats for which the 
    // ECam Server supports snapshots.
	TUint suppFormats = snap->SupportedFormats();
	InfoMessage(KSupportedSnapshotFormats); 
	
	CCamera::TFormat format = CCamera::EFormatJpeg;
	if(suppFormats & format)
		{
		InfoMessage(KSnapshotFormat);
		}
	else
		{
		InfoMessage(KSnapshotFormatErr);
		User::Leave(KErrNotSupported);
		}
		
	TSize sShotSize(90,50);
	TRgb bgrndColor(100,100,100);
    TBool aspectRatio = ETrue;
    TPoint orgPos(2,2);
     
    // Sets the properties of the snapshot data including 
    // background colour and the position of the snapshot  
    TRAP(error,snap->PrepareSnapshotL(format, orgPos, sShotSize, bgrndColor,aspectRatio));
    if(error!= KErrNone)
		{
		InfoMessage(KPrepareSnapshotErr);
		User::Leave(error);	
		}
		
    InfoMessage(KPrepareSnapshot);
    	
	TBool isActive = EFalse;
	isActive = User::LeaveIfError(snap->IsSnapshotActive());
    User::LeaveIfError(isActive);
    
    // A callback to HandleEvent() will occur when the snapshot data 
    // is ready to be retrieved.
    // On success eventUid in HandleEvent() should have the value KUidECamEventCameraSnapshot
	snap->StartSnapshot();
	InfoMessage(KStartSnapshot);

    // Deactivates the snapshot feature if it is active
    snap->StopSnapshot();
    InfoMessage(KStopSnapshot);
	CleanupStack::PopAndDestroy(snap);	    	   	
	}   	    			

/**
Demonstrates direct View Finder functionalities, pause and resume.
@leave KErrNoMemory
*/  
void CCameraAppUi::DirectViewFinderL()
	{
	CCamera::CCameraDirectViewFinder* directviewfinder = NULL;
 	TRAPD(error, directviewfinder  = CCamera::CCameraDirectViewFinder::NewL(*iCamera));	
	if (directviewfinder == NULL)
		{
		iEikonEnv->InfoMsg(KFeatureNotSupported);
		return;
		}
	
	CleanupStack::PushL(directviewfinder);

	// Gets the default viewfinder state
	directviewfinder->ViewFinderState();
	InfoMessage(KViewFinderInactive);  	
	
	// Assumption is that meanwhile direct viewfinder has been started. This would be done by calling CCamera::StartViewFinderDirectL(). 
	// This function starts the direct viewfinder and hence changes the state to active. 
	// Also performs initial boundary checking that 'viewfinder remains inactive before its called'. So, the vfstate changes to active.
	// The next step is to pause the direct viewfinder
        
	TRAP(error, directviewfinder->PauseViewFinderDirectL());
	InfoMessage(error, KViewFinderPause, KViewFinderPauseErr);  	

	directviewfinder->ViewFinderState();
	InfoMessage(KViewFinderStatePaused);  	
	
	// The next step is to resume the direct viewfinder
	TRAP(error, directviewfinder->ResumeViewFinderDirectL());
	InfoMessage(error, KViewFinderResume, KViewFinderResumeErr);  	

	directviewfinder->ViewFinderState();
	InfoMessage(KViewFinderStateActive);  	
	
	CleanupStack::PopAndDestroy(directviewfinder);
	}

/**
Gets default histogram data in a specified format for an image 
sets it to a different value and gets it again.
The fuction calls will not leave in case of an error but,
just throw up an info message flagging an error.
@leave KErrNoMemory 
@leave KErrArgument
*/
void CCameraAppUi::HistogramL()
	{
	CCamera::CCameraHistogram* hist = NULL;
	
	TRAPD(error, hist = CCamera::CCameraHistogram::NewL(*iCamera));
	if (hist == NULL)
		{
		iEikonEnv->InfoMsg(KFeatureNotSupported);
		return;
		}
	CleanupStack::PushL(hist);
	
	// Gets the supported set of values
	TUint32 suppHists = hist->SupportedHistograms();
	
	// The array should not be empty 
	if (suppHists == 0)
		{
		User::Leave(KErrNotSupported);
		}
		
	// Assigns the histogram type to ELuminance	
	CCamera::CCameraHistogram::THistogramType histType = CCamera::CCameraHistogram::ELuminance;
		
	// Checks if the histogram type is supported before setting it.
	if (suppHists & histType)
	    {
	 	// Prepare Non-DSA based histogram
		TUint histhandle = 0;
		
		TRAP(error, histhandle = hist->PrepareHistogramL(CCamera::CCameraHistogram::ELuminance));
		if(error != KErrNone)
			{
			User::Leave(error);
			}
		InfoMessage(KCreateHistogram);
	
		// Starts getting histogram notifications	    	
		TRAP(error,hist->StartHistogramL(histhandle));
		InfoMessage(error, KHistStart, KHistStartErr); 	
	    
		// After a KUidECamEventCameraHistogram event is received in HandleEventL(), a  
		// histogram data buffer can be obtained using HistogramDataL(). The data buffer
		// should be released after use, using MHistogramBuffer::Release().
		// TRAP(error,MHistogramBuffer& buffer = hist->HistogramDataL());
	
		// Stops getting histogram notifications
		TRAP(error, hist->StopHistogramL(histhandle));
    	InfoMessage(error, KHistStop, KHistStopErr);
	
		// Destroys the histogram on the ECam server and releases its handle
    	TRAP(error, hist->DestroyHistogramL(histhandle));
		InfoMessage(error, KDestroyHistogram,KDestroyHistogramErr);
	
		}
		else
	    	{
	    	InfoMessage(KNotSupported);
	    	User::Leave(KErrNotSupported);    
	    	}
		CleanupStack::PopAndDestroy(hist);
	}

/**
Creates an overlay for bitmap and uses it to overlay an image onto a still image.
The fuction calls will not leave in case od an error but,
just throw up an info message flagging an error.
@leave KErrNoMemory
@leave KErrArgument
*/
void CCameraAppUi::OverLayL()
	{
	CCamera::CCameraOverlay* overlay = NULL;

	TRAPD(error, overlay = CCamera::CCameraOverlay::NewL(*iCamera));
	if (overlay == NULL)
		{
		iEikonEnv->InfoMsg(KFeatureNotSupported);
		return;
		}

	CleanupStack::PushL(overlay);
	
	CFbsBitmap* bitmap = new (ELeave) CFbsBitmap;
	CleanupStack::PushL(bitmap);		
	
	// Creates an overlay of hardcoded size 20x20
	User::LeaveIfError(bitmap->Create(TSize(20,20), EColor16M));

	CCamera::CCameraOverlay::TOverlayParameters parameters;
	
	CCamera::CCameraOverlay::TOverlaySupportInfo suppInfo;
 	// Gets information on the overlay functionality supported by the ECam server.
 	overlay->GetOverlaySupport(suppInfo);
 	
	TUint currentModes = suppInfo.iSupportedModes;
	if(currentModes & CCamera::CCameraOverlay::EModeStillImage)
		{
		// Sets the camera mode in which the image overlay can be used.
		parameters.iCurrentModes = CCamera::CCameraOverlay::EModeStillImage;
		InfoMessage(KOverLayMode);
		}
	else
		{
		InfoMessage(KOverLayModeErr);
		User::Leave(KErrNotSupported);
		}
		
	TUint currentTypes = suppInfo.iSupportedTypes;
	if(currentTypes & CCamera::CCameraOverlay::EPerPixel)
		{
		// Sets the camera type in which the image overlay can be used
		parameters.iCurrentTypes = CCamera::CCameraOverlay::EPerPixel;
		InfoMessage(KOverlayType);
		// Sets the camera type to EPerPixel needs this value to be set to zero.
		parameters.iAlphaValue = 0;	
		}
	else
		{
		InfoMessage(KCurrentTypeErr);
		User::Leave(KErrNotSupported);
		}
	
	// Sets the size of the overlay image in pixels.	
	//parameters.Size() = TSize(20,20);

	// Top left corner within the original image, where the overlay image is to be blended.		
	parameters.iPosition = TPoint(2,2);	
	
	// The z-order of the overlay to indicate depth	
	parameters.iZOrder = 1;
	
	// Creates an image overlay object on the ECam server.
	// Returns handle to the newly created object.
	TUint overlayHandle =0;	
	TRAP(error, overlayHandle = overlay->CreateOverlayL(parameters, bitmap));
	if(error!= KErrNone)
		{
		InfoMessage(KCreateoverlayErr);
		User::Leave(error);	
		}
	
	InfoMessage(KCreateoverlay);
	
	// Allows the overlay image data to be changed if it was 
	// not specified when the overlay was created using CreateOverlayL()
	TRAP(error, overlay->SetOverlayBitmapL(overlayHandle, bitmap));
	InfoMessage(error, KSetoverlayBmp, KSetoverlayBmpErr);	

	// Gets the overlay image data for a specified overlay.
	TRAP(error, overlay->GetOverlayBitmapL(overlayHandle, bitmap));
	InfoMessage(error, KGetoverlayBmp, KGetoverlayBmpErr);	

	// Gets the parameters that characterize a given overlay.
	TRAP(error, overlay->GetOverlayParametersL(overlayHandle, parameters));
	InfoMessage(error, KGetoverlayParams, KGetoverlayParamsErr);	
	
	// Sets new parameters that characterize a given overlay. 	
	TRAP(error, overlay->SetOverlayParametersL(overlayHandle, parameters));
	InfoMessage(error, KSetoverlayParams, KSetoverlayParamsErr);	
	 
	RArray<TUint> overlayHandlesArray;
	// Gets all the overlay handles maintained by the ECam server. 
	TRAP(error, overlay->GetAllOverlaysInZOrderL(overlayHandlesArray));
	InfoMessage(error, KGetAllOverlays, KGetAllOverlaysErr);	
 		
    // Releases the overlay handle.
    TRAP(error, overlay->ReleaseOverlay(overlayHandle));
    InfoMessage(error,KReleaseOverlay, KReleaseOverlayErr);
    
   	CleanupStack::PopAndDestroy(2, overlay); //bitmap, overlay
    }

/**
Simplifies user - camera interaction by allowing simultaneous setting 
of various advanced camera hardware settings using a single parameter.
Preset is identified by a single UID and relates to a known predefined outcome
@leave KErrNoMemory
@leave KErrNotSupported
*/   
void CCameraAppUi::PresetL()
	{
	CCamera::CCameraPresets* presets = NULL;
	TRAPD(error, presets  = CCamera::CCameraPresets::NewL(*iCamera));
	if (presets == NULL)
		{
		iEikonEnv->InfoMsg(KFeatureNotSupported);
		return;
		}
	
	CleanupStack::PushL(presets);
	
	// Gets the supported set of values  
	RArray<TUid> resultSet;
	
	// Gets the presets supported by the camera. 
	// These are identified by UIDs and relate to a known predefined outcome. 
	TRAP(error,presets->GetSupportedPresetsL(resultSet));
	InfoMessage(error,KSupportedPresets, KEmptyArray);
		
	// Sets preset after checking if it is supported
	TUid inputEventUid = KUidECamPresetOutdoor;
	TInt index = resultSet.Find(inputEventUid);
	if(index == -1)
		{
		User::Leave(KErrNotFound);	
		}
	
	presets->SetPreset(inputEventUid);

	// All the settings which are related to the preset in question will 
	// be included in the list, even though the value might not have changed.
	TRAP(error,presets->GetAffectedSettingsL(resultSet));
	
	InfoMessage(error, KGetAffectedSettings, KGetAffectedSettingsErr);
	resultSet.Reset();
	CleanupStack::PopAndDestroy(presets);
	}


/**
Does image processing operations like brightness, contrast, 
saturation adjustments etc. 
Performs simple image transformations like colour swapping.
@leave KErrNoMemory
*/
void CCameraAppUi::ImageProcessingL()
	{
	CCamera::CCameraImageProcessing* imageprocess = NULL;
	imageprocess = CCamera::CCameraImageProcessing::NewL(*iCamera);
	if (imageprocess == NULL)
		{
		iEikonEnv->InfoMsg(KFeatureNotSupported);
		return;
		}

	CleanupStack::PushL(imageprocess);
	
	// Gets array of supported transformations
	RArray<TUid> supportedTransforms; 	
    CleanupClosePushL(supportedTransforms);	
	imageprocess->GetSupportedTransformationsL(supportedTransforms);
	
	// Uses the adjust brightness transformation
	TUid transformUid = KUidECamEventImageProcessingAdjustBrightness;
	if (supportedTransforms.Find(transformUid) != KErrNotFound)
		{
		// Reads a list of the supported effects into an array
		RArray<TInt> supportedValues;
	    CleanupClosePushL(supportedValues);				
		TValueInfo info = ENotActive;
		imageprocess->GetTransformationSupportedValuesL(transformUid, supportedValues, info);
		
		// For the brightness transform, expects supported values to give the minimum and maximum range
		if (info == EContinuousRangeMinMax) 
			{			
			// Adjusts brightness by the first of the supported values
			TInt brightValue = supportedValues[1];
			imageprocess->SetTransformationValue(transformUid, brightValue);
			InfoMessage(KSetBrightness);
			}
		CleanupStack::PopAndDestroy(); // supportedValues
		}
	
	// Uses the monochrome effect	
	transformUid = KUidECamEventImageProcessingEffect;
	if (supportedTransforms.Find(transformUid) != KErrNotFound)
		{
		// Reads a list of the supported effects into an array
		RArray<TInt> supportedValues;
	    CleanupClosePushL(supportedValues);				
		TValueInfo info = ENotActive;
		imageprocess->GetTransformationSupportedValuesL(transformUid, supportedValues, info);
		// For effects, expects first member of the supported values to a bitfield of the supported effects
		TInt effects = supportedValues[0];
		CleanupStack::PopAndDestroy(); // supportedValues		
		if(effects & CCamera::CCameraImageProcessing::EEffectMonochrome)
    		{	
			imageprocess->SetTransformationValue(transformUid, CCamera::CCameraImageProcessing::EEffectMonochrome);
			InfoMessage(KImageEffect);
			}
		}

	CleanupStack::PopAndDestroy(2); //supportedTransforms, imageprocess
	}

/**
Displays a message in the system default corner of the screen.
The message disappears after a 0.5 seconds.
@param TDesC& aMsg	A descriptor message
*/
void CCameraAppUi::InfoMessage(const TDesC& aMsg)
	{
	iEikonEnv->InfoMsg(aMsg);
	User::After(500000); // pause .5 seconds
	}

/**
Displays a message in the system default corner of the screen.
The message disappears after a 0.5 seconds.
@param TInt aError				Error value
@param const TDesC& aSuccessMsg	A descriptor message indicating success
@param const TDesC& aErrMsg		A descriptor message indicating failure
*/
void CCameraAppUi::InfoMessage(TInt aError, const TDesC& aSuccessMsg, const TDesC& aErrMsg)
	{
	if (aError==KErrNone) iEikonEnv->InfoMsg(aSuccessMsg); else iEikonEnv->InfoMsg(aErrMsg);
	User::After(500000); // pause .5 seconds
	}

