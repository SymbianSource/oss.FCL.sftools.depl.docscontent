// Copyright (c) 2008-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
// This code demonstrates various imagetransformations available in Jpeg Tools and Squeeze 
// modules of ICL 
// Note 1: For demonstration purposes we create a client side active object which can 
// handle the asynchronous request to transform the image. In a standard application the asynchronous
// call would be made passing in a TRequestStatus object associate with an active object
// which is part of that application. We would return to the main UI processing thread in 
// which an active scheduler is running and wait for the asynchronous request to complete. In 
// this demonstration we need to manually start the active scheduler.
// Note 2: Starts the active scheduler - this is for demonstration purposes. See Note 1:
//





/**
 @file 
*/

#include "iclexample.h"

#include <imagetransform.h>
#include <icl/squeezetransformextension.h>
#include <icl/orientationtransformextension.h>
#include <icl/overlaytransformextension.h>
#include <iclexifimageframe.h>
#include <imageframe.h>
#include <imageconversion.h>
	

const TUid KImageFramePluginUid = {0x101F7C60};

/**
Demonstrates how to squeeze an image from a file to a file

@param aSrcFileName  The specified file where the image is stored
@param aDestFileName  The destination file to store the squeezed image

@leave KErrNotFound  Either the appropriate plugin for this file hasn't been found, or the file itself is missing
@leave KErrCorrupt  The plugin cannot interpret data
@leave KErrNotSupported The plugin does not support squeezing for this image
*/
void CIclExample::SqueezeJpgFileToFileL(const TDesC& aSrcFileName, const TDesC& aDestFileName)
	{
	// Create CImageTransform object and push it on to the cleanup stack
	CImageTransform* imageTransform = CImageTransform::NewL(iFs);
	CleanupStack::PushL(imageTransform);

	imageTransform->SetSourceFilenameL(aSrcFileName);
	imageTransform->SetDestFilenameL(aDestFileName);
	imageTransform->SetTransformationsL(CImageTransform::ESqueeze);
	imageTransform->SetOptionsL(CImageTransform::EIgnoreExifMetadataProcessing);
	imageTransform->SetupL();

	TUid lSqUid = {KUidSqueezeTransformExtension	};
	TInt err = KErrNone;
	CSqueezeTransformExtension* lSqExt = static_cast<CSqueezeTransformExtension*>(imageTransform->Extension(lSqUid, err));
	if(!lSqExt)
		{
		User::Leave(err);
		}

	// Squeeze by 20% of size in bytes
	TInt squeezeRate = 20;
	RFile file;
	User::LeaveIfError(file.Open(iFs, aSrcFileName, EFileRead));
	TInt filesize;
	User::LeaveIfError(file.Size(filesize));
	file.Close();
	TInt maxdestsize = filesize - ( (filesize * squeezeRate)/100 );

	// Set the desired max size of the squeezed file on the squeeze extension
	lSqExt->SetDestSizeInBytes(maxdestsize);

	// Call Transform() function of CImageTransform for image transform operation
	// See Note 1
	CActiveListener* activeListener = CreateAndInitializeActiveListenerLC();

	// Call Transform() function of CImageTransform for image transform operation
	imageTransform->Transform(activeListener->iStatus);

	// See Note 2
	CActiveScheduler::Start();
	User::LeaveIfError(activeListener->iStatus.Int());


	CleanupStack::PopAndDestroy(2); // activeListener, imageTransform 
	}


/**
Demonstrates how to squeeze an image from a buffer to a buffer

@param aSrcFileName  The specified file where the image is stored
@param aDestFileName  The destination file to store the squeezed image

@leave KErrNotFound  Either the appropriate plugin for this file hasn't been found, or the file itself is missing
@leave KErrCorrupt  The plugin cannot interpret data
@leave KErrNotSupported The plugin does not support squeezing for this image
*/
void CIclExample::SqueezeJpgBufferToBufferL(const TDesC& aSrcFileName, const TDesC& aDestFileName)
	{
	TPtr8 imageFromFilePtr = LoadImageIntoMemoryLC(aSrcFileName);
	HBufC8* destData = NULL;

	// Create CImageTransform object and push it on to the cleanup stack
	CImageTransform* imageTransform = CImageTransform::NewL(iFs);
	CleanupStack::PushL(imageTransform);

	imageTransform->SetSourceDataL(imageFromFilePtr);
	imageTransform->SetDestDataL(destData);
	imageTransform->SetTransformationsL(CImageTransform::ESqueeze);
	imageTransform->SetupL();

	TUid lSqUid = {KUidSqueezeTransformExtension	};
	TInt err = KErrNone;
	CSqueezeTransformExtension* lSqExt = static_cast<CSqueezeTransformExtension*>(imageTransform->Extension(lSqUid, err));
	if(!lSqExt)
		{
		User::Leave(err);
		}

	// Squeeze by 5% of size in bytes
	TInt squeezeRate = 5;
	RFile file;
	User::LeaveIfError(file.Open(iFs, aSrcFileName, EFileRead));
	TInt filesize;
	User::LeaveIfError(file.Size(filesize));
	file.Close();
	TInt maxdestsize = filesize - ( (filesize * squeezeRate)/100 );

	// Set the desired max size of the squeezed file on the squeeze extension
	lSqExt->SetDestSizeInBytes(maxdestsize);

	// Call Transform() function of CImageTransform for image transform operation
	// See Note 1
	CActiveListener* activeListener = CreateAndInitializeActiveListenerLC();

	// Call Transform() function of CImageTransform for image transform operation
	imageTransform->Transform(activeListener->iStatus);

	// See Note 2
	CActiveScheduler::Start();
	User::LeaveIfError(activeListener->iStatus.Int());
	
	// write the descriptor to the output file
	User::LeaveIfError(file.Replace(iFs, aDestFileName, EFileWrite));
	file.Write(*destData);
	file.Close();
	delete destData;

	CleanupStack::PopAndDestroy(3); // activeListener, imageTransform, image 
	}


/**
Demonstrates how to auto-squeeze an image from a file to a file

@param aSrcFileName  The specified file where the image is stored
@param aDestFileName  The destination file to store the squeezed image

@leave KErrNotFound  Either the appropriate plugin for this file hasn't been found, or the file itself is missing
@leave KErrCorrupt  The plugin cannot interpret data
@leave KErrNotSupported The plugin does not support squeezing for this image
*/
void CIclExample::AutoSqueezeJpgFileToFileL(const TDesC& aSrcFileName, const TDesC& aDestFileName)
	{
	// Create CImageTransform object and push it on to the cleanup stack
	CImageTransform* imageTransform = CImageTransform::NewL(iFs);
	CleanupStack::PushL(imageTransform);

	imageTransform->SetSourceFilenameL(aSrcFileName);
	imageTransform->SetDestFilenameL(aDestFileName);
	imageTransform->SetTransformationsL(CImageTransform::ESqueeze);
	imageTransform->SetupL();

	TUid lSqUid = {KUidSqueezeTransformExtension	};
	TInt err = KErrNone;
	CSqueezeTransformExtension* lSqExt = static_cast<CSqueezeTransformExtension*>(imageTransform->Extension(lSqUid, err));
	if(!lSqExt)
		{
		User::Leave(err);
		}

	// Squeeze by 5% of size in bytes
	TInt squeezeRate = 5;
	RFile file;
	User::LeaveIfError(file.Open(iFs, aSrcFileName, EFileRead));
	TInt filesize;
	User::LeaveIfError(file.Size(filesize));
	file.Close();
	TInt maxdestsize = filesize - ( (filesize * squeezeRate)/100 );

	// Get the pixel size of the image
	CJPEGImageFrameDecoder *decoder = NULL;
	decoder= static_cast<CJPEGImageFrameDecoder*> (CImageDecoder::FileNewL(iFs, aSrcFileName, CImageDecoder::EOptionNone, KNullUid, KNullUid, KImageFramePluginUid));
	const TFrameInfo* frameInfo = &decoder->FrameInfo();;
	TSize imgSizeInPixels = frameInfo->iOverallSizeInPixels;
	delete decoder;

	// Max pixel size may be 10% of the original size
	TSize maxImageSizeInPixels;
	maxImageSizeInPixels.iWidth = imgSizeInPixels.iWidth - (imgSizeInPixels.iWidth *10) /100;
	maxImageSizeInPixels.iHeight = imgSizeInPixels.iHeight - (imgSizeInPixels.iHeight *10) /100;

	// Min pixel size may be 30% of the original size
	TSize minImageSizeInPixels;
	minImageSizeInPixels.iWidth = imgSizeInPixels.iWidth - (imgSizeInPixels.iWidth *30) /100;
	minImageSizeInPixels.iHeight = imgSizeInPixels.iHeight - (imgSizeInPixels.iHeight *30) /100;

	// Set the various desired parmas for the auto squeeze
	TAdvancedSqueezeParams  squeezeAutoResizeParams;
	squeezeAutoResizeParams.iMaxDestSizeInBytes = maxdestsize;
	squeezeAutoResizeParams.iResizeAction = TAdvancedSqueezeParams::EAutoResizeActionPrioritizeLargeImageSize;
	squeezeAutoResizeParams.iMinImageSize = minImageSizeInPixels;
	squeezeAutoResizeParams.iMaxImageSize = maxImageSizeInPixels;
	squeezeAutoResizeParams.iSamplingUid = KUidSamplingColor422;
	squeezeAutoResizeParams.iMinEncodingQuality = 0.8f;
	// Set the advance params to the squeeze extension
	lSqExt->SetAdvancedSqueezeModeL(&squeezeAutoResizeParams);


	// Call Transform() function of CImageTransform for image transform operation
	// See Note 1
	CActiveListener* activeListener = CreateAndInitializeActiveListenerLC();

	// Call Transform() function of CImageTransform for image transform operation
	imageTransform->Transform(activeListener->iStatus);

	// See Note 2
	CActiveScheduler::Start();
	User::LeaveIfError(activeListener->iStatus.Int());


	CleanupStack::PopAndDestroy(2); // activeListener, imageTransform 
	}
	
/**
Demonstrates how to rotate an image from a file to a file

@param aSrcFileName  The specified file where the image is stored
@param aDestFileName  The destination file to store the squeezed image

@leave KErrNotFound  Either the appropriate plugin for this file hasn't been found, or the file itself is missing
@leave KErrCorrupt  The plugin cannot interpret data
@leave KErrNotSupported The plugin does not support squeezing for this image
*/
void CIclExample::RotateJpgFileToFileL(const TDesC& aSrcFileName, const TDesC& aDestFileName)
	{
	// Create CImageTransform object and push it on to the cleanup stack
	CImageTransform* imageTransform = CImageTransform::NewL(iFs);
	CleanupStack::PushL(imageTransform);

	imageTransform->SetSourceFilenameL(aSrcFileName);
	imageTransform->SetDestFilenameL(aDestFileName);
	imageTransform->SetTransformationsL(CImageTransform::EOrientation);
	imageTransform->SetupL();

	TUid lRotateUid = {KUidOrientationTransformExtension	};
	TInt err = KErrNone;
	COrientationTransformExtension* lRotateExt = static_cast<COrientationTransformExtension*>(imageTransform->Extension(lRotateUid, err));
	if(!lRotateExt)
		{
		User::Leave(err);
		}
	// Rotate by 90 degree of size in bytes
	lRotateExt->SetOrientationL(COrientationTransformExtension::ERotation90DegreesClockwise);

	// Call Transform() function of CImageTransform for image transform operation
	// See Note 1
	CActiveListener* activeListener = CreateAndInitializeActiveListenerLC();

	// Call Transform() function of CImageTransform for image transform operation
	imageTransform->Transform(activeListener->iStatus);

	// See Note 2
	CActiveScheduler::Start();
	User::LeaveIfError(activeListener->iStatus.Int());


	CleanupStack::PopAndDestroy(2); // activeListener, imageTransform 
	}


/**
Demonstrates how to blend a jpg data in file to a file to a file

@param aSrcFileName  The specified file where the image is stored
@param aOverlayFileName  The file containing the overlay image 
@param aDestFileName  The destination file to store the squeezed image

@leave KErrNotFound  Either the appropriate plugin for this file hasn't been found, or the file itself is missing
@leave KErrCorrupt  The plugin cannot interpret data
@leave KErrNotSupported The plugin does not support squeezing for this image
*/
void CIclExample::OverlayJpgDataToJpgFileToFileL(const TDesC& aSrcFileName, const TDesC& aOverlayFileName, const TDesC& aDestFileName)
	{
	// Create CImageTransform object and push it on to the cleanup stack
	CImageTransform* imageTransform = CImageTransform::NewL(iFs);
	CleanupStack::PushL(imageTransform);

	imageTransform->SetSourceFilenameL(aSrcFileName);
	imageTransform->SetDestFilenameL(aDestFileName);
	imageTransform->SetTransformationsL(CImageTransform::EOverlay);
	imageTransform->SetupL();

	TUid lRotateUid = {KUidOverlayTransformExtension	};
	TInt err = KErrNone;
	COverlayTransformExtension* lOverlayExt = static_cast<COverlayTransformExtension*>(imageTransform->Extension(lRotateUid, err));
	if(!lOverlayExt)
		{
		User::Leave(err);
		}
	// Set the position
	TPoint position(0,0);
	lOverlayExt->SetPosition(position);

	// Set the overlay file
	TPtr8 imageFromFilePtr = LoadImageIntoMemoryLC(aOverlayFileName);
	lOverlayExt->SetOverlayDataL(imageFromFilePtr, KImageTypeJPGUid);
	
	// Call Transform() function of CImageTransform for image transform operation
	// See Note 1
	CActiveListener* activeListener = CreateAndInitializeActiveListenerLC();

	// Call Transform() function of CImageTransform for image transform operation
	imageTransform->Transform(activeListener->iStatus);

	// See Note 2
	CActiveScheduler::Start();
	User::LeaveIfError(activeListener->iStatus.Int());


	CleanupStack::PopAndDestroy(3); // activeListener, overlay image, imageTransform 
	}

/**
Demonstrates how to blend a png image in file to a jpg file to a file

@param aSrcFileName  The specified file where the image is stored
@param aOverlayFileName  The file containing the overlay png image 
@param aDestFileName  The destination file to store the squeezed image

@leave KErrNotFound  Either the appropriate plugin for this file hasn't been found, or the file itself is missing
@leave KErrCorrupt  The plugin cannot interpret data
@leave KErrNotSupported The plugin does not support squeezing for this image
*/
void CIclExample::OverlayPngFileToJpgFileToFileL(const TDesC& aSrcFileName, const TDesC& aOverlayFileName, const TDesC& aDestFileName)
	{
	// Create CImageTransform object and push it on to the cleanup stack
	CImageTransform* imageTransform = CImageTransform::NewL(iFs);
	CleanupStack::PushL(imageTransform);

	imageTransform->SetSourceFilenameL(aSrcFileName);
	imageTransform->SetDestFilenameL(aDestFileName);
	imageTransform->SetTransformationsL(CImageTransform::EOverlay);
	imageTransform->SetupL();

	TUid lOverlayUid = {KUidOverlayTransformExtension	};
	TInt err = KErrNone;
	COverlayTransformExtension* lOverlayExt = static_cast<COverlayTransformExtension*>(imageTransform->Extension(lOverlayUid, err));
	if(!lOverlayExt)
		{
		User::Leave(err);
		}
	// Set the position
	TPoint position(0,0);
	lOverlayExt->SetPosition(position);

	// Set the overlay data
	TUid pngUid = KImageTypePNGUid;
	lOverlayExt->SetOverlayFileL(aOverlayFileName, pngUid);

	// Call Transform() function of CImageTransform for image transform operation
	// See Note 1
	CActiveListener* activeListener = CreateAndInitializeActiveListenerLC();

	// Call Transform() function of CImageTransform for image transform operation
	imageTransform->Transform(activeListener->iStatus);

	// See Note 2
	CActiveScheduler::Start();
	User::LeaveIfError(activeListener->iStatus.Int());


	CleanupStack::PopAndDestroy(2); // activeListener, overlay image, imageTransform 
	}


/**
Demonstrates how to blend a bitmap to a file to a file

@param aSrcFileName  The specified file where the image is stored
@param aOverlayFileName  The file containing the overlay btimap image 
@param aDestFileName  The destination file to store the squeezed image

@leave KErrNotFound  Either the appropriate plugin for this file hasn't been found, or the file itself is missing
@leave KErrCorrupt  The plugin cannot interpret data
@leave KErrNotSupported The plugin does not support squeezing for this image
*/
void CIclExample::OverlayBmpDataToJpgFileToFileL(const TDesC& aSrcFileName, const TDesC& aOverlayFileName, const TDesC& aDestFileName)
	{
	// Create CImageTransform object and push it on to the cleanup stack
	CImageTransform* imageTransform = CImageTransform::NewL(iFs);
	CleanupStack::PushL(imageTransform);

	imageTransform->SetSourceFilenameL(aSrcFileName);
	imageTransform->SetDestFilenameL(aDestFileName);
	imageTransform->SetTransformationsL(CImageTransform::EOverlay);
	imageTransform->SetupL();

	TUid lRotateUid = {KUidOverlayTransformExtension	};
	TInt err = KErrNone;
	COverlayTransformExtension* lOverlayExt = static_cast<COverlayTransformExtension*>(imageTransform->Extension(lRotateUid, err));
	if(!lOverlayExt)
		{
		User::Leave(err);
		}
	// Set the position
	TPoint position(0,0);
	lOverlayExt->SetPosition(position);

	// Set the overlay bitmap
	CFbsBitmap* overlayBitmap = new (ELeave) CFbsBitmap;
	CleanupStack::PushL(overlayBitmap);	
	User::LeaveIfError(overlayBitmap->Load(aOverlayFileName));
	lOverlayExt->SetOverlayImageL(*overlayBitmap);

	
	// Call Transform() function of CImageTransform for image transform operation
	// See Note 1
	CActiveListener* activeListener = CreateAndInitializeActiveListenerLC();

	// Call Transform() function of CImageTransform for image transform operation
	imageTransform->Transform(activeListener->iStatus);

	// See Note 2
	CActiveScheduler::Start();
	User::LeaveIfError(activeListener->iStatus.Int());


	CleanupStack::PopAndDestroy(3); // activeListener, overlay bitmap, imageTransform 
	}

