// iclencodeexample.cpp
// Copyright (c) 2007-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
// 
//


/** 
@file 

This code demonstrates various encoding,rotating and scaling functionality of images in 
ICL component
*/

/**
Note 1: For demonstration purposes we create a client side active object which can 
handle the asynchronous request to decode the image. In a standard application the asynchronous
call would be made passing in a TRequestStatus object associate with an active object
which is part of that application. We would return to the main UI processing thread in 
which an active scheduler is running and wait for the asynchronous request to complete. In 
this demonstration we need to manually start the active scheduler.
*/

/**
Note 2: Starts the active scheduler - this is for demonstration purposes. See Note 1:
*/

#include "iclexample.h"
#include <gifscaler.h>
#include <imagetransform.h>
	
/**
Demonstrates how to encode an image into a descriptor.

@param aFileName  The specified file where the image is stored

@leave KEComErrNoInterfaceIdentified  ECom could not find the specified interface
@leave KErrNotFound  Either the appropriate plugin decoder for this file hasn't been found, or the file itself is missing
@leave KErrCorrupt  The plugin cannot interpret data
@leave KErrUnderflow An underflow in some operation
*/
void CIclExample::EncodeBitmapToDescriptorL(const TDesC& aFileName)	
	{
	HBufC8* encodedImageDescriptor = NULL;

	// Create the encoder, passing a buffer to store the encoded image
	CImageEncoder* encoder = CImageEncoder::DataNewL(encodedImageDescriptor, CImageEncoder::EOptionNone,KImageTypeGIFUid);
	CleanupStack::PushL(encoder);

	// Create a CFbsBitmap to store the source bitmap to encode
	CFbsBitmap* sourceBitmap = new(ELeave) CFbsBitmap;
	CleanupStack::PushL(sourceBitmap);

	User::LeaveIfError(sourceBitmap->Create(TSize(20,30), EColor16M));
	User::LeaveIfError(sourceBitmap->Load(aFileName));

	// See Note 1
	CActiveListener* activeListener = CreateAndInitializeActiveListenerLC();

	// Convert the image
	encoder->Convert(&activeListener->iStatus, *sourceBitmap);

	// See Note 2
	CActiveScheduler::Start();
	User::LeaveIfError(activeListener->iStatus.Int());// encode complete either display the image or report an error.


	CleanupStack::PopAndDestroy(3); // encoder, sourceBitmap and activeListener


	// We can use the descriptor here

	// And as we took ownership back, we need to push into the cleanup stack to make sure no
	// memory leaks take place if any leave later

	CleanupDeletePushL(encodedImageDescriptor);


	// Just verifying the presence of some output. 

	RFile file;
	
	User::LeaveIfError(file.Replace(iFs, _L("c:\\ICLExample\\encodeddescriptor.mbm"), EFileWrite)); 
	CleanupClosePushL(file);

	User::LeaveIfError(file.Write(*encodedImageDescriptor));

	CleanupStack::PopAndDestroy(&file);


	CleanupStack::PopAndDestroy(encodedImageDescriptor);
	}

	
/**
Demonstrates how to encode a JPEG thumbnail of an image.

@param aFileName  The specified file where the image is stored

@leave KEComErrNoInterfaceIdentified  ECom could not find the specified interface
@leave KErrNotFound  Either the appropriate plugin decoder for this file hasn't been found, or the file itself is missing
@leave KErrCorrupt  The plugin cannot interpret data
@leave KErrUnderflow  An underflow in some operation
*/
void CIclExample::EncodeImageWithThumbnailL(const TDesC& aFileName)
	{
	HBufC8* encodedImageDescriptor = NULL;

	// Create the encoder, passing a buffer to store the encoded image
	CImageEncoder* encoder = CImageEncoder::DataNewL(encodedImageDescriptor, CImageEncoder::EOptionNone, KImageTypeJPGUid);
	CleanupStack::PushL(encoder);

	// Set the image type to thumbnail 
	encoder->SetThumbnail(ETrue);

	// Create a bitmap to access the thumbnail
	CFbsBitmap* sourceBitmap = new(ELeave) CFbsBitmap;
	CleanupStack::PushL(sourceBitmap);

	User::LeaveIfError(sourceBitmap->Create(TSize(250,200), EColor16M));
	User::LeaveIfError(sourceBitmap->Load(aFileName));

	// See Note 1
	CActiveListener* activeListener = CreateAndInitializeActiveListenerLC();

	// Convert the image
	encoder->Convert(&activeListener->iStatus, *sourceBitmap);

	// See Note 2
	CActiveScheduler::Start();
	User::LeaveIfError(activeListener->iStatus.Int()); // access to thumbnail complete either display the image or report an error.


	CleanupStack::PopAndDestroy(3); // encoder, sourceBitmap and activeListener
	

	// We can use the descriptor here
	
	// And as we took ownership back, we need to push into the cleanup stack to make sure no
	// memory leaks take place if any leave later

	CleanupDeletePushL(encodedImageDescriptor);
	

    // Just verifying the presence of some output.

	RFile file;
	
	User::LeaveIfError(file.Replace(iFs, _L("c:\\ICLExample\\encodedbitmapwiththumbnail.mbm"), EFileWrite)); 
	CleanupClosePushL(file);

	User::LeaveIfError(file.Write(*encodedImageDescriptor));

	CleanupStack::PopAndDestroy(&file);


	CleanupStack::PopAndDestroy(encodedImageDescriptor);
	}


/**
Demonstrates how to set the exif metadata of an image.

@param aFileName  The specified file where the image is stored

@leave KEComErrNoInterfaceIdentified  ECom could not find the specified interface
@leave KErrNotFound  Either the appropriate plugin decoder for this file hasn't been found, or the file itself is missing
@leave KErrCorrupt  The plugin cannot interpret data
@leave KErrArgument  An argument is out of range 
@leave KErrNotSupported  Functionality is not supported 
*/       
void CIclExample::SettingExifMetadataL(const TDesC& aFileName)	
	{
	HBufC8* encodedImageDescriptor = NULL;

	// Create the encoder, passing a buffer to store the encoded image
	CJPEGExifEncoder* exifEncoder = static_cast<CJPEGExifEncoder*>(CImageEncoder::DataNewL(encodedImageDescriptor, CImageEncoder::EOptionNone, KImageTypeJPGUid));
	CleanupStack::PushL(exifEncoder);

	// Create a MExifMetadata object and initialize it with the metadata associated with CJPEGexifEncoder  
	MExifMetadataWriter* metaData = exifEncoder->ExifMetadata(); 

	// Create a TExifWriterUtility object to write the metadata in to the image
	TExifWriterUtility exifWriteUtility(metaData);

	HBufC8*	buf8ParamWriteVersion = KBuf8ParamWriteVersion().AllocLC();
	
	User::LeaveIfError(exifWriteUtility.SetImageDescription(buf8ParamWriteVersion));

	CleanupStack::PopAndDestroy(buf8ParamWriteVersion);


	// Create a bitmap 
	CFbsBitmap* sourceBitmap = new(ELeave) CFbsBitmap;
	CleanupStack::PushL(sourceBitmap);

	User::LeaveIfError(sourceBitmap->Create(TSize(250,200), EColor16M));
	User::LeaveIfError(sourceBitmap->Load(aFileName));
		
	// See Note 1
	CActiveListener* activeListener = CreateAndInitializeActiveListenerLC();

	// Convert the image
	exifEncoder->Convert(&activeListener->iStatus, *sourceBitmap);

	// See Note 2
	CActiveScheduler::Start();
	User::LeaveIfError(activeListener->iStatus.Int());


	CleanupStack::PopAndDestroy(3); // encoder, sourceBitmap and activeListener


	// We can use the descriptor here

	// And as we took ownership back, we need to push into the cleanup stack to make sure no
	// memory leaks take place if any leave later

	CleanupDeletePushL(encodedImageDescriptor);


	// Just verifying the presence of some output.

	RFile file;
	
	User::LeaveIfError(file.Replace(iFs, _L("c:\\ICLExample\\settingexifdescriptor.mbm"), EFileWrite)); 
	CleanupClosePushL(file);

	User::LeaveIfError(file.Write(*encodedImageDescriptor));

	CleanupStack::PopAndDestroy(&file);
	

	CleanupStack::PopAndDestroy(encodedImageDescriptor);
	}


/**
Demonstrates how to rotate a bitmap.

@param aFileName  The specified file where the image is stored

@leave ENoSourceBitmap  Invalid source bitmap
*/
void CIclExample::RotateBitmapL(const TDesC& aFileName)
	{
	// Create a CBitmapRotator object and push it on the cleanup stack 
	CBitmapRotator* rotator = CBitmapRotator::NewL();
	CleanupStack::PushL(rotator);

	// Create a source bitmap 
	CFbsBitmap* sourceBitmap = new(ELeave) CFbsBitmap;
	CleanupStack::PushL(sourceBitmap);

	User::LeaveIfError(sourceBitmap->Create(TSize(15,20), EColor16M));
	User::LeaveIfError(sourceBitmap->Load(aFileName));

	// See Note 1
	CActiveListener* activeListener = CreateAndInitializeActiveListenerLC();

	// Rotate the bitmap through the specified angle
	rotator->Rotate(&activeListener->iStatus, *sourceBitmap, CBitmapRotator::ERotation180DegreesClockwise);

	// See Note 2
	CActiveScheduler::Start();
	User::LeaveIfError(activeListener->iStatus.Int());

	// Just verifying the presence of some output.
	sourceBitmap->Save(_L("c:\\ICLExample\\rotatedbitmap.mbm"));


	CleanupStack::PopAndDestroy(3); // rotator, sourceBitmap and activeListener
	}


/**
Demonstrates how to scale a bitmap including optional selection of low memory
and quality algorithms.

@param aFileName  The specified file where the image is stored

@leave KErrNotSupported  Functionality is not supported 
*/
void CIclExample::ScaleBitmapL(const TDesC& aFileName)
	{
	// Create a source bitmap object and push it on to the cleanup stack
	CFbsBitmap* sourceBitmap = new(ELeave) CFbsBitmap;
	CleanupStack::PushL(sourceBitmap);

	User::LeaveIfError(sourceBitmap->Create(TSize(100,100), EGray2));
	User::LeaveIfError(sourceBitmap->Load(aFileName));

	// Create a destination bitmap  object and push it on to the cleanup stack
	CFbsBitmap* destBitmap = new(ELeave) CFbsBitmap;
	CleanupStack::PushL(destBitmap);

	User::LeaveIfError(destBitmap->Create(TSize(20,30), EColor16M));

	// Scale the bitmap with old algorithm
	// Create a CBitmapScaler object and push it on to the cleanup stack
	CBitmapScaler* scaler = CBitmapScaler::NewL();
	CleanupStack::PushL(scaler);

	// See Note 1
	CActiveListener* activeListener = CreateAndInitializeActiveListenerLC();

	// Scale the bitmap using low memory and medium quality algorithm
	scaler->UseLowMemoryAlgorithm(ETrue);
	scaler->SetQualityAlgorithm(CBitmapScaler::EMediumQuality);

	// Call the scale() function of CBitmapScaler to perform the scaling operation with optional selection of low memory 
	scaler->Scale(&activeListener->iStatus, *sourceBitmap, *destBitmap, EFalse);	

	// See Note 2
	CActiveScheduler::Start();
	User::LeaveIfError(activeListener->iStatus.Int());// scale complete either display the image or report an error.

	// Just verifying the presence of some output. Descriptor can also be used instead

	destBitmap->Save(_L("c:\\ICLExample\\scaledbitmap.mbm"));


	CleanupStack::PopAndDestroy(4); // activeListener, scaler, destBitmap and sourceBitmap
	}


/**
1) Specifies the name of the source file containing the image to transform
2) Defines the destination descriptor
3) Resize using CImageTransform

@param aFileName  The specified file  where the image is stored

@leave KErrArgument  An argument is out of range
@leave KErrNotFound  Either the appropriate plugin decoder for this file hasn't been found, or the file itself is missing
*/ 
void CIclExample::SetSourceDestinationandResizeL(const TDesC& aFileName)
	{
	HBufC8* desData = NULL;

	// Create CImageTransform object and push it on to the cleanup stack
	CImageTransform* imageTransform = CImageTransform::NewL(iFs);
	CleanupStack::PushL(imageTransform);

	imageTransform->SetSourceFilenameL(aFileName);
	imageTransform->SetDestDataL(desData);
	imageTransform->SetDestSizeInPixelsL(TSize(160, 120), ETrue);
	imageTransform->SetupL();

	// See Note 1
	CActiveListener* activeListener = CreateAndInitializeActiveListenerLC();

	// Call Transform() function of CImageTransform for image transform operation
	imageTransform->Transform(activeListener->iStatus);

	// See Note 2
	CActiveScheduler::Start();
	// destData ownership is on CLI side if something goes wrong
	User::LeaveIfError(activeListener->iStatus.Int());


	CleanupStack::PopAndDestroy(2); // imageTransform and activeListener


	// We can use the destination data here

	// And as we took ownership back, we need to push into the cleanup stack to make sure no
	// memory leaks take place if any leave later

	CleanupDeletePushL(desData);


	// Just verifying the presence of some output.

	RFile file;
	
	User::LeaveIfError(file.Replace(iFs, _L("c:\\ICLExample\\destdata.mbm"), EFileWrite)); 
	CleanupClosePushL(file);

	User::LeaveIfError(file.Write(*desData));

	CleanupStack::PopAndDestroy(&file);

	
	CleanupStack::PopAndDestroy(desData);
	}


/**
1) Specifies the source descriptor containing the image to transform
2) Specifies the name of the destination file where the transformed image 
is to be written to.
3) Transforms the bitmap
4) Either specify that the original image data is to be preserved, as far as possible, 
or that the image data should be re-encoded to produce a more size-efficient image. 

@param aFileName  The specified file  where the image is stored

@leave KErrArgument  An argument is out of range
*/ 
void CIclExample::SettingWithUseOfPreserveImageDataL(const TDesC& aFileName1,const TDesC& aFileName2)
	{
	TPtr8 imageFromFilePtr = LoadImageIntoMemoryLC(aFileName1);

	// Create CImageTransform object and push it on to the cleanup stack
	CImageTransform* imageTransform = CImageTransform::NewL(iFs);
	CleanupStack::PushL(imageTransform);

	imageTransform->SetSourceDataL(imageFromFilePtr);
	imageTransform->SetDestFilenameL(aFileName2);
	imageTransform->SetDestSizeInPixelsL(TSize(160, 120), ETrue);
	imageTransform->SetPreserveImageData(ETrue);	
	imageTransform->SetupL();

	// Call Transform() function of CImageTransform for image transform operation
	// See Note 1
	CActiveListener* activeListener = CreateAndInitializeActiveListenerLC();

	// Call Transform() function of CImageTransform for image transform operation
	imageTransform->Transform(activeListener->iStatus);

	// See Note 2
	CActiveScheduler::Start();
	User::LeaveIfError(activeListener->iStatus.Int());


	CleanupStack::PopAndDestroy(3); // activeListener, imageTransform and imageInMemory
	}

	
/**
Demonstrates how to add thumbnail to JPEG file.

@param aSrcFileName  The specified file  where the source image is stored
@param aDesFileName  The specified

@leave KErrArgument  An argument is out of range
@leave KErrNotFound  Either the appropriate plugin decoder for this file hasn't been found, or the file itself is missing
@leave KErrNotSupported  Functionality is not supported
*/ 
void CIclExample::AddThumbnailToJpegFileL(const TDesC& aSrcFileName, const TDesC& aDesFileName)
	{
	// Create a CImageTransform object and push it on to the cleanup stack
	CImageTransform* imageTransform = NULL;
	
	imageTransform = CImageTransform::NewL(iFs);
	CleanupStack::PushL(imageTransform);

	imageTransform->SetSourceFilenameL(aSrcFileName);
	imageTransform->SetDestFilenameL(aDesFileName);
	imageTransform->SetDestSizeInPixelsL(TSize(160, 120), ETrue);
	imageTransform->SetOptionsL(CImageTransform::EThumbnail);
	imageTransform->SetupL();

	// encode the image to add thumbnail
	// See Note 1
	CActiveListener* activeListener = CreateAndInitializeActiveListenerLC();

	// Call Transform() function of CImageTransform for image transform operation
	imageTransform->Transform(activeListener->iStatus);

	// See Note 2
	CActiveScheduler::Start();
	User::LeaveIfError(activeListener->iStatus.Int());


	CleanupStack::PopAndDestroy(2); // activeListener and imageTransform
	}


/**
Demonstrates how to add Exif data to a JPEG file.

@param aFileName  The specified file where the image is stored

@leave KEComErrNoInterfaceIdentified  ECom could not find the specified interface
@leave KErrNotFound  Either the appropriate plugin decoder for this file hasn't been found, or the file itself is missing
@leave KErrArgument  An argument is out of range 
@leave KErrNotSupported  Functionality is not supported
@leave KErrOverflow  An overflow in some operation
*/ 
void CIclExample::AddExifDataToJpegFileL(const TDesC& aFileName)
	{	
	HBufC8* encodedImageDescriptor = NULL;

	// Create the encoder, passing a buffer to store the encoded image
	CJPEGExifEncoder* exifEncoder = static_cast<CJPEGExifEncoder*>(CImageEncoder::DataNewL(encodedImageDescriptor, CImageEncoder::EOptionNone, KImageTypeJPGUid));
	CleanupStack::PushL(exifEncoder);

	// Create a MExifMetadata object and initializes to metadata associated with CJPEGexifEncoder  
	MExifMetadataWriter* metaData = exifEncoder->ExifMetadata(); 

	// Create a TExifWriterUtility object to write the metadata in to the image
	TExifWriterUtility exifWriteUtility(metaData);

	HBufC8*	buf8ParamWriteVersion = KBuf8ParamWriteVersion().AllocLC();
	
	User::LeaveIfError(exifWriteUtility.SetImageDescription(buf8ParamWriteVersion));

	CleanupStack::PopAndDestroy(buf8ParamWriteVersion);


	// Create a CFbsBitmap to store the source bitmap to encode
	CFbsBitmap* sourceBitmap = new(ELeave) CFbsBitmap;
	CleanupStack::PushL(sourceBitmap);
	
	User::LeaveIfError(sourceBitmap->Create(TSize(20,30), EColor16M));
	User::LeaveIfError(sourceBitmap->Load(aFileName));

	// Create CFrameImageData object and push it on the cleanup stack	
	CFrameImageData* frameImageData = CFrameImageData::NewL();
	CleanupStack::PushL(frameImageData);

	// See Note 1
	CActiveListener* activeListener = CreateAndInitializeActiveListenerLC();

	// Convert the image
	exifEncoder->Convert(&activeListener->iStatus, *sourceBitmap, frameImageData);

	// See Note 2
	CActiveScheduler::Start();
	User::LeaveIfError(activeListener->iStatus.Int()); // encode complete either display the image or report an error.


	// Just verifying the presence of some output.
	sourceBitmap->Save(_L("c:\\ICLExample\\addexifbitmap.mbm"));


	CleanupStack::PopAndDestroy(4); // activeListener, frameImageData, sourceBitmap and exifEncoder


	// We can use the descriptor here
	
	// And as we took ownership back, we need to push into the cleanup stack to make sure no
	// memory leaks take place if any leave later

	CleanupDeletePushL(encodedImageDescriptor);


	// Just verifying the presence of some output.

	RFile file;
	
	User::LeaveIfError(file.Replace(iFs, _L("c:\\ICLExample\\addexifdescriptor.mbm"), EFileWrite)); 
	CleanupClosePushL(file);

	User::LeaveIfError(file.Write(*encodedImageDescriptor));

	CleanupStack::PopAndDestroy(&file);


	CleanupStack::PopAndDestroy(encodedImageDescriptor);
	}


/**
Demonstrates how to apply rotation operation while encoding a bitmap to a jpeg.

@param aSrcFileName  Specifies the source bitmap containing the image to transform.
@param aDestFileName Specifies the destination file where the transformed image is to be written.

@leave KEComErrNoInterfaceIdentified  ECom could not find the specified interface
@leave KErrNotFound  Either the appropriate plugin decoder for this file hasn't been found, or the file itself is missing
@leave KErrCorrupt  The plugin cannot interpret data
@leave KErrUnderflow An underflow in some operation
*/
void CIclExample::EncodeBitmapToFileUsingOperationExtensionL(const TDesC& aSrcFileName, const TDesC& aDestFileName)
	{
	// Create the encoder, passing the filename. 
	// If the image is not recognised or valid then the call will leave with an error	
	CImageEncoder* jpegImageEncoder = CImageEncoder::FileNewL(iFs, aDestFileName, CImageEncoder::EOptionNone, KImageTypeJPGUid);
	CleanupStack::PushL(jpegImageEncoder);
	
	// Create a CFbsBitmap to store the source bitmap to encode
	CFbsBitmap* sourceBitmap = new(ELeave) CFbsBitmap;
	CleanupStack::PushL(sourceBitmap);

	User::LeaveIfError(sourceBitmap->Load(aSrcFileName));
	
	// Create operation extension
	TImageConvOperation* operation = jpegImageEncoder->OperationL();
	
	// Add Rotate 90degrees operation
	operation->AddOperationL(TImageConvOperation::ERotation90DegreesClockwise); 
	// NOTE: Multiple operations can be added
	
	// See Note 1
	CActiveListener* activeListener = CreateAndInitializeActiveListenerLC();

	// Convert the image
	jpegImageEncoder->Convert(&activeListener->iStatus, *sourceBitmap, NULL);

	// See Note 2
	CActiveScheduler::Start();
	User::LeaveIfError(activeListener->iStatus.Int());// encode complete either display the image or report an error.
	
	CleanupStack::PopAndDestroy(3, jpegImageEncoder); // jpegImageEncoder, sourceBitmap and activeListener
	}
