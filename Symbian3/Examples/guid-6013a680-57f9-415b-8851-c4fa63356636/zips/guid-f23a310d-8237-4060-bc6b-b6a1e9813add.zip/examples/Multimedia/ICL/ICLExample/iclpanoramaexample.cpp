// Copyright (c) 2008-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
// The code demonstrates panorama stitching functionality of CIclExample
//



/**
 @file
*/

#include "iclexample.h"
#include <panorama/panorama.h>

void CIclExample::BasicPanoramaStitchingL()
	{
	TSize imageSize(1200, 1000);
	
	TDirection direction = EPanoramaDirectionRight;
		
	//Lens parameters or internal camera characteristics should be available for the 
	//specific camera module in use. Here we use default values.
	TPanoramaLens lens;
		
	//Create transform. A transform is an approximate offset between each image.
	CPanoramaTransform* panTrans = CPanoramaTransform::NewL();
	CleanupStack::PushL(panTrans);
	
	//Create panorama object.This stitches the individual images together.
	CImagePanorama* panImage = CImagePanorama::NewL();
	CleanupStack::PushL(panImage);
		
	//Create panorama engine and set the lens and size
	panImage->InitializeL(imageSize, lens, direction);
		
	//Each file added is provided with an approximate translation. 
	//In this case there are 4 images.
	panTrans->SetTranslationL(TPoint(0, 0), imageSize);
	panImage->AddFileL(KTestFileName1, *panTrans);
		
	panTrans->SetTranslationL(TPoint(900, -30), imageSize);
	panImage->AddFileL(KTestFileName2, *panTrans);
		
	panTrans->SetTranslationL(TPoint(900, 60), imageSize);
	panImage->AddFileL(KTestFileName3, *panTrans);
	
	panTrans->SetTranslationL(TPoint(400, -30), imageSize);
	panImage->AddFileL(KTestFileName4, *panTrans);
		
	//The image size can be obtained before rendering (if required)
	TSize size;
	panImage->CurrentImageSizeL(size);
	
	//view the output image
	panImage->RenderL(KTestBSOutputFileName);

	CleanupStack::PopAndDestroy(2); //panTrans, panImage
	}
	
void CIclExample::ViewFinderImageTrackingL()
	{
	_LIT(KFileOutput, "c:\\ICLExample\\viewfinder%d.mbm");
	_LIT(KFileCapturedImage, "c:\\ICLExample\\pancapture%d.jpg");
	TInt i = 0;

	TSize imageSize(1200,1000);

    CFbsBitmap* bmp = new (ELeave) CFbsBitmap;
	CleanupStack::PushL(bmp);

	// get 1st viewfinder image from camera into bmp (detail excluded)
	
	// ####Begin exclude from OS Library example  
	// (for example purposes we have some prepared viewfinder images on disk)
	TFileName vfFileName;
    vfFileName.Format(KFileOutput(),i);
    User::LeaveIfError(bmp->Load(vfFileName));
	// ####End exclude from OS Library example  

	TSize bmpSize = bmp->SizeInPixels();

	CPanoramaTransform* panTrans = CPanoramaTransform::NewL();//create panorama transform
	CleanupStack::PushL(panTrans);

	CVFTracker* vfTracker = CVFTracker::NewL(); //create VFTracker and load the plugin
	CleanupStack::PushL(vfTracker);
		
	vfTracker->InitializeL(bmpSize); //Create VFTracker and set size

	CImagePanorama* panImage = CImagePanorama::NewL(); //create CImagePanorama object
	CleanupStack::PushL(panImage);
		
	TDirection direction = EPanoramaDirectionRight; //assign direction
		
	// Lens parameters or internal camera characteristics should be available for the 
	// specific camera module in use. Here we use default values.
	TPanoramaLens lens;
	panImage->InitializeL(imageSize, lens, direction); //initialise size, lens, direction and create panorama engine

	// get the first captured image from the camera as a starting point - its name is given in capturedFileName
	TFileName capturedFileName;
    capturedFileName.Format(KFileCapturedImage(),i);
	panImage->AddFileL(capturedFileName, *panTrans); //add the captured image

	do 
		{
		// give the next camera viewfinder image to the tracker	(details ommitted)
		vfTracker->RegisterImageL(*bmp, *panTrans); // register viewfinder image
		
		// check if we have a good overlap with the previous image
		if(vfTracker->IsTimeToCapture(direction, KPanoramaDefaultOverlap)) 
			{
			// capture the next image from the camera (details ommitted)
		    capturedFileName.Format(KFileCapturedImage(),i);
			
			panImage->AddFileL(capturedFileName, *panTrans); //add the captured image
			vfTracker->Reset(); //reset the VFTracker object
			}
	
		// ####Begin exclude from OS Library example  
		// For example purposes we have some prepared viewfinder images on disk.
		i += 10;	
		vfFileName.Format(KFileOutput(),i);
	    TInt err = bmp->Load(vfFileName);
		// ####End exclude from OS Library example  
		
		if ( err != KErrNone )  // some termination condition usually a signal from user
			{
			// no more viewfinder images
			break;
			}
		}
	while (1);  
		
	panImage->RenderL(KTestVFTOutputFileName); // render the stitched image
	
	CleanupStack::PopAndDestroy(4,bmp); //panTrans, vfTracker, panImage, bmp
	}

