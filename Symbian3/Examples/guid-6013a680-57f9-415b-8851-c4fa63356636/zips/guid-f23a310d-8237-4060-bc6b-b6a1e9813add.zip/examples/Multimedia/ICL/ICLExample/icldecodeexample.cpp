// Copyright (c) 2007-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
// 
//

/**
@file
The code demonstrates various decode functionality of CIclExample
*/

#include "iclexample.h"

/**
Note 1: For demonstration purposes we create a client side active object which can handle
the asynchronous request to decode the image. In a standard application the asynchronous
call would be made passing in a TRequestStatus object associate with an active object
which is part of that application. We would return to the main UI processing thread in
which an active scheduler is running and wait for the asynchronous request to complete. In
this demonstration we need to manually start the active scheduler.
*/

/**
Note 2: Starts the active scheduler - this is for demonstration purposes. See Note 1:
*/

/**
Demonstrates how to decode an image for which the content of the file has been loaded into memory.
The image is decoded into a bitmap which can later be displayed on the screen.

@param aFileName  The specified file where the image is stored

@leave KEComErrNoInterfaceIdentified  ECom could not find the specified interface
@leave KErrNotFound  Either the appropriate plugin decoder for this file hasn't been found, or the file itself is missing
@leave KErrCorrupt  The plugin cannot interpret data
@leave EFrameNumberOutOfRange  Frame range is out of limit
@leave KErrCouldNotConnect  A session could not connect
@leave KErrArgument  An argument is out of range
@leave KErrTooBig  A number is too big
@leave KErrUnderflow  An underflow in some operation
*/
void CIclExample::DecodeFromDescriptorToBitmapL(const TDesC& aFileName)
	{
	TPtr8 imageInMemory = LoadImageIntoMemoryLC(aFileName);

	// Try to create the decoder. If it's successful the image headers are read.
	CImageDecoder* imageDecoder = CImageDecoder::DataNewL(iFs, imageInMemory);
	CleanupStack::PushL(imageDecoder);

	// Decoder found, create a bitmap for it to render the image to.
	CFbsBitmap* destBitmap = new(ELeave) CFbsBitmap();
	CleanupStack::PushL(destBitmap);

	// Since the image header has been read we can find out the image size and
	// can create the bitmap to match the display mode we wish to support
	const TFrameInfo& frameInfo = imageDecoder->FrameInfo(KFirstFrame);
	User::LeaveIfError(destBitmap->Create(frameInfo.iOverallSizeInPixels, frameInfo.iFrameDisplayMode));

	// See Note 1
	CActiveListener* activeListener = CreateAndInitializeActiveListenerLC();

    // Convert the image (first frame)
	imageDecoder->Convert(&activeListener->iStatus, *destBitmap, KFirstFrame);

	// See Note 2
	CActiveScheduler::Start();
	User::LeaveIfError(activeListener->iStatus.Int()); // decode complete either display the image or report an error.

	// Just verifying the presence of some output. The image can also be displayed instead.
	_LIT(KOutputFile, "c:\\ICLExample\\DecodedBitmapFromDescriptor.mbm");
	destBitmap->Save(KOutputFile); // Ignore return code.

	CleanupStack::PopAndDestroy(4); // activeListener, destBitmap, imageDecoder and imageInMemory
	}


/**
Demonstrates how to decode an image which has been loaded into a file.
The image is decoded into a bitmap which can later be displayed on the screen.

@param aFileName  The specified file where the image is stored

@leave KEComErrNoInterfaceIdentified  ECom could not find the specified interface
@leave KErrNotFound  Either the appropriate plugin decoder for this file hasn't been found, or the file itself is missing
@leave KErrCorrupt  The plugin cannot interpret data
@leave EFrameNumberOutOfRange  Frame range is out of limit
@leave KErrCouldNotConnect  A session could not connect
@leave KErrArgument  An argument is out of range
@leave KErrTooBig   A number is too big
@leave KErrUnderflow  An underflow in some operation
*/
void CIclExample::DecodeFromFileToBitmapL(const TDesC& aFileName)
	{
	// Create the decoder, passing the filename. The image is recognised by the
	// Image Conversion Library, an appropriate codec plugin loaded and the image
	// headers parsed.
	// If the image is not recognised or valid then the call will leave with an error
	CImageDecoder* imageDecoder = CImageDecoder::FileNewL(iFs, aFileName);
	CleanupStack::PushL(imageDecoder);

	CFbsBitmap* destBitmap = new(ELeave) CFbsBitmap();
	CleanupStack::PushL(destBitmap);

	// Since the image header has been parsed we can find out the image size and
	// can create the bitmap to match the display mode we wish to support
	const TFrameInfo& frameInfo = imageDecoder->FrameInfo(KFirstFrame);
	User::LeaveIfError(destBitmap->Create(frameInfo.iOverallSizeInPixels, frameInfo.iFrameDisplayMode));

	// See Note 1
	CActiveListener* activeListener = CreateAndInitializeActiveListenerLC();

	// Convert the image (first frame)
	imageDecoder->Convert(&activeListener->iStatus, *destBitmap, KFirstFrame);

	// See Note 2
	CActiveScheduler::Start();
	User::LeaveIfError(activeListener->iStatus.Int()); // decode complete either display the image or report an error.

	// Just verifying the presence of some output. The image can also be displayed instead.
	_LIT(KOutputFile, "c:\\ICLExample\\DecodedBitmapFromFile.mbm");
	destBitmap->Save(KOutputFile);	// Ignore return code.

	CleanupStack::PopAndDestroy(3); // activeListener, destBitmap and imageDecoder
	}


/**
Demonstrates how to decode a JPEG image to an uncompressed YUV image frame.

@param aFileName  The specified file where the image is stored

@leave KEComErrNoInterfaceIdentified  ECom could not find the specified interface
@leave KErrNotFound  Either the appropriate plugin decoder for this file hasn't been found, or the file itself is missing
@leave KErrCorrupt  The plugin cannot interpret data
@leave KErrArgument  An argument is out of range
@leave KErrNotSupported  Functionality is not supported
@leave KErrUnderflow  An underflow in some operation
*/
void CIclExample::DecodeToYuvFrameL(const TDesC& aFileName)
	{
	RChunk chunk;
	TInt imageSizeInBytes = 0;

	// Create the decoder, passing the filename. The image is recognised by the
	// Image Conversion Library, an appropriate codec plugin loaded and the image
	// headers parsed.
	// If the image is not recognised or valid then the call will leave with an error
	CJPEGImageFrameDecoder* jpegImageDecoder = static_cast<CJPEGImageFrameDecoder*>(CJPEGImageFrameDecoder::FileNewL(iFs, aFileName));
	CleanupStack::PushL(jpegImageDecoder);

	// Check the image whether it's supporting YUV or not
	if (jpegImageDecoder->RecommendedBufferSize(imageSizeInBytes) == EFalse)
		{
		User::Leave(KErrNotSupported);
		}

	User::LeaveIfError(chunk.CreateGlobal(KRChunk, imageSizeInBytes, imageSizeInBytes, EOwnerProcess));
	CleanupClosePushL(chunk);

	// Create an empty imageframe
	CImageFrame* imageFrame = CImageFrame::NewL(&chunk, imageSizeInBytes, 0);
	CleanupStack::PushL(imageFrame);

	// See Note 1
	CActiveListener* activeListener = CreateAndInitializeActiveListenerLC();

	// Convert the image to YUV image frame
	jpegImageDecoder->ConvertFrame(&activeListener->iStatus, *imageFrame, KFirstFrame);

	// See Note 2
	CActiveScheduler::Start();
	User::LeaveIfError(activeListener->iStatus.Int()); // decode complete either display the image or report an error.

	// NOTE: YUV pixel buffer can be used if appropriate screen driver is available

	CleanupStack::PopAndDestroy(4); // activeListener, imageFrame, chunk and jpegImageDecoder
    }


/**
Demonstrates accessing the JPEG thumbnail of an image for which the content of the file
has been loaded into memory.

@param aFileName  The specified file where the image is stored

@leave KEComErrNoInterfaceIdentified  ECom could not find the specified interface
@leave KErrNotFound  Either the appropriate plugin decoder for this file hasn't been found, or the file itself is missing
@leave KErrCorrupt  Either the plugin cannot interpret data, or links between sections have been corrupted
@leave KErrArgument  An argument is out of range
*/
void CIclExample::AccessThumbnailToDecodeL(const TDesC& aFileName)
	{
	TPtr8 imageInMemory = LoadImageIntoMemoryLC(aFileName);

	// Create the decoder, passing the image buffer. The image is recognised by the
	// Image Conversion Library, an appropriate codec plugin loaded and the image
	// headers parsed.
	// If the image is not recognised or valid then the call will leave with an error
	CJPEGExifDecoder* exifDecoder = static_cast<CJPEGExifDecoder*>(CJPEGExifDecoder::DataNewL(iFs, imageInMemory));
	CleanupStack::PushL(exifDecoder);

	exifDecoder->SetImageTypeL(CImageDecoder::EImageTypeThumbnail);

	CFbsBitmap* destBitmap = new(ELeave) CFbsBitmap();
	CleanupStack::PushL(destBitmap);

	// Since the image header has been parsed we can find out the image size and
	// can create the bitmap to match the display mode we wish to support
	const TFrameInfo& frameInfo = exifDecoder->FrameInfo(KFirstFrame);
	User::LeaveIfError(destBitmap->Create(frameInfo.iOverallSizeInPixels, frameInfo.iFrameDisplayMode));

	// See Note 1
	CActiveListener* activeListener = CreateAndInitializeActiveListenerLC();

	// Convert the image
	exifDecoder->Convert(&activeListener->iStatus, *destBitmap, KFirstFrame);

	// See Note 2
	CActiveScheduler::Start();
	User::LeaveIfError(activeListener->iStatus.Int()); // access and decode to thumbnail complete either display the image or report an error.

	// Just verifying the presence of some output. The image can also be displayed instead.

	_LIT(KOutputFile, "c:\\ICLExample\\DecodedDescThumbnail.mbm");
	destBitmap->Save(KOutputFile);	// Ignore return code.

	CleanupStack::PopAndDestroy(4); // activeListener, destBitmap, exifDecoder and imageInMemory
	}


/**
Demonstrates how to access Exif metadata of an image.

@param aFileName  The specified file where the image is stored

@leave KEComErrNoInterfaceIdentified  ECom could not find the specified interface
@leave KErrNotFound  Either the appropriate plugin decoder for this file hasn't been found, or the file itself is missing
@leave KErrCorrupt  The plugin cannot interpret data
@leave KErrArgument  An argument is out of range
@leave KErrNotSupported  Functionality is not supported
@leave KErrNotFound  Either the appropriate plugin decoder for this file hasn't been found, or the file itself is missing
@leave KErrOverflow  An overflow in some operation
*/
void CIclExample::AccessExifMetadataL(const TDesC& aFileName)
	{
	// Create the decoder, passing the image buffer. The image is recognised by the
	// Image Conversion Library, an appropriate codec plugin loaded and the image
	// headers parsed.
	// If the image is not recognised or valid then the call will leave with an error
	CJPEGExifDecoder* exifDecoder = static_cast<CJPEGExifDecoder*>(CJPEGExifDecoder::FileNewL(iFs, aFileName));
	CleanupStack::PushL(exifDecoder);

	// Create a MExifMetadata object and Initializes to metadata associated with the CJPEGExifDecoder
	MExifMetadata* metaData = exifDecoder->ExifMetadata();
	if (metaData != NULL)
		{
		// Create a TExifReaderUtility object and pass the metadata to read it
		TExifReaderUtility reader(metaData);

		HBufC8* buffer8Bit = NULL;
		User::LeaveIfError(reader.GetImageDescription(buffer8Bit));

		// NOTE: Image metadata buffer can be used here

		delete buffer8Bit;
		}

	CleanupStack::PopAndDestroy(exifDecoder);
	}


/**
Demonstrates how to decode the thumbnail of the image for which the content of the
file has been loaded into memory.
The image is decoded into a bitmap which can later be displayed on the screen.

@param aFileName  The specified file where the image is stored

@leave KEComErrNoInterfaceIdentified  ECom could not find the specified interface
@leave KErrNotFound  Either the appropriate plugin decoder for this file hasn't been found, or the file itself is missing
@leave KErrCorrupt  Either the plugin cannot interpret data, or links between sections have been corrupted
@leave EFrameNumberOutOfRange  Frame range is out of limit
@leave KErrCouldNotConnect  A session could not connect
@leave KErrArgument  An argument is out of range
@leave KErrTooBig  A number is too big
@leave KErrUnderflow  An underflow in some operation
*/
void CIclExample::DecodeTheThumbnailL(const TDesC& aFileName)
	{
	TPtr8 imageInMemory = LoadImageIntoMemoryLC(aFileName);

	// Create the decoder, passing the image buffer . The image is recognised by the
	// Image Conversion Library, an appropriate codec plugin loaded and the image
	// headers parsed.
	// If the image is not recognised or valid then the call will leave with an error
	CImageDecoder* imageDecoder = CImageDecoder::DataNewL(iFs, imageInMemory);
	CleanupStack::PushL(imageDecoder);

	// Set the image type to thumbnail to decode only the thumbnail part of the image
	imageDecoder->SetImageTypeL(CImageDecoder::EImageTypeThumbnail);

	CFbsBitmap* destBitmap = new(ELeave) CFbsBitmap();
	CleanupStack::PushL(destBitmap);

	// Since the image header has been parsed we can find out the image size and
	// can create the bitmap to match the display mode we wish to support.
	const TFrameInfo& frameInfo = imageDecoder->FrameInfo(KFirstFrame);
	User::LeaveIfError(destBitmap->Create(frameInfo.iOverallSizeInPixels, frameInfo.iFrameDisplayMode));

	// See Note 1
	CActiveListener* activeListener = CreateAndInitializeActiveListenerLC();

	// Convert the thumbnail part of the image
	imageDecoder->Convert(&activeListener->iStatus, *destBitmap);

	// See Note 2
	CActiveScheduler::Start();
	User::LeaveIfError(activeListener->iStatus.Int()); // decode complete either display the image or report an error.

	// Just verifying the presence of some output. The image can also be displayed instead.
	_LIT(KOutputFile, "c:\\ICLExample\\DecodedBitmapWithThumbnail.mbm");
	destBitmap->Save(KOutputFile);

	CleanupStack::PopAndDestroy(4); // activeListener, destBitmap, imageDecoder and imageInMemory
	}


/**
Demonstrates how to decode an image using separate thread.
The image is decoded into a bitmap which can later be displayed on the screen.

@param aFileName  The specified file where the image is stored

@leave KEComErrNoInterfaceIdentified  ECom could not find the specified interface
@leave KErrNotFound  Either the appropriate plugin decoder for this file hasn't been found, or the file itself is missing
@leave KErrCorrupt  The plugin cannot interpret data
@leave KErrArgument  An argument is out of range
@leave EFrameNumberOutOfRange  Frame range is out of limit
@leave KErrUnderflow  An underflow in some operation
*/
void CIclExample::DecodeUsingSepThreadL(const TDesC& aFileName)
	{
	TPtr8 imageInMemory = LoadImageIntoMemoryLC(aFileName);

	// Create the decoder, passing the image buffer and decoder option as EOptionAlwaysThread. The image is recognised by the
	// Image Conversion Library, an appropriate codec plugin loaded and the image
	// headers parsed.
	// If the image is not recognised or valid then the call will leave with an error
	CImageDecoder* imageDecoder = CImageDecoder::DataNewL(iFs, imageInMemory, CImageDecoder::EOptionAlwaysThread);
	CleanupStack::PushL(imageDecoder);

	// Since the image header has been parsed we can find out the image size and
	// can create the bitmap to match the display mode we wish to support
	const TFrameInfo& frameInfo = imageDecoder->FrameInfo(KFirstFrame);

	CFbsBitmap* destBitmap = new(ELeave) CFbsBitmap();
	CleanupStack::PushL(destBitmap);
	User::LeaveIfError(destBitmap->Create(frameInfo.iOverallSizeInPixels, frameInfo.iFrameDisplayMode));

	// See Note 1
	CActiveListener* activeListener = CreateAndInitializeActiveListenerLC();

	// Convert the image
	imageDecoder->Convert(&activeListener->iStatus, *destBitmap, KFirstFrame);

	// See Note 2
	CActiveScheduler::Start();
	User::LeaveIfError(activeListener->iStatus.Int()); // decode complete using separate thread either display the image or report an error.

	// Just verifying the presence of some output. The image can also be displayed instead.
	_LIT(KOutputFile, "c:\\ICLExample\\DecodedBitmapsUsingSeparateThread.mbm");
	destBitmap->Save(KOutputFile);	// Ignore return code.

	CleanupStack::PopAndDestroy(4); // activeListener, destBitmap, imageDecoder and imageInMemory
	}


/**
Demonstrates how to decode an image to ? ?and 1/8 sized bitmaps for which the content of the file
has been loaded into memory.
The image is decoded into a bitmap which can later be displayed on the screen.

@param aFileName  The specified file where the image is stored

@leave KEComErrNoInterfaceIdentified  ECom could not find the specified interface
@leave KErrNotFound  Either the appropriate plugin decoder for this file hasn't been found, or the file itself is missing
@leave KErrCorrupt  The plugin cannot interpret data
@leave KErrArgument  An argument is out of range.
@leave KErrUnderflow  An underflow in some operation
*/
void CIclExample::DecodeToHalfFourthAndEighthSizedBitmapL(const TDesC& aFileName)
	{
	TPtr8 imageInMemory = LoadImageIntoMemoryLC(aFileName);

	// Create the decoder, passing the image buffer. The image is recognised by the
	// Image Conversion Library, an appropriate codec plugin loaded and the image
	// headers parsed.
	// If the image is not recognised or valid then the call will leave with an error
	CImageDecoder* imageDecoder = CImageDecoder::DataNewL(iFs, imageInMemory);
	CleanupStack::PushL(imageDecoder);

	// Since the image header has been parsed we can find out the image size and
	// can create the bitmap to match the display mode we wish to support
	const TFrameInfo& frameInfo = imageDecoder->FrameInfo(KFirstFrame);

	CFbsBitmap* destBitmap = new(ELeave) CFbsBitmap();
	CleanupStack::PushL(destBitmap);

	// Create a new TSize object which is half the size of original size
	// and pass this size to the destination bitmap
	TSize halfSize;
	TInt reductionFactor = 1; // half size, but quarter (2) and eighth (3) size are possible too
	User::LeaveIfError(imageDecoder->ReducedSize(frameInfo.iOverallSizeInPixels, reductionFactor, halfSize));
	User::LeaveIfError(destBitmap->Create(halfSize, frameInfo.iFrameDisplayMode));

	// See Note 1
	CActiveListener* activeListener = CreateAndInitializeActiveListenerLC();

	// Convert the image to half sized bitmap
	imageDecoder->Convert(&activeListener->iStatus, *destBitmap, KFirstFrame);

	// See Note 2
	CActiveScheduler::Start();
	User::LeaveIfError(activeListener->iStatus.Int()); // decode to half sized bitmap complete either display the image or report an error.


	// Just verifying the presence of some output. The image can also be displayed instead.
	_LIT(KOutputFile, "c:\\ICLExample\\HalfSizeDecodedBitmap.mbm");
	destBitmap->Save(KOutputFile);

	CleanupStack::PopAndDestroy(4); // activeListener, destBitmap, imageDecoder and imageInMemory
	}


/**
Demonstrates how to decode an image using an image mask for which the content of the file
has been loaded into memory.
The image is decoded into a bitmap which can later be displayed on the screen.

@param aFileName  The specified file where the image is stored

@leave KEComErrNoInterfaceIdentified  ECom could not find the specified interface
@leave KErrNotFound  Either the appropriate plugin decoder for this file hasn't been found, or the file itself is missing
@leave KErrCorrupt  The plugin cannot interpret data
@leave KErrArgument  An argument is out of range.
@leave KErrUnderflow  An underflow in some operation
*/
void CIclExample::DecodeUsingImageMaskL(const TDesC& aFileName)
	{
	TPtr8 imageInMemory = LoadImageIntoMemoryLC(aFileName);

	// Create the decoder, passing the image buffer. The image is recognised by the
	// Image Conversion Library, an appropriate codec plugin loaded and the image
	// headers parsed.
	// If the image is not recognised or valid then the call will leave with an error
	CImageDecoder* imageDecoder = CImageDecoder::DataNewL(iFs, imageInMemory);
	CleanupStack::PushL(imageDecoder);

	// Since the image header has been parsed we can find out the image size and
	// can create the bitmap to match the display mode we wish to support
	// for both destination bitmap and destination mask bitmap
	const TFrameInfo& frameInfo = imageDecoder->FrameInfo(KFirstFrame);

	CFbsBitmap* destBitmap = new(ELeave) CFbsBitmap();
	CleanupStack::PushL(destBitmap);
	User::LeaveIfError(destBitmap->Create(frameInfo.iOverallSizeInPixels, frameInfo.iFrameDisplayMode));

	// See note 1.
	CActiveListener* activeListener = CreateAndInitializeActiveListenerLC();

	if (frameInfo.iFlags & TFrameInfo::ETransparencyPossible)
		{
		// we can decode the mask
		CFbsBitmap* destBitmapMask = new(ELeave) CFbsBitmap();
		CleanupStack::PushL(destBitmapMask);

		// mask bitmap type depends on presence of alpha channel
		TDisplayMode bitmapMode = (frameInfo.iFlags & TFrameInfo::EAlphaChannel) ? EGray256 : EGray2;
		User::LeaveIfError(destBitmapMask->Create(frameInfo.iOverallSizeInPixels, bitmapMode));

		// Decoding the frame and separating the mask from the main image.
		imageDecoder->Convert(&activeListener->iStatus, *destBitmap, *destBitmapMask, KFirstFrame);

		// See Note 2
		CActiveScheduler::Start();
		User::LeaveIfError(activeListener->iStatus.Int()); // decode complete using an image mask either display the image or report an error.

		// Just verifying the presence of some output. The image can also be displayed instead.
		_LIT(KOutputFile1, "c:\\ICLExample\\DecodedBitmapMask.mbm");
		_LIT(KOutputFile2, "c:\\ICLExample\\DecodedBitmapWithMask.mbm");
		destBitmapMask->Save(KOutputFile1);	// Ignore error code.
		destBitmap->Save(KOutputFile2);		// Ignore error code.

		CleanupStack::PopAndDestroy(); // destBitmapMask
		}
	else
		{
		// no mask available - in this case we decode without mask
		// Convert the image
		imageDecoder->Convert(&activeListener->iStatus, *destBitmap, KFirstFrame);

		// See Note 2
		CActiveScheduler::Start();
		User::LeaveIfError(activeListener->iStatus.Int()); // decode complete without using mask either display the image or report an error.

		// Just verifying the presence of some output. The image can also be displayed instead.
		_LIT(KOutputFile, "c:\\ICLExample\\DecodedBitmapWithoutMask.mbm");
		destBitmap->Save(KOutputFile);	// Ignore error code.
		}

	CleanupStack::PopAndDestroy(4); // activeListener, destBitmap, imageDecoder and imageInMemory
	}


/**
Demonstrates how to decode a multi-frame image for which the content of the file
has been loaded into memory.
The image is decoded into a bitmap which can later be displayed on the screen.

@param aFileName  The specified file where the image is stored

@leave EFrameNumberOutOfRange  Frame range is out of limit
@leave KEComErrNoInterfaceIdentified  ECom could not find the specified interface
@leave KErrNotFound  Either the appropriate plugin decoder for this file hasn't been found, or the file itself is missing
@leave KErrCorrupt  The plugin cannot interpret data
@leave KErrArgument  An argument is out of range
@leave KErrUnderflow  An underflow in some operation
*/
void CIclExample::MultiFrameImageDecodeL(const TDesC& aFileName)
	{
	TPtr8 imageInMemory = LoadImageIntoMemoryLC(aFileName);

	// Create the decoder, passing the image buffer. The image is recognised by the
	// Image Conversion Library, an appropriate codec plugin loaded and the image
	// headers parsed.
	// If the image is not recognised or valid then the call will leave with an error
	CImageDecoder* imageDecoder = CImageDecoder::DataNewL(iFs, imageInMemory);
	CleanupStack::PushL(imageDecoder);

	// Since the image header has been parsed we can find out the image size and
	// can create the bitmap to match the display mode we wish to support
	const TFrameInfo& frameInfo = imageDecoder->FrameInfo(KFirstFrame);

	CFbsBitmap* destBitmap = new(ELeave) CFbsBitmap();
	CleanupStack::PushL(destBitmap);
	User::LeaveIfError(destBitmap->Create(frameInfo.iOverallSizeInPixels, frameInfo.iFrameDisplayMode));

	// Read the number of frames
	const TInt KNumberOfFrames = imageDecoder->FrameCount();

	// See Note 1
	CActiveListener* activeListener = CActiveListener::NewLC();

	// Iterate all the frames and display them
	for (TInt frameNumber = 0; frameNumber < KNumberOfFrames; ++frameNumber)
		{
		// See Note 1
		activeListener->Initialize();

		// Convert the multi frame image
		imageDecoder->Convert(&activeListener->iStatus, *destBitmap, frameNumber);

		// See Note 2
		CActiveScheduler::Start();
		User::LeaveIfError(activeListener->iStatus.Int()); // decode complete using multiframe image either display the image or report an error.

		// DoSomethingWithTheFrame(destBitmap);
		}

	_LIT(KOutputFile, "c:\\ICLExample\\DecodedMultiFrameBitmap.mbm");
    destBitmap->Save(KOutputFile);

	CleanupStack::PopAndDestroy(4); // activeListener, destBitmap, imageDecoder and imageInMemory
	}


/**
Demonstrates how to decode an image using CBufferedImageDecoder::Convert() and
CBufferedImageDecoder::ContinueConvert() functions.
The image is decoded into a bitmap, which can later be displayed on the screen.

@param aFileName  The specified file where the image is stored

@leave KEComErrNoInterfaceIdentified  ECom could not find the specified interface
@leave KErrNotFound  Either the appropriate plugin decoder for this file hasn't been found, or the file itself is missing
@leave KErrCorrupt  The plugin cannot interpret data
@leave KErrArgument  An argument is out of range
@leave KErrUnderflow  An underflow in some operation
*/
void CIclExample::DecodeUsingContinueConvertL(const TDesC& aFileName)
	{
	const TInt KChunkSize = 32;

	// Open the file containing the image and get the size.
	// Create a TPtr object to wrap the pointer to the buffer.
	RFile file;
	TUint flags = EFileShareReadersOnly | EFileStream | EFileRead;
	User::LeaveIfError(file.Open(iFs, aFileName, flags));
	CleanupClosePushL(file);

	// Read the file size
	TInt fileSize = 0;
	User::LeaveIfError(file.Size(fileSize));

	// Allocate the buffer for the file read in chunks
	HBufC8* buffer = HBufC8::NewLC(KChunkSize);
	TPtr8 bufferPtr(buffer->Des());

	// Read the first chunk from the file
	User::LeaveIfError(file.Read(bufferPtr, KChunkSize));

	// Create the decoder passing the File Server session and attempt to open the decoder
	CBufferedImageDecoder* decoder = CBufferedImageDecoder::NewL(iFs);
	CleanupStack::PushL(decoder);

	// The image is recognised by the Image Conversion Library, an appropriate codec plugin loaded and
	// the image headers parsed.

	decoder->OpenL(bufferPtr);
	while (!decoder->ValidDecoder())
		{
		User::LeaveIfError(file.Read(bufferPtr, KChunkSize));
        if(0 == bufferPtr.Length() )
            {//no more bytes read from file. so end of file reached.
            // image is corrupted as header processing is incomplete
            _LIT(KErrMsg,"Error: image corrupted. Processing will stop\n");
            iConsole->Printf(KErrMsg);
            User::Leave(KErrCorrupt);
            }		
		decoder->AppendDataL(bufferPtr);
		decoder->ContinueOpenL();
		}
	// Make sure the header has been fully processed.
	while (!decoder->IsImageHeaderProcessingComplete())
		{
		User::LeaveIfError(file.Read(bufferPtr, KChunkSize));
        if(0 == bufferPtr.Length())
            {//no more bytes read from file. so end of file reached.
            break;
            }   
		decoder->AppendDataL(bufferPtr);

		}

	// Create the destination bitmap
	const TFrameInfo frameInfo = decoder->FrameInfo(KFirstFrame);

	CFbsBitmap* bitmap = new (ELeave) CFbsBitmap();
	CleanupStack::PushL(bitmap);

	User::LeaveIfError(bitmap->Create(frameInfo.iOverallSizeInPixels, frameInfo.iFrameDisplayMode));

	// Convert the image (first frame) using Convert() function for the first piece of code
	// and ContinueConvert() function for the remaining piece of code
	// Feed the image data piece by piece into decoder while the error code is KErrUnderflow
	// until it becomes KErrNone (or any other system error code).
	TInt err = KErrNone;
	CActiveListener* activeListener = CreateAndInitializeActiveListenerLC();
	decoder->Convert(&activeListener->iStatus, *bitmap, KFirstFrame);
	CActiveScheduler::Start();

	while ((err = activeListener->iStatus.Int()) == KErrUnderflow)
		{
		if ((err != KErrNone) && (err != KErrUnderflow))
			{
			User::Leave(err);
			}

		User::LeaveIfError(file.Read(bufferPtr, KChunkSize));
        if(0 == bufferPtr.Length())
            {//no more bytes read from file. so end of file reached.
            break;
            }   			
		decoder->AppendDataL(bufferPtr);
		activeListener->Initialize();
		decoder->ContinueConvert(&activeListener->iStatus);
		CActiveScheduler::Start();
		}

	// Just verifying the presence of some output. The image can also be displayed instead.
	_LIT(KOutputFile, "c:\\ICLExample\\DecodedBitmapWithContinueConvert.mbm");
	bitmap->Save(KOutputFile);

	CleanupStack::PopAndDestroy(5); // file, buffer, decoder, bitmap and activeListener
	}


/**
Demonstrates how to display the comments contained in an image for which the content of the file
has been loaded into memory.

@param aFileName  The specified file where the image is stored

@leave KEComErrNoInterfaceIdentified  ECom could not find the specified interface
@leave KErrNotFound  Either the appropriate plugin decoder for this file hasn't been found, or the file itself is missing
@leave KErrCorrupt  The plugin cannot interpret data
@leave KErrArgument  An argument is out of range
*/
void CIclExample::DisplayingImageCommentsL(const TDesC& aFileName)
	{
	TInt numberOfImageComments;

	TPtr8 imageInMemory = LoadImageIntoMemoryLC(aFileName);

	// Create the decoder, passing the image buffer. The image is recognised by the
	// Image Conversion Library, an appropriate codec plugin loaded and the image
	// headers parsed.
	// If the image is not recognised or valid then the call will leave with an error
	CImageDecoder* imageDecoder = CImageDecoder::DataNewL(iFs, imageInMemory);
	CleanupStack::PushL(imageDecoder);

	// Count the number of image comments attached to the specified image
	numberOfImageComments = imageDecoder->NumberOfImageComments();

	for (TInt commentNumber = 0; commentNumber < numberOfImageComments; ++commentNumber)
		{
		HBufC* imageComment = imageDecoder->ImageCommentL(commentNumber);
		CleanupStack::PushL(imageComment);

		TPtrC commentPtr = imageComment->Des();

		// Decoded image comments can be displayed here
		CleanupStack::PopAndDestroy(imageComment);
		}

	CleanupStack::PopAndDestroy(2); // imageDecoder and imageInMemory
	}


/**
Demonstrates how to display the comments contained in frame of an image for which the content of the file
has been loaded into memory.

@param aFileName  The specified file where the image is stored

@leave KEComErrNoInterfaceIdentified  ECom could not find the specified interface
@leave KErrNotFound  Either the appropriate plugin decoder for this file hasn't been found, or the file itself is missing
@leave KErrCorrupt  The plugin cannot interpret data
@leave KErrArgument  An argument is out of range
*/
void CIclExample::DisplayingFrameCommentsL(const TDesC& aFileName)
	{
	TInt numberOfComments = 0;

	TPtr8 imageInMemory = LoadImageIntoMemoryLC(aFileName);

	// Create the decoder, passing the image buffer. The image is recognised by the
	// Image Conversion Library, an appropriate codec plugin loaded and the image
	// headers parsed.
	// If the image is not recognised or valid then the call will leave with an error
	CImageDecoder* imageDecoder = CImageDecoder::DataNewL(iFs, imageInMemory);
	CleanupStack::PushL(imageDecoder);

	for (TInt frameNumber = 0; frameNumber < imageDecoder->FrameCount(); ++frameNumber)
		{
		// Count the number of frame comments
		numberOfComments = imageDecoder->NumberOfFrameComments(frameNumber);

		for (TInt commentNumber = 0; commentNumber < numberOfComments; ++commentNumber)
			{
			HBufC* frameComment = imageDecoder->FrameCommentL(frameNumber, commentNumber);
			CleanupStack::PushL(frameComment);

			TPtrC commentPtr = frameComment->Des();

	    	// Decoded frame comments can be displayed here

			CleanupStack::PopAndDestroy(frameComment);
			}
		}

	CleanupStack::PopAndDestroy(2); // imageDecoder and imageInMemory
	}


/**
Demonstrates how to get the mime type of source in descriptor and load the decoder using this mime type.

@param aFileName  The specified file where the image is stored

@leave KEComErrNoInterfaceIdentified  ECom could not find the specified interface
@leave KErrNotFound  Either the appropriate plugin decoder for this file hasn't been found, or the file itself is missing
@leave KErrCorrupt  The plugin cannot interpret data
@leave KErrArgument  An argument is out of range
@leave KErrPermissionDenied  An operation cannot be performed due to a potential security violation
@leave KErrInUse  Requested resource is already in use
*/
void CIclExample::GettingMimeTypeOfSourceDescriptorL(const TDesC& aFileName)
	{
	TBuf8<128> theMimeType;

	TPtr8 imageInMemory = LoadImageIntoMemoryLC(aFileName);

	// Call GetMimeTypeDataL() function of CImageDecoder to get the mime type of specified file
	CImageDecoder::GetMimeTypeDataL(imageInMemory, theMimeType);

	// Create the decoder, passing the image buffer. The image is recognised by the
	// Image Conversion Library, an appropriate codec plugin loaded and the image
	// headers parsed.
	// If the image is not recognised or valid then the call will leave with an error
	CImageDecoder* imageDecoder = CImageDecoder::DataNewL(iFs, imageInMemory, theMimeType);
	CleanupStack::PushL(imageDecoder);

	// Decoded image mime can be displayed here after convert operation.

	CleanupStack::PopAndDestroy(2); // imageDecoder and imageInMemory
	}


/**
Demonstrates how to get the mime type of source in file and load the decoder using this mime type.

@param aFileName  The specified file where the image is stored

@leave KEComErrNoInterfaceIdentified  ECom could not find the specified interface
@leave KErrNotFound  Either the appropriate plugin decoder for this file hasn't been found, or the file itself is missing
@leave KErrCorrupt  The plugin cannot interpret data
@leave KErrArgument  An argument is out of range
@leave EFrameNumberOutOfRange  Frame range is out of limit
*/
void CIclExample::GettingMimeTypeOfSourceFileL(const TDesC& aFileName)
	{
	TBuf8<128> theMimeType;

	// Call GetMimeTypeFileL() function of CImageDecoderGet to get the mime type of source file
	CImageDecoder::GetMimeTypeFileL(iFs, aFileName, theMimeType);

	// Create the decoder, passing the filename and mime type. The image is recognised by the
	// Image Conversion Library, an appropriate codec plugin loaded and the image
	// headers parsed.
	// If the image is not recognised or valid then the call will leave with an error
	CImageDecoder* imageDecoder = CImageDecoder::FileNewL(iFs, aFileName, theMimeType);
	CleanupStack::PushL(imageDecoder);

	// Decoded image mime can be displayed here after convert operation

	CleanupStack::PopAndDestroy(imageDecoder);
	}


/**
Demonstrates how to resolve and load a plug-in by specific UID

@param aFileName  The specified file  where the image is stored
@param TUid  aCodecUid specific Uid to load the decoder

@leave KErrArgument  An argument is out of range
*/
void CIclExample::LoadPluginByUidL(const TDesC& aFileName, TUid aCodecUid)
	{
	// create the decoder, passing the filename. The image is recognised by the
	// Image Conversion Library, an appropriate codec plugin loaded and the image
	// headers parsed according to Uid.
	// If the image is not recognised or valid then the call will leave with an error
	CImageDecoder* imageDecoder = NULL;

	imageDecoder = CImageDecoder::FileNewL(iFs, aFileName, CImageDecoder::EOptionNone, aCodecUid);
	CleanupStack::PushL(imageDecoder);

	// Decoder can be used here

	CleanupStack::PopAndDestroy(imageDecoder);
	}


/**
Demonstrates how to decode a bitmap including rotation of image MNG/GIF 'Animation'

@param aFileName  The specified file where the image is stored

@leave KEComErrNoInterfaceIdentified  ECom could not find the specified interface
@leave KErrNotFound  Either the appropriate plugin decoder for this file hasn't been found, or the file itself is missing
@leave KErrCorrupt  The plugin cannot interpret data
@leave EFrameNumberOutOfRange  Frame range is out of limit
@leave KErrCouldNotConnect  A session could not connect
@leave KErrArgument  An argument is out of range
@leave KErrTooBig  A number is too big
@leave KErrUnderflow  An underflow in some operation
@leave ENoSourceBitmap  Invalid source bitmap
*/
void CIclExample::DecodeWithRotateL(const TDesC& aFileName)
	{
	TPtr8 imageInMemory = LoadImageIntoMemoryLC(aFileName);

	// create the decoder, passing in the image memory. The image is recognised by the
	// Image Conversion Library, an appropriate codec plugin loaded and the image
	// headers parsed.
	// If the image is not recognised or valid then the call will leave with an error
	CImageDecoder* imageDecoder = CImageDecoder::DataNewL(iFs, imageInMemory);
	CleanupStack::PushL(imageDecoder);

	// Since the image header has been parsed we can find out the image size and can create
	// the bitmap to match the display mode we wish to support.
	const TFrameInfo& frameInfo = imageDecoder->FrameInfo(KFirstFrame);

	CFbsBitmap* destBitmap = new(ELeave) CFbsBitmap();
	CleanupStack::PushL(destBitmap);

	User::LeaveIfError(destBitmap->Create(frameInfo.iOverallSizeInPixels, frameInfo.iFrameDisplayMode));

	// See Note 1
	CActiveListener* activeListener = CreateAndInitializeActiveListenerLC();

	// Convert the image (first frame)
	imageDecoder->Convert(&activeListener->iStatus, *destBitmap, KFirstFrame);

	// See Note 2
	CActiveScheduler::Start();
	User::LeaveIfError(activeListener->iStatus.Int()); // decode complete either display the image or report an error.

	// Create a CBitmapRotator object and push it on the cleanup stack
	CBitmapRotator* rotator = CBitmapRotator::NewL();
	CleanupStack::PushL(rotator);

	// Rotate the bitmap through the specified angle
	activeListener->Initialize();
	rotator->Rotate(&activeListener->iStatus, *destBitmap, CBitmapRotator::ERotation180DegreesClockwise);

	// See Note 2
	CActiveScheduler::Start();
	User::LeaveIfError(activeListener->iStatus.Int()); // rotate complete either display the image or report an error.

	// Just verifying the presence of some output. The rotated image can also be displayed instead.
	_LIT(KOutputFile, "c:\\ICLExample\\RotatedBitmap.mbm");
	destBitmap->Save(KOutputFile);

	CleanupStack::PopAndDestroy(5); // rotator, destBitmap, activeListener, imageDecoder and imageInMemory
	}

//
// Illustrates how to clip and rotate images during decode.
//
const TDecodeParams KDecodeParams[] =
	{	// Clip - R90 - MirrorV  - Scale - Output
		{EFalse, EFalse, EFalse, 1, _S("\\ICLExample\\NormalFull.mbm")},
		{ETrue,  EFalse, EFalse, -1, _S("\\ICLExample\\ClipFull.mbm")},
		{ETrue,  EFalse, ETrue,  -2, _S("\\ICLExample\\MirrorVertClipQuarter.mbm")},
		{ETrue,  ETrue,  ETrue,  -3, _S("\\ICLExample\\Rotate90MirrorVertClipEighth.mbm")},
		{EFalse, ETrue,  EFalse, 1, _S("\\ICLExample\\Rotate90Full.mbm")},
		{EFalse, EFalse, EFalse, 1, NULL}
	};

void CIclExample::ClipAndRotateDuringDecodeL()
	{
	TRect clipRect(TPoint(50, 65), TSize(170, 160));	// The wheel in thumbimage.jpg
	TSize finalSize;

	// The decoder must support *all* the operations we're going to perform.
	TUint options =	CImageDecoder::EOptionExtRotation |
					CImageDecoder::EOptionExtMirrorHorizontalAxis |
					CImageDecoder::EOptionExtCrop |
					CImageDecoder::EOptionExtScaling;

	// The installed decoders must support *all* the operations requested in aOptions.
	_LIT(KInputFile, "c:\\ICLExample\\thumbimage.jpg");
	CImageDecoder* decoder = CImageDecoder::FileNewL(iFs, KInputFile, static_cast<CImageDecoder::TOptions>(options));
	CleanupStack::PushL(decoder);

	const TFrameInfo& frameInfo = decoder->FrameInfo(KFirstFrame);
	CFbsBitmap* output = new(ELeave) CFbsBitmap();
	CleanupStack::PushL(output);
	User::LeaveIfError(output->Create(frameInfo.iFrameSizeInPixels, frameInfo.iFrameDisplayMode));

	CActiveListener* ao = CActiveListener::NewLC();

	TImageConvOperation* operation = decoder->OperationL();
	TImageConvScaler* scaler = decoder->ScalerL();

	TInt i = 0;
	while (KDecodeParams[i].iOutputFile != NULL)
		{
		const TDecodeParams& params = KDecodeParams[i++];

		operation->ClearOperationStack();
		if (params.iRotate90)
			{
			operation->AddOperationL(TImageConvOperation::ERotation90DegreesClockwise);
			}

		if (params.iMirrorVerticalAxis)
			{
			operation->AddOperationL(TImageConvOperation::EMirrorVerticalAxis);
			}

		// Some codecs may have a limit on the amount of scaling they can do.
		scaler->SetScalingL(params.iScalingCoeff, TImageConvScaler::EMaximumQuality);

		// Setting the clipping rect to NULL will decode the whole image.
		decoder->SetClippingRectL(params.iClip ? &clipRect : NULL);
		User::LeaveIfError(decoder->GetDestinationSize(finalSize, KFirstFrame));
		User::LeaveIfError(output->Resize(finalSize));

		// See Note 1
		ao->Initialize();
		decoder->Convert(&ao->iStatus, *output, KFirstFrame);

		// See Note 2
		CActiveScheduler::Start();

		TPtrC outputFile(params.iOutputFile);
		output->Save(outputFile);	// Ignore error code.
		}

	CleanupStack::PopAndDestroy(3); // decoder, output, ao
	}


/**
Demonstrates modification of JPEG MCUs using minimal memory, for example to change brightness over an entire image, 
by decoding and then re-encoding via the block streamer extension interfaces.

@param aSrcFileName  Specifies the source file containing the image to be stream decoded.
@param aDestFileName Specifies the destination file where the stream encoded image is to be written.

@leave KEComErrNoInterfaceIdentified  ECom could not find the specified interface
@leave KErrNotFound  Either the appropriate plugin decoder for this file hasn't been found, or the file itself is missing
@leave KErrCorrupt  The plugin cannot interpret data
@leave KErrArgument  An argument is out of range
@leave KErrNotSupported  Functionality is not supported 
@leave KErrUnderflow  An underflow in some operation
@leave KErrOverflow  An underflow in some operation
*/
void CIclExample::BlockStreamDecodeAndEncodeYuvFrameL(const TDesC& aSrcFileName, const TDesC& aDestFileName)
	{
	const TInt KNumBlocksToGet = 1;
	RChunk chunk;
	TSize streamBlockSizeInPixels;
	TEncodeStreamCaps encodeCaps;
	TDecodeStreamCaps decodeCaps;
	TInt numBlocksRead = 0;
	TBool haveMoreBlocks = ETrue;
	// Create the decoder, passing the filename. The image is recognised by the 
	// Image Conversion Library, an appropriate codec plugin loaded and the image headers parsed.
	// If the image is not recognised or valid then the call will leave with an error
	CImageDecoder* jpegImageDecoder = CImageDecoder::FileNewL(iFs, aSrcFileName);
	CleanupStack::PushL(jpegImageDecoder);

	// Create the encoder, passing the filename. The image is recognised by the 
	// Image Conversion Library, an appropriate codec plugin loaded and the image headers parsed.
	// If the image is not recognised or valid then the call will leave with an error	
	CImageEncoder* jpegImageEncoder = CImageEncoder::FileNewL(iFs, aDestFileName, CImageEncoder::EOptionNone, KImageTypeJPGUid);
	CleanupStack::PushL(jpegImageEncoder);
	
	// Create encode & decode Block Streamer
	TImageConvStreamedDecode* streamDecode = jpegImageDecoder->BlockStreamerL();	
	TImageConvStreamedEncode* streamEncode = jpegImageEncoder->BlockStreamerL();
	
	TFrameInfo frameInfo = jpegImageDecoder->FrameInfo();
	TSize frameSizeInPixels(frameInfo.iOverallSizeInPixels); //NOTE: For JPEG codec, the image used for stream decoding and encoding should be multiple of MCU(Minimum coded unit)
	
	// Get decoder capabilities
	TDecodeStreamCaps::TNavigation decodeNavigation = TDecodeStreamCaps::ENavigationSequentialForward;
	
	TUid KFormat;
	RArray<TUid> supportedFormats;
	CleanupClosePushL(supportedFormats);
	
	streamDecode->GetSupportedFormatsL(supportedFormats, KFormat);
	
	streamDecode->GetCapabilities(KFormat, KFirstFrame, decodeCaps);

	// Check that the decoder supports sequential navigation capabilities
	if(decodeCaps.Navigation() & TDecodeStreamCaps::ENavigationSequentialForward != decodeNavigation)
		{
		User::Leave(KErrNotSupported);
		}

	// set the navigation mode initialize decoder frame
	streamDecode->InitFrameL(KFormat, KFirstFrame, decodeNavigation);
	
	// Get decoder capabilities
	streamEncode->GetCapabilities(KFormat,encodeCaps);
	
	TSize blockSizeInPixels = encodeCaps.MinBlockSizeInPixels();
	
	// initialize encoder frame
	TEncodeStreamCaps::TNavigation encodeNavigation = TEncodeStreamCaps::ENavigationSequentialForward;
	
	// Check that the encoder supports sequential navigation capabilities
	if(encodeCaps.Navigation() & TEncodeStreamCaps::ENavigationSequentialForward != encodeNavigation)
		{
		User::Leave(KErrNotSupported);
		}
	
	// create frame image data
	CFrameImageData* frameImageData = CFrameImageData::NewL();
	CleanupStack::PushL(frameImageData);
	
	TJpegImageData* jpegImageData = new(ELeave) TJpegImageData;		
	frameImageData->AppendImageData(jpegImageData);
	
	streamEncode->InitFrameL(KFormat, KFirstFrame, frameSizeInPixels, blockSizeInPixels, encodeNavigation, NULL);
	
	// When decoding, the buffer wrapped by the destination CImageFrame must be large enough to contain the decoded frame.
	// GetBufferSize() should be used to obtain the buffer size required for a particular decode
	TInt imageSizeInBytes = streamDecode->GetBufferSize(KFormat, streamBlockSizeInPixels, KNumBlocksToGet);
			
	User::LeaveIfError(chunk.CreateLocal(imageSizeInBytes, imageSizeInBytes));
	CleanupClosePushL(chunk);
		
	// Create an empty imageframe   
	CImageFrame* imageFrame = CImageFrame::NewL(&chunk, imageSizeInBytes, 0);
	CleanupStack::PushL(imageFrame);

	imageFrame->SetFrameSizeInPixels(streamBlockSizeInPixels);
	
	while(haveMoreBlocks)
		{
		// See Note 1
		CActiveListener* activeListener = CreateAndInitializeActiveListenerLC();
		
		// decoder get blocks
		streamDecode->GetNextBlocks(activeListener->iStatus, *imageFrame, KNumBlocksToGet, numBlocksRead, haveMoreBlocks);
		
		// See Note 2
		CActiveScheduler::Start();
		User::LeaveIfError(activeListener->iStatus.Int()); // decode complete.
		
		// NOTE: Apply effects like adjust brightness etc in low memory conditions by use of streaming to the image frame block
				
		// See Note 1
		activeListener->Initialize();
		
		// encoder append blocks
		streamEncode->AppendBlocks(activeListener->iStatus, *imageFrame, numBlocksRead);

		// See Note 2
		CActiveScheduler::Start();
		User::LeaveIfError(activeListener->iStatus.Int()); // encode complete.
		
		CleanupStack::PopAndDestroy(activeListener); // encodeActiveListener 
		}
	
	CleanupStack::PopAndDestroy(6, jpegImageDecoder); // imageFrame, chunk, supportedFormats, jpegImageEncoder and jpegImageDecoder
    }


