// iclexample.h
//
// // Copyright (c) 2007-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//
//

/**
@file 
Contains the CIclExample class.
*/
#ifndef __ICLEXAMPLE_H__
#define __ICLEXAMPLE_H__

// Symbian platform includes
#include <bitmaptransforms.h>
#include <iclexifimageframe.h> 
#include <exifutility.h>
#include <e32cons.h>


// Index of the first frame of an image.
const TInt KFirstFrame = 0;

// Literals
_LIT(KBitmapFile,"\\ICLExample\\smiley.bmp");
_LIT(KThumbFile,"\\ICLExample\\thumbimage.jpg");
_LIT(KYuvBitmap,"\\ICLExample\\yuvimage.jpg");
_LIT(KYuvDestBitmap,"\\ICLExample\\yuvdestimage.jpg");
_LIT(KDestStreamFile,"\\ICLExample\\encodedstreamimage.jpg");
_LIT(KDestRotateFile,"\\ICLExample\\encodedrotateimage.jpg");
_LIT(KMultiFrameClock,"\\ICLExample\\clock.gif");
_LIT(KBitmapComment,"\\ICLExample\\am475.gif");
_LIT(KBitmapFrameComment,"\\ICLExample\\comment.jpg");
_LIT(KBitmapExif,"\\ICLExample\\exifencode.jpg");
_LIT(KSourceBitmap,"\\ICLExample\\source.mbm");
_LIT(KBitmapRotateWhileEncodeToJpeg,"\\ICLExample\\sourcerotate.mbm");
_LIT(KTestFileName1, "\\ICLExample\\harbourbridge1.jpg");
_LIT(KTestFileName2, "\\ICLExample\\harbourbridge2.jpg");
_LIT(KTestFileName3, "\\ICLExample\\harbourbridge3.jpg");
_LIT(KTestFileName4, "\\ICLExample\\harbourbridge4.jpg");
_LIT(KTestBSOutputFileName, "\\ICLExample\\harbourbridgepanorama.jpg");
_LIT(KTestVFTOutputFileName, "\\ICLExample\\harbourbridgepanoramavt.jpg");
_LIT(KVFTTestFileName1, "\\ICLExample\\office1.jpg");
_LIT(KVFTTestFileName2, "\\ICLExample\\office2.jpg");
_LIT(KVFTTestFileName3, "\\ICLExample\\office3.jpg");
_LIT(KVFTTestFileName4, "\\ICLExample\\office4.jpg");
_LIT(KVFTTestFileName5, "\\ICLExample\\office5.jpg");
_LIT(KVFTTestFileName6, "\\ICLExample\\office6.jpg");
_LIT(KVFTTestRefFileName, "\\ICLExample\\office.mbm");
_LIT(KInputFileName,"c:\\ICLExample\\input_image.jpg");
_LIT(KInputFileName01,"c:\\ICLExample\\input_image01.jpg");
_LIT(KInputFileName02,"c:\\ICLExample\\input_image02.jpg");
_LIT(KInputFileName03,"c:\\ICLExample\\input_image03.jpg");
_LIT(KInputFileName04,"c:\\ICLExample\\input_image04.jpg");
_LIT(KInputOverlayFileName,"c:\\ICLExample\\overlay.png");
_LIT(KInputWithSpmoFileName,"c:\\ICLExample\\input_image_with_spmo.jpg");
_LIT(KOutputFileName, "c:\\ICLExample\\output_image.jpg");
_LIT(KOutputWithBasicEffectFileName, "c:\\ICLExample\\output_image_with_basiceffect.jpg");
_LIT(KOutputWithUndoFileName, "c:\\ICLExample\\output_image_with_undo.jpg");
_LIT(KOutputWithOverlayFileName,"c:\\ICLExample\\output_image_with_overlay.jpg");
_LIT(KOutputBitmapFileName,"c:\\ICLExample\\output_bitmap.mbm");
_LIT(KOutputBitmapFileName01,"c:\\ICLExample\\output_bitmap01.mbm");
_LIT(KOutputBitmapFileName02,"c:\\ICLExample\\output_bitmap02.mbm");
_LIT(KOutputBitmapFileName03,"c:\\ICLExample\\output_bitmap03.mbm");
_LIT(KOutputBitmapFileName04,"c:\\ICLExample\\output_bitmap04.mbm");
_LIT(KOutputWithSpmoFileName,"c:\\ICLExample\\output_image_with_spmo.jpg");
_LIT(KSpmoFileName, "c:\\ICLExample\\spmo.bin");
_LIT(KSourceJpgCapstest,"\\ICLExample\\capstest.jpg");
_LIT(KSourceJpgDatetree,"\\ICLExample\\datetree.jpg");
_LIT(KSourceJpgOverlay,"\\ICLExample\\overlay.jpg");
_LIT(KSourcePngOverlay,"\\ICLExample\\overlay.png");
_LIT(KSourceMbmOverlay,"\\ICLExample\\mbm32bpp_1.mbm");
_LIT(KSqueezeDestJpgDatetreeFileToFile,"\\ICLExample\\dest_datetreefiletofile.jpg");
_LIT(KSqueezeDestJpgDatetreeBufferToBuffer,"\\ICLExample\\dest_datetreebufffertobuffer.jpg");
_LIT(KAutoSqueezeDestJpgCapstest,"\\ICLExample\\dest_capstestautosqueze.jpg");
_LIT(KRotate90DestJpgCapstest, "\\ICLExample\\dest_capstestrotate90.jpg");
_LIT(KOverlayDestPngFileToFile, "\\ICLExample\\dest_overlayfile_filetofile.jpg");
_LIT(KOverlayDestJpgDataFileToFile, "\\ICLExample\\dest_overlaydata_filetofile.jpg");
_LIT(KOverlayDestBitmapFileToFile,"\\ICLExample\\dest_overlaybitmap_filetofile.jpg");

_LIT(KTitle, "ICL Example" );
_LIT(KWelcomeMessage,"\n   Welcome to ICL Example\n");
_LIT(KPressAKeyMsg, "\nPress any key to step through the example\n");
_LIT(KExitMsg, "\nPress any key to exit the application ");
_LIT(KPressAKey, "\nPress any key to continue\n");
_LIT(KFailed, "\nFailed to complete");

_LIT(KDecode, "\n   Decoding Bitmap");
_LIT(KDecodeFromDescriptorToBitmap, "\nDecode descriptor to bitmap\n");
_LIT(KDecodeFromDescriptorAndFile, "\nFile %S  successfully decoded from descriptor and file\n");
_LIT(KDecodeToHalfFourthAndEighthSizedBmp, "\nFile %S successfully decoded to half, fourth and eighth sized bitmap using reduction factor and reduced size\n");
_LIT(KSeparateThreadAndCancelAndContinueConvert, "\nFile %S successfully  decoded using separate thread and Continue convert\n");
_LIT(KDecodeUsingImageMask, "\nDecode using image mask\n");
_LIT(KDecodeToYuv, "\nFile %S successfully decoded to image frame Yuv\n");
_LIT(KStreamYuv, "\nFile %S successfully block stream decoded to image frame Yuv and block stream encoded to Jpeg file\n");
_LIT(KDecodeUsingSepThread, "\nDecode using separate thread\n");
_LIT(KAccessThumbnailToDecode, "\nJPEG thumbnail access\n");
_LIT(KAccessExifMetadata, "\nAccess Exif metadata\n");
_LIT(KDisplayingImageComments, "\nDecode and display image comments\n");
_LIT(KGettingMimeTypeOfSourceDescriptor, "\nGet the MIME type of a source image descriptor, and load a decoder using a MIME type\n");
_LIT(KRChunk, "aRChunkICL");
_LIT(KAccessExifThumbnailAndDecodeThumbnail, "\nEXIF And JPEG thumbnail accessed and thumbnail part of file %S decoded successfully\n");
_LIT(KImageMaskAndMultiFrameImageDecode, "\nFile %S successfully decoded using image mask and Multiframe image \n");
_LIT(KImageAndFrameComment, "\nImage comment and frame comment accessed successfully\n");
_LIT(KGettingMimeTypeFromSourceAndFile, "\nFile %S decoded successfully after getting the MIME type from source image\n");

_LIT(KEncode, "\n    Encoding Bitmap");
_LIT(KFileEncode, "\nFile %S encoded successfully to descriptor\n");
_LIT(KEncodeImageWithThumbnail, "\nEncode a JPEG thumbnail of an image\n");
_LIT(KAccessToThumbnailAndExifSetting,"\nThumbnail access and setting Exif metadata to image successful\n");
_LIT(KFileRotate, "\nBitmap rotated successfully\n");
_LIT(KEncodeRotate, "\nBitmap encoded to file %S with rotation operation successful\n");
_LIT(KScaleBitmap, "\nBitmap scaled successfully including optional selection of low memory and quality algorithms\n");
_LIT(KSetSourceDestinationandResize, "\nResize using CImageTransform\n");
_LIT(KFileRotateAfterDecode, "\nFile %S rotated successfully after being decoded\n");
_LIT(KSetSourceAndDestinationAndResize, "\nSetting source and destination and resize and preserve image data successful\n");
_LIT8(KExifMetadata, "Smiley bitmap"); 
_LIT8(KBuf8ParamWriteVersion, "Add Exif data");
_LIT(KExifAndThumbnailAdded, "\nAdding thumbnail and Exif metadata successful\n");
_LIT(KAddThumbnailToJpegFile, "\nAdd thumbnail to JPEG file\n");
_LIT(KPluginLoadedSpecificToUID, "\nPlugin loaded according to specific uid\n");
_LIT(KScaledWithWithoutAndThresholdScaling, "\nScaling with and without mask and threshold scaling successful\n");

_LIT(KPanoramaStitching, "\nPanorama stitching\n");
_LIT(KBPStitching, "\nBasic panorama stitching\n");
_LIT(KVFTStitching, "\nView Finder Image Tracking\n");
_LIT(KGeneratingSpmo, "\n    Generating Spmo");
_LIT(KGeneratingSpmoIteratively, "\n    Generating Spmo iteratively\n");
_LIT(KBasicImageProcessing, "\n    Basic image processing\n");
_LIT(KBasicEffectImageProcessing, "\n    Image processing with basic effects applied\n");
_LIT(KEffectImageProcessingWithUndo, "\n    Image processing with undo\n");
_LIT(KEffectImageProcessingWithPreview, "\n    Image processing with preview\n");
_LIT(KEffectImageProcessingWithOverlay, "\n    Image processing with overlay\n");
_LIT(KImageProcessingWithSpmo, "\n    Image processing with Spmo\n");

_LIT(KImageTransform, "\n    Image Transform Functions");
_LIT(KSqueezeFileToFile, "\nSqueezing Jpg File to a Jpg File");
_LIT(KSqueezeBufferToBuffer, "\nSqueezing Jpg in Buffer to a Jpg in Buffer");
_LIT(KAutoSqueezeFileToFile, "\nAuto-Squeezing Jpg File to a Jpg File");

_LIT(KRotateFileToFile, "\nRotating a Jpg File to a Jpg File");

_LIT(KOverlayJpgDataFileToFile, "\nOverlay Jpg data to a Jpg File to a Jpg File");
_LIT(KOverlayPngFileToFile, "\nOverlay Png file to a Jpg File to a Jpg File");
_LIT(KOverlayBmpDataFileToFile, "\nOverlay Bmp data to a Jpg File to a Jpg File");

class CActiveListener;

/**
Demonstrates some uses of the Symbian platform ICL (Image Converter Library) component.

The class demonstrates how to decode, encode, rotate and scale images using the plug-ins provided by ICL.
It covers the following use-cases of the ICL component:
- Decoding an image:
 - from a descriptor 
 - from a file
 - using an image mask
 - using separate thread
 - using the image thumbnail
 - using mult-frame
 - that supports YUV format into an image frame
- Encoding an image to a descriptor with EXIF metadata
- Rotating a bitmap
- Scaling a bitmap with and without mask	
*/

typedef struct
	{
	TBool iClip;
	TBool iRotate90;
	TBool iMirrorVerticalAxis;
	TInt iScalingCoeff;	// 1,-1 = Normal, -2 = Half, -3 = Quarter, -4 = Eighth.
	const TText* iOutputFile;
	}
TDecodeParams;

class CIclExample: public CBase
	{
public:
	static CIclExample* NewLC();

	~CIclExample();
	CActiveListener* CreateAndInitializeActiveListenerLC();
	void DecodeFromDescriptorToBitmapL(const TDesC& aFileName);
	void DecodeFromFileToBitmapL(const TDesC& aFilename);
	void DecodeToYuvFrameL(const TDesC& aFileName);
	void AccessThumbnailToDecodeL(const TDesC& aFileName);
	void AccessExifMetadataL(const TDesC& aFileName);
	void DecodeUsingSepThreadL(const TDesC& aFileName);
	void DecodeToHalfFourthAndEighthSizedBitmapL(const TDesC& aFileName);
	void DecodeUsingImageMaskL(const TDesC& aFileName);
	void MultiFrameImageDecodeL(const TDesC& aFileName);
	void DecodeTheThumbnailL(const TDesC& aFileName);
	void DecodeUsingContinueConvertL(const TDesC& aFileName);
	void DisplayingImageCommentsL(const TDesC& aFileName);
	void DisplayingFrameCommentsL(const TDesC& aFileName);
	void GettingMimeTypeOfSourceDescriptorL(const TDesC& aFileName);
	void GettingMimeTypeOfSourceFileL(const TDesC& aFileName);
	void EncodeBitmapToDescriptorL(const TDesC& aFileName);
	void EncodeImageWithThumbnailL(const TDesC& aFileName);
	void SettingExifMetadataL(const TDesC& aFileName);
	void RotateBitmapL(const TDesC& aFileName);
	void ScaleBitmapL(const TDesC& aFileName);
	void DecodeWithRotateL(const TDesC& aFileName);
	void SetSourceDestinationandResizeL(const TDesC& aFileName);
	void SettingWithUseOfPreserveImageDataL(const TDesC& aFileName1,const TDesC& aFileName2);
	void AddThumbnailToJpegFileL(const TDesC& aSrcFileName, const TDesC& aDesFileName );
	void AddExifDataToJpegFileL(const TDesC& aFileName);
	void LoadPluginByUidL(const TDesC& aFilename, TUid aCodecUid);
	void BlockStreamDecodeAndEncodeYuvFrameL(const TDesC& aSrcFileName, const TDesC& aDestFileName);
	void EncodeBitmapToFileUsingOperationExtensionL(const TDesC& aSrcFileName, const TDesC& aDestFileName);

	void ClipAndRotateDuringDecodeL();
	
	//panorama stitching
	void BasicPanoramaStitchingL();
	void ViewFinderImageTrackingL();
	// Spmo
	void GeneratingSpmoL();
	void GeneratingSpmoIterativelyL();

	// Image Processor
	void BasicImageProcessingL();
	void BasicEffectImageProcessingL();
	void EffectImageProcessingWithUndoL();
	void EffectImageProcessingWithPreviewL();
	void EffectImageProcessingWithOverlayL();
	void ImageProcessingWithSpmoL();

	// Transform
	void SqueezeJpgFileToFileL(const TDesC& aSrcFileName, const TDesC& aDestFileName);
	void SqueezeJpgBufferToBufferL(const TDesC& aSrcFileName, const TDesC& aDestFileName);
	void AutoSqueezeJpgFileToFileL(const TDesC& aSrcFileName, const TDesC& aDestFileName);

	void RotateJpgFileToFileL(const TDesC& aSrcFileName, const TDesC& aDestFileName);

	void OverlayJpgDataToJpgFileToFileL(const TDesC& aSrcFileName, const TDesC& aOverlayFileName, const TDesC& aDestFileName);	
	void OverlayPngFileToJpgFileToFileL(const TDesC& aSrcFileName, const TDesC& aOverlayFileName, const TDesC& aDestFileName);
	void OverlayBmpDataToJpgFileToFileL(const TDesC& aSrcFileName, const TDesC& aOverlayFileName, const TDesC& aDestFileName);

public:
	inline void SetConsole(CConsoleBase* aConsole);	

	
private:
	CIclExample();
	void ConstructL();
	
	TPtr8 LoadImageIntoMemoryLC(const TDesC& aFileName);	

private:
	/* File server session */
	RFs iFs;
	CConsoleBase* iConsole; // owned in MainL() 
    };

inline void CIclExample::SetConsole(CConsoleBase* aConsole)
	{
	iConsole = aConsole;
	}
  
/**
CActiveListener provides the asynchronous operation
of an active object
*/
class CActiveListener : public CActive
	{
public:
	static CActiveListener* NewLC();
	~CActiveListener();	

	void Initialize();
	TBool IsRequestCancelled();
	
private:
	CActiveListener();

	virtual void RunL();
	virtual void DoCancel();
	};
	
#endif //__ICLEXAMPLE_H__

