// Copyright (c) 2008-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
// iclimageprocessorexample.cpp
// The code demonstrates Caps Spmo Utility functionality
//



/**
 @file
*/

#include "iclexample.h"
#include <capsspmoutility/capsspmoutility.h>

using namespace CapsSpmoUtility;

void CIclExample::GeneratingSpmoL()
	{
	// Start new spmo optimized for QVGA screen size.
	CCapsSpmo* spmo = CapsSpmoUtility::CCapsSpmoUtility::NewSpmoL(TSize(320, 240));
	CleanupStack::PushL(spmo);

	// Generate spmo data from the input file
	spmo->SetInputL(KInputFileName);
	spmo->GenerateFromInputL();

	// Add the generated Spmo data to the output file.
	spmo->AddToFileL(KInputWithSpmoFileName);
	
	CleanupStack::PopAndDestroy(spmo);
	}

#define CHUNK_SIZE 8192 
void CIclExample::GeneratingSpmoIterativelyL()
	{
	// Start new spmo optimized for QVGA screen size.
	CCapsSpmo* spmo = CapsSpmoUtility::CCapsSpmoUtility::NewSpmoL(TSize(320, 240));
	CleanupStack::PushL(spmo);

	RFile file;
	TInt fileSize = 0;

	// Open the file for reading.
	User::LeaveIfError(file.Open(iFs, KInputFileName, EFileRead));
	CleanupClosePushL(file);

    User::LeaveIfError(file.Size(fileSize));

	// Prepare memory buffer for 8K chunk
	HBufC8* chunk = HBufC8::NewMaxL(CHUNK_SIZE);
	TPtr8 chunkPtr = chunk->Des();

	// We must reorder the cleanupstack.
	CleanupStack::Pop(); // file
    CleanupStack::PushL(chunk);
    CleanupClosePushL(file);

    if (file.SubSessionHandle())
		{
		// Begin spmo streaming
		spmo->BeginInputStreamL();

		TInt leftToRead = fileSize;
		while (leftToRead >= CHUNK_SIZE)
			{
			leftToRead -= CHUNK_SIZE;
			User::LeaveIfError(file.Read(chunkPtr, CHUNK_SIZE)); 
			spmo->ContinueInputStreamL(chunkPtr);			
			}	

		if (leftToRead != 0) 
			{
			User::LeaveIfError(file.Read(chunkPtr, leftToRead)); 
			spmo->ContinueInputStreamL(chunkPtr);
			}

		spmo->EndInputStreamL();
		}

	// Generate spmo data from the processed input stream.
	spmo->GenerateFromInputL();
	
	CleanupStack::PopAndDestroy(2); // file chunk

	// Get just generated spmo data and save it to a binary file.
	TPtr8 spmoData = spmo->BufferL();

	// Open the file for writing.
	User::LeaveIfError(file.Replace(iFs, KSpmoFileName, EFileWrite));
	CleanupClosePushL(file);

	User::LeaveIfError(file.Write(spmoData)); 
	
	CleanupStack::PopAndDestroy(2,spmo); // file spmo
	}
