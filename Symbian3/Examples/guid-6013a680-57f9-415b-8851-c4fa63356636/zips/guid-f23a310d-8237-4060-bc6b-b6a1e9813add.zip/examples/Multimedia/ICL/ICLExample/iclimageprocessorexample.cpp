// Copyright (c) 2008-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
// The code demonstrates Image Processor functionality
//



/**
 @file
*/

#include "iclexample.h"
#include <imageprocessor/imageprocessor.h>
#include <imageprocessor/imageprocessorobserver.h>
#include <imageprocessor/imageprocessorinputinfo.h>
#include <imageprocessor/imageprocessoroutputinfo.h>
#include <imageprocessor/imageprocessoroverlay.h>
#include <imageprocessor/imageprocessorpreview.h>
#include <imageprocessor/imageprocessoreffect.h>
#include <imageprocessor/imageprocessorprogressinfo.h>
#include <capsimageprocessor/capsimageprocessorextension.h>

using namespace ImageProcessor;

/**
Observer for the imageprocessor when used in asynchrionous mode. 
Callbacks give indications of progress and the success or failure of requested operations.
*/
class CImgProcessorObserverStub: public ImageProcessor::MImgProcessorObserver
	{
	public:
		CImgProcessorObserverStub(CConsoleBase& aConsole) : iConsole(aConsole), 
			iNumberOfDots(0), iCurrentIteration(0), iNumberOfIterations(0) {}

	public:
		void ImageProcessorInitializingComplete(ImageProcessor::CImgProcessor& /*aImageProcessor*/, TInt aError)
			{
			iConsole.Printf(_L("\nImageProcessorInitializingComplete, aError = %d\n"), aError);
			iCurrentIteration = 0;
			iNumberOfIterations = 0;
			iNumberOfDots = 0;
			CActiveScheduler::Stop();
			}
		
		void ImageProcessorPreviewInitializingComplete(ImageProcessor::CImgProcessor& /*aImageProcessor*/, TInt aPreviewId, TInt aError)
			{
			iConsole.Printf(_L("\nImageProcessorPreviewInitializingComplete, aPreviewId = %d, aError = %d\n"), aPreviewId, aError);
			iCurrentIteration = 0;
			iNumberOfIterations = 0;
			iNumberOfDots = 0;
			CActiveScheduler::Stop();
			}
		
		void ImageProcessingComplete(ImageProcessor::CImgProcessor& /*aImageProcessor*/, TInt aError)
			{
			iConsole.Printf(_L("\nImageProcessingComplete, aError = %d\n"), aError);
			iCurrentIteration = 0;
			iNumberOfIterations = 0;
			iNumberOfDots = 0;
			CActiveScheduler::Stop();
			}
		
		void ImageProcessorPreviewRenderingComplete(ImageProcessor::CImgProcessor& /*aImageProcessor*/, TInt aPreviewId, TInt aError)
			{
			iConsole.Printf(_L("\nImageProcessorPreviewRenderingComplete, aPreviewId=%d, aError=%d\n"), aPreviewId, aError);
			iCurrentIteration = 0;
			iNumberOfIterations = 0;
			iNumberOfDots = 0;
			CActiveScheduler::Stop();
			}
		
		void ImageProcessorEvent(ImageProcessor::CImgProcessor& aImageProcessor, TInt /*aEventId*/, TUid /*aUid*/, TInt /*aId*/)
			{
			// We try to emulate a progress bar by printing out 
			// a dot per one tenth of all iterations completed. 
			// So ten dots are printed out when the processing is finished.
			
			TProgressInfo* progressInfo = NULL;
			
			// Get TProgressInfo interface to get progress information
			TInt err = KErrNone;
			TRAP(err, progressInfo = aImageProcessor.ProgressInfoL());
			
			// Get total number of iterations for the processing/rendering
			if (iNumberOfIterations == 0) 
				{
				TRAP(err, iNumberOfIterations =  progressInfo->NumberOfIterationsL());
				}

			// Get current iteration
			TRAP(err, iCurrentIteration = progressInfo->CurrentIterationL());
			
			if (err == KErrNone) 
				{
				// Print out another dot if next one tenth is processed
				if (10 * iCurrentIteration > iNumberOfDots * iNumberOfIterations) 
					{
					iNumberOfDots++;
					iConsole.Printf(_L("."));
					}
				}

			}
	private:
		CConsoleBase& iConsole;
		TInt iNumberOfDots;
		TInt iCurrentIteration;
		TInt iNumberOfIterations;
	};

/**
Demonstrates how to scale an image and re-encode at a specific quality.
*/
void CIclExample::BasicImageProcessingL()
	{
	CImgProcessorObserverStub observer(*iConsole);
	ImageProcessor::CImgProcessor* imageProcessor = ImageProcessor::CImgProcessor::NewL(iFs, observer);
	CleanupStack::PushL(imageProcessor);
	
	// Initialize the Image Processor instance. By default the initialization is asynchronous.
	// (It might take some time to load Image Processor plugin and initialize it).
	imageProcessor->InitializeL();

	// Wait for asynchronous callback
	CActiveScheduler::Start();

	// Set input and output images
	imageProcessor->SetInputL(KInputFileName, KImageTypeJPGUid);
	imageProcessor->SetOutputL(KOutputFileName, KImageTypeJPGUid);
		
	// Get TOutputInfo interface
	TOutputInfo* outputInfo = imageProcessor->OutputInfoL();

	// Set 0.75 quality for the output image.
	// (Note. Default quality value for the output image is the same as for the input image.)
	TReal32 quality = 0.75f;
	outputInfo->SetJpegQualityL(quality);

	// Process the input image to the output image. 
	// The output image size is QVGA and the output image keeps the same aspect ratio as the input image.  
	imageProcessor->ProcessL(TSize(320, 240), ETrue);

	// Wait for asynchronous callback
	CActiveScheduler::Start();

	CleanupStack::PopAndDestroy(imageProcessor);
	}

/**
Demonstrates how to crop an image, apply effects and geometrical operations to it and re-encode
the image to a specific size and quality.
*/
void CIclExample::BasicEffectImageProcessingL()
	{
	CImgProcessorObserverStub observer(*iConsole);
	ImageProcessor::CImgProcessor* imageProcessor = ImageProcessor::CImgProcessor::NewL(iFs, observer);
	CleanupStack::PushL(imageProcessor);

	// Initialize the Image Processor instance. By default the initialization is asynchronous.
	imageProcessor->InitializeL();

	// Wait for asynchronous callback
	CActiveScheduler::Start();

	imageProcessor->SetInputL(KInputFileName, KImageTypeJPGUid);
	imageProcessor->SetOutputL(KOutputWithBasicEffectFileName, KImageTypeJPGUid);
		
	// The TOutputInfo interface is used to set quality and sampling scheme for JPEG output
	TOutputInfo* outputInfo = imageProcessor->OutputInfoL();

	// Set 0.75 quality for the output image.
	// (Note. Default quality value for the output image is the same as for the input image.)
	TReal32 quality = 0.75f;
	outputInfo->SetJpegQualityL(quality);

	// Get information about the input image
	TInputInfo* inputInfo = imageProcessor->InputInfoL();
	TSize inputSize = inputInfo->SizeL();

	// Define crop region - eighth size
	TRect cropRegion(inputSize.iWidth/4, inputSize.iHeight/4, inputSize.iWidth/2, inputSize.iHeight/2);

	// Apply crop gives a quarter size image
	imageProcessor->SetInputRectL(cropRegion);

	// Get TEffect interface for Mirror Left To Right effect. 
	// Note. All effects can be handled via generic TEffect interface. For more advanced functionality
	// the interface pointer must be cast to a derived effect interface.
	TEffect* effect = imageProcessor->EffectL(KEffectMirrorLeftToRightUid);
	
	// Standard sequence of function calls to apply the default behaviour for an effect 
	// is to simply call BeginL() and then EndL().
	effect->BeginL();
	effect->EndL();

	// Some effects do not have a default behaviour and need to use the specialized interface.
	TGeometricalOperation* operation = static_cast<TGeometricalOperation*>(imageProcessor->EffectL(KGeometricalOperationUid));
	operation->BeginL();
	operation->SetOperationL(ImageProcessor::CImgProcessor::EOperationRotate270);
	operation->EndL();

	// Process the input image to the output image. 
	// If an output size is not given then its size will be equal to the current input image after any cropping and 
	// geometrical operations are applied, so preserving the aspect ratio.
	// For this example the output size is (inputSize.iHeight/4, inputSize.iWidth/4)).   
	imageProcessor->ProcessL();

	// Wait for asynchronous callback
	CActiveScheduler::Start();

	CleanupStack::PopAndDestroy(imageProcessor);
	}

/**
Demonstrates how to use undo facility to remove effects applied to an image.
*/
void CIclExample::EffectImageProcessingWithUndoL()
	{
	CImgProcessorObserverStub observer(*iConsole);
	ImageProcessor::CImgProcessor* imageProcessor = ImageProcessor::CImgProcessor::NewL(iFs, observer);
	CleanupStack::PushL(imageProcessor);
	
	// Initialize the Image Processor instance. By default the initialization is asynchronous.
	// (It might take some time to load Image Processor plugin and initialize it).
	imageProcessor->InitializeL();

	// Wait for asynchronous callback
	CActiveScheduler::Start();

	imageProcessor->SetInputL(KInputFileName, KImageTypeJPGUid);
	imageProcessor->SetOutputL(KOutputWithUndoFileName, KImageTypeJPGUid);
		
	// The TOutputInfo interface is used to set quality and sampling scheme for JPEG output
	TOutputInfo* outputInfo = imageProcessor->OutputInfoL();

	// Set 0.75 quality for the output image.
	// (Note. Default quality value for the output image is the same as for the input image.)
	TReal32 quality = 0.75f;
	outputInfo->SetJpegQualityL(quality);

	// The rotation effect can be used via derived interface only.
	TEffectRotation* rotationEffect = static_cast<TEffectRotation*>(imageProcessor->EffectL(KEffectRotationUid));
	rotationEffect->BeginL();
	rotationEffect->SetRotationL(ImageProcessor::TEffectRotation::ERotationScaleModeFitInside, 45.0f);
	rotationEffect->EndL();

	// Check if we can undo last applied effect
	if (imageProcessor->CanUndoL()) 
		{
		// Undo the effect
		imageProcessor->UndoL();		
		}

	// Process the input image to the output image. 
	imageProcessor->ProcessL();

	// Wait for asynchronous callback
	CActiveScheduler::Start();

	// resultant image looks similar and has same image size as the input image but has some differences due to quality settings.
	CleanupStack::PopAndDestroy(imageProcessor); 
	}

/**
Demonstrates how to 'preview' a sequence of images as low quality bitmaps, applying the same set of effects to each.
*/
void CIclExample::EffectImageProcessingWithPreviewL()
	{
	CImgProcessorObserverStub observer(*iConsole);
	ImageProcessor::CImgProcessor* imageProcessor = ImageProcessor::CImgProcessor::NewL(iFs, observer);
	CleanupStack::PushL(imageProcessor);
	
	// Initialize the Image Processor instance. By default the initialization is asynchronous.
	// (It might take some time to load Image Processor plugin and initialize it).
	imageProcessor->InitializeL();

	// Wait for asynchronous callback
	CActiveScheduler::Start();

	// Initialize the list of images filenames
	const TDesC* filenames[4] = 
		{ 
		&KInputFileName01, 
		&KInputFileName02, 
		&KInputFileName03, 
		&KInputFileName04
		};

	// Initialize the list of bitmaps filenames
	const TDesC* bitmapsnames[4] = 
		{ 
		&KOutputBitmapFileName01, 
		&KOutputBitmapFileName02, 
		&KOutputBitmapFileName03, 
		&KOutputBitmapFileName04
		};
	
	// Create the output bitmap for the preview.
	// In this case the output bitmap should be considered as a offscreen buffer 
	CFbsBitmap* previewBitmap = new (ELeave) CFbsBitmap();
	previewBitmap->Create(TSize(320,240), EColor64K);

	CleanupStack::PushL(previewBitmap);

	// Define preview id for the preview
	const TInt previewId = 1;

	// Get TPreview interface using preview id
	TPreview* preview = imageProcessor->PreviewL(previewId);
	
	// Set all image processor operations including preview rendering to be synchronous.
	// The preview rendering should be reasonably quick so it is preferable to use
	// the option here and get better performance over asynchronous operations.
	// No callbacks to an observer are made in this case.
	imageProcessor->SetOptionsL(ImageProcessor::CImgProcessor::EOptionSyncProcessing);
	
	// Create a blank input and set up a chain of the effects before rendering the first preview.
	imageProcessor->CreateInputL(TSize(320, 240),  TRgb(0, 0, 0));
	
	// Initialize the preview
	preview->InitializeL();

	// Set output for the preview. 
	preview->SetOutputL(*previewBitmap);

	// Get sharpness effect
	TEffect* effect=imageProcessor->EffectL(KEffectSharpnessUid);

	// Apply default level of sharpness
	effect->BeginL();
	effect->EndL();

	// Get color boost effect
	effect = imageProcessor->EffectL(KEffectColorBoostUid);

	// Apply default level of color boost
	effect->BeginL();
	effect->EndL();

	// Get white balance effect
	effect = imageProcessor->EffectL(KEffectWhiteBalanceUid);
	
	// Apply default white balance 
	effect->BeginL();
	effect->EndL();

	// Go through the images and render the preview for each of them
	for (TInt i = 0; i < 4; i++) 
		{
		imageProcessor->SetInputL(*filenames[i]);
		preview->RenderL();		

		// Here a code to update the screen using the preview bitmap can be placed
		// In our case we just save the bitmap.
		previewBitmap->Save(*bitmapsnames[i]);
		}

	CleanupStack::PopAndDestroy(2,imageProcessor); //previewBitmap imageProcessor
	}

/**
Demonstrates overlay of a PNG image on a JPEG and how that overlay can be resized and
repositioned through a preview prior to being re-encoded to image file on disk.
*/
void CIclExample::EffectImageProcessingWithOverlayL()
	{
	CImgProcessorObserverStub observer(*iConsole);
	ImageProcessor::CImgProcessor* imageProcessor = ImageProcessor::CImgProcessor::NewL(iFs, observer);
	CleanupStack::PushL(imageProcessor);
	
	// Initialize the Image Processor instance. By default the initialization is asynchronous.
	// (It might take some time to load Image Processor plugin and initialize it).
	imageProcessor->InitializeL();

	// Wait for asynchronous callback
	CActiveScheduler::Start();

	// Set input and output files 
	imageProcessor->SetInputL(KInputFileName, KImageTypeJPGUid);
	imageProcessor->SetOutputL(KOutputWithOverlayFileName, KImageTypeJPGUid);

	// Create the output bitmap for the preview.
	CFbsBitmap* previewBitmap = new (ELeave) CFbsBitmap();
	previewBitmap->Create(TSize(320,240), EColor64K);

	CleanupStack::PushL(previewBitmap);

	// Define preview id for the preview
	const TInt previewId = 1;

	// Get TPreview interface using preview id
	TPreview* preview = imageProcessor->PreviewL(previewId); 
	
	// Set all image processor operation like preview rendering to be synchronous
	// The preview rendering should be reasonably quick so it is preferable to use
	// the option here.
	imageProcessor->SetOptionsL(ImageProcessor::CImgProcessor::EOptionSyncProcessing);
	
	// Initialize the preview
	preview->InitializeL();
	
	// Set output for the preview. 
	preview->SetOutputL(*previewBitmap);

	// we can check what this looks like by rendering to the preview
	preview->RenderL();

	TPoint overlayPosition(0,0);

	// Get preview canvas rectangle 
	TRect canvasArea = preview->CanvasAreaL();
        
	// Set overlay position to the center of the preview canvas area 	
	overlayPosition.iX = (canvasArea.iBr.iX - canvasArea.iTl.iX) / 2;
	overlayPosition.iY = (canvasArea.iBr.iY - canvasArea.iTl.iY) / 2;
	
	// Convert the preview canvas coordinates to the input current coordinates  
	TPoint tmp(0, 0);
	preview->CanvasToCurrentCoordL(overlayPosition, tmp);
	overlayPosition = tmp;
	 
	// Get TOverlay interface
	TOverlay* overlay = imageProcessor->OverlayL();
	
	// Begin the overlay with a overlay file
	overlay->SetInputL(KInputOverlayFileName, KImageTypePNGUid);
	overlay->BeginL();

	// Set overlay with 1.0 x/y scale (un-scaled), position at the center of the preview canvas, 0.0 angle (no rotation)
	overlay->SetL(1.0f, 1.0f, overlayPosition, 0.0f);

	// we can check what this looks like by rendering to the preview
	preview->RenderL();
	// save the content of the preview bitmap to check the result
	previewBitmap->Save(KOutputBitmapFileName01);

	// We can then double the size of the overlaid, rotate it 45 degrees clockwise 
	// and move it down ten screen pixels.

	// Double the size of the overlay 
	TReal32 overlayScaleX = 0.0f;
	TReal32 overlayScaleY = 0.0f;
	overlay->GetScaleL(overlayScaleX, overlayScaleY);

	overlayScaleX *= 2.0f;
	overlayScaleY *= 2.0f;

	TReal32 overlayAngle = overlay->AngleL();

	// Rotate the overlay 45 degrees 
	overlayAngle += 45.0f;
	if (overlayAngle >= 360.0f)
		{
		overlayAngle = overlayAngle - 360.0f;
		}

	// Move down the position of the overlay 10 screen pixels
	overlayPosition = overlay->PositionL();
	overlayPosition.iY += 10;

	// Set overlay with new parameters
	overlay->SetL(overlayScaleX, overlayScaleY, overlayPosition, overlayAngle);

	// Apply overlay parameters and finish with overlay
	overlay->EndL();

	preview->RenderL();

	//save the content of the preview bitmap to check the result
	previewBitmap->Save(KOutputBitmapFileName02);

	// Restore default asyncronous processing
	imageProcessor->SetOptionsL(imageProcessor->Options() ^ ImageProcessor::CImgProcessor::EOptionSyncProcessing);
	
	// Process the input image to the output image. 
	imageProcessor->ProcessL();

	// Wait for asynchronous callback
	CActiveScheduler::Start();
	
	CleanupStack::PopAndDestroy(2,imageProcessor); //previewBitmap imageProcessor
	}
	
/**
Demonstrates how to add a SpeedView object to an image which has been processed and is 
being re-encoded. This gives the benefit that the output image can be previewed quickly at 
some point in the future.
This also demonstrates the transfer of EXIF headers and the regeneration of the thumbnail to match the main image.
*/
void CIclExample::ImageProcessingWithSpmoL()
	{
	CImgProcessorObserverStub observer(*iConsole);
	ImageProcessor::CImgProcessor* imageProcessor = ImageProcessor::CImgProcessor::NewL(iFs, observer);
	CleanupStack::PushL(imageProcessor);
	
	// Initialize the Image Processor instance. By default the initialization is asynchronous.
	// (It might take some time to load Image Processor plugin and initialize it).
	imageProcessor->InitializeL();

	// Wait for asynchronous callback
	CActiveScheduler::Start();

	// Set input image. This one does not have Spmo, but it could have.
	imageProcessor->SetInputL(KInputFileName, KImageTypeJPGUid);
	imageProcessor->SetOutputL(KOutputWithSpmoFileName, KImageTypeJPGUid);

	// transfer exif from the input (this is not mandatory)
	imageProcessor->SetOptionsL(ImageProcessor::CImgProcessor::EOptionExifMetadataProcessing);

	// To access Spmo functionality it is necessary to get Caps image processor extension interface @publishedpartner.
	TCapsImageProcessorExtension* extension = static_cast<TCapsImageProcessorExtension*>(imageProcessor->Extension(KCapsImageProcessorExtensionUid));

	// Set add Spmo to the output. The Spmo will be optimized for preview at QVGA screen size.
	// The code below will be commented in when DTW-MM00213 is fixed
    extension->SetAddSpmoToOutputL(ETrue, TSize(320, 240));

	// it is not possible to apply effects AND set Speedview object to the output
	
	// Process the input image to the output image. 
	imageProcessor->ProcessL();

	// Wait for asynchronous callback
	CActiveScheduler::Start();

	CleanupStack::PopAndDestroy(imageProcessor); 	
	}

