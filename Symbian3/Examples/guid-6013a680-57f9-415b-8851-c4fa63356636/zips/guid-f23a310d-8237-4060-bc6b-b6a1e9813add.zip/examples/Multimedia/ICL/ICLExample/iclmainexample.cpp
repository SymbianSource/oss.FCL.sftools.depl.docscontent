// iclmainexample.cpp
//
// // Copyright (c) 2008-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
// 
//

/**
@file
This example program demonstrates the usage of the CIclExample and CActiveListener classes.
It defines E32Main() which internally calls the  MainL() function for calling all the
functions of the CIclExample class.
*/
#include "iclexample.h"
#include <f32file.h>

/**
CActiveListener factory function
@return A CActiveListener object
*/
CActiveListener* CActiveListener::NewLC()
	{
    CActiveListener* self = new(ELeave) CActiveListener();
	CleanupStack::PushL(self);
	return self;
	}

/**
Constructor for class CActiveListener
*/
CActiveListener::CActiveListener() : CActive(EPriorityLow)
	{
 	CActiveScheduler::Add(this);
	}

/**
Destructor
*/
CActiveListener::~CActiveListener()
	{
	}

/**
Handles the request.
This function is derived from CActive
*/
void CActiveListener::RunL()
	{
	CActiveScheduler::Stop();
	}

/**
Cancels the outstanding request.
This function is derived from CActive
*/
void CActiveListener::DoCancel()
	{
	}

/**
Initializes the CActiveListener
*/
void CActiveListener::Initialize()
	{
	iStatus = KRequestPending;
	SetActive();
	}

/**
Check that the request has been cancelled.
@return A boolean indicating whether the request has been cancelled or not
*/
TBool CActiveListener::IsRequestCancelled()
	{
	return (iStatus == KErrCancel);
	}



/**
Instance a CIclExample object and push it on the cleanup stack.
Initializes all member data to their default values.
@return A CIclExample object
*/
CIclExample* CIclExample::NewLC()
 	{
	CIclExample* self = new(ELeave) CIclExample();
	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
	}

/**
Constructor
*/
CIclExample::CIclExample()
	{
	}

void CIclExample::ConstructL()
	{
	User::LeaveIfError(iFs.Connect());
	User::LeaveIfError(RFbsSession::Connect());
	}

/**
Destructor
*/
CIclExample::~CIclExample()
	{
	RFbsSession::Disconnect();
	iFs.Close();

	// Close REComSession
	REComSession::FinalClose();
	}


/**
Opens file and creates file pointer
@param aFileName The specified file to open
@return imageInMemoryPtr A Pointer to iImageInMemory
@leave System-wide error codes
*/
TPtr8 CIclExample::LoadImageIntoMemoryLC(const TDesC& aFileName)
	{
    RFile file;
	TInt fileSize = 0;

    // Open the file for decoding.
 	User::LeaveIfError(file.Open(iFs, aFileName, EFileRead));
 	CleanupClosePushL(file);
	User::LeaveIfError(file.Size(fileSize));

	HBufC8* imageInMemory = HBufC8::NewMaxL(fileSize);
	TPtr8 imageInMemoryPtr = imageInMemory->Des();

	// We must reorder the cleanupstack.
	CleanupStack::Pop(); // file
	CleanupStack::PushL(imageInMemory); // imageInMemory
	CleanupClosePushL(file);

	if (file.SubSessionHandle())
		{
		User::LeaveIfError(file.Read(imageInMemoryPtr));
		}

	CleanupStack::PopAndDestroy(); // file
	return imageInMemoryPtr;
	}


/**
Creates and Initializes a CActiveListener object.
@return A CActiveListener object
*/
CActiveListener* CIclExample::CreateAndInitializeActiveListenerLC()
	{
	// Create an active Listener and push it on the cleanup stack
	CActiveListener* activeListener = CActiveListener::NewLC();
	activeListener->Initialize();
	return activeListener;
	}


LOCAL_C void MainL()
	{
	// Create a CConsoleBase to define console interface
	CConsoleBase* gConsole = Console::NewL(KTitle, TSize(KConsFullScreen, KConsFullScreen));
	CleanupStack::PushL(gConsole);

	// Create an active scheduler to handle asychronous calls
	CActiveScheduler* scheduler = new(ELeave) CActiveScheduler();
	CleanupStack::PushL(scheduler);
	CActiveScheduler::Install(scheduler);

	CIclExample* app = CIclExample::NewLC();
	app->SetConsole(gConsole);

	gConsole->Printf(KWelcomeMessage);
	gConsole->Printf(KPressAKeyMsg);
	gConsole->Getch();

	//Panorama Stitching
	gConsole->Printf(KPanoramaStitching);
	
	//Stitch images already captured to form a panorama
	_LIT(KPath,"z:\\resource\\plugins\\");
	_LIT(KFile,"panoramaplugin.rsc");
	
    /*
    Check for the availability of the panorama plugin. If it is not available, skip the code that uses it.
	*/
	RFs fsSession;// Connect session
	User::LeaveIfError(fsSession.Connect());
	
	TFindFile file(fsSession);
	TInt panoramaPluginSupport;
	panoramaPluginSupport = file.FindByPath(KFile(),&KPath());
	
	if(panoramaPluginSupport == KErrNone)
		{
		app->BasicPanoramaStitchingL();
		gConsole->Printf(KBPStitching);
	    //Stitch images together to form a panorama based on viewfinder tracking
		app->ViewFinderImageTrackingL();
		gConsole->Printf(KVFTStitching);
		}
	
	gConsole->Printf(KPressAKey);
	gConsole->Getch();

	/*
	Various Decode functions
	*/
	gConsole->Printf(KDecode);

	// Decode descriptor to bitmap
	app->DecodeFromDescriptorToBitmapL(KBitmapFile);
	gConsole->Printf(KDecodeFromDescriptorToBitmap);

	// Decode from image file to bitmap
	app->DecodeFromFileToBitmapL(KBitmapFile);
	gConsole->Printf(KDecodeFromDescriptorAndFile, &KBitmapFile);

	// Decode to image frame YUV
	app->DecodeToYuvFrameL(KYuvBitmap);
	gConsole->Printf(KDecodeToYuv, &KYuvBitmap);

	// Decode to �, � and 1/8 sized bitmaps
	app->DecodeToHalfFourthAndEighthSizedBitmapL(KBitmapFile);
	gConsole->Printf(KDecodeToHalfFourthAndEighthSizedBmp, &KBitmapFile);

	// Decode using image mask
	app->DecodeUsingImageMaskL(KMultiFrameClock);
	gConsole->Printf(KDecodeUsingImageMask);

	// Multi-frame Image Decode
	app->MultiFrameImageDecodeL(KMultiFrameClock);
	gConsole->Printf(KImageMaskAndMultiFrameImageDecode, &KMultiFrameClock);

    // Decode using separate thread
	app->DecodeUsingSepThreadL(KBitmapFile);
	gConsole->Printf(KDecodeUsingSepThread);

	// Decode using continue convert
	app->DecodeUsingContinueConvertL(KBitmapFile);
	gConsole->Printf(KSeparateThreadAndCancelAndContinueConvert, &KBitmapFile);

	// JPEG thumbnail access
	app->AccessThumbnailToDecodeL(KThumbFile);
	gConsole->Printf(KAccessThumbnailToDecode);

	// Access Exif metadata
	app->AccessExifMetadataL(KBitmapExif);
	gConsole->Printf(KAccessExifMetadata);

	// Decode the thumbnail part of the image
	app->DecodeTheThumbnailL(KThumbFile);
	gConsole->Printf(KAccessExifThumbnailAndDecodeThumbnail, &KThumbFile);

	// Decode and display image comments
	app->DisplayingImageCommentsL(KBitmapComment);
	gConsole->Printf(KDisplayingImageComments);

	// Decode and display frame comments
	app->DisplayingFrameCommentsL(KBitmapFrameComment);
	gConsole->Printf(KImageAndFrameComment);

	// Get the MIME type of a source image descriptor, and load a decoder using a MIME type
	app->GettingMimeTypeOfSourceDescriptorL(KBitmapFile);
	gConsole->Printf(KGettingMimeTypeOfSourceDescriptor);

	// Get the MIME type of a source image file, and load a decoder using a MIME type
	app->GettingMimeTypeOfSourceFileL(KBitmapFile);
	gConsole->Printf(KGettingMimeTypeFromSourceAndFile, &KBitmapFile);

	// Decode Bitmap including rotating an image
	app->DecodeWithRotateL(KBitmapFile);
	gConsole->Printf(KFileRotateAfterDecode, &KBitmapFile);

	// Load a Plugin by specific UID
	app->LoadPluginByUidL(KBitmapExif, KImageTypeJPGUid);
	gConsole->Printf(KPluginLoadedSpecificToUID);
	
	// Stream Decode and stream encode YUV image frame 
	app->BlockStreamDecodeAndEncodeYuvFrameL(KYuvBitmap, KDestStreamFile);
	gConsole->Printf(KStreamYuv, &KYuvBitmap);

	// Apply clipping, scaling and rotation during image decode.
	app->ClipAndRotateDuringDecodeL();	   

	gConsole->Printf(KPressAKey);
	gConsole->Getch();


	/*
	various encode functions
	*/
	gConsole->Printf(KEncode);

	// Encode image frame (YUV) to descriptor
	app->EncodeBitmapToDescriptorL(KSourceBitmap);
	gConsole->Printf(KFileEncode, &KSourceBitmap);

	// JPEG thumbnail access
	app->EncodeImageWithThumbnailL(KSourceBitmap);
	gConsole->Printf(KEncodeImageWithThumbnail);

	// Setting EXIF metadata
	app->SettingExifMetadataL(KSourceBitmap);
	gConsole->Printf(KAccessToThumbnailAndExifSetting);

	// Rotating a bitmap
	app->RotateBitmapL(KSourceBitmap);
	gConsole->Printf(KFileRotate);

	// Scaling a bitmap (including optional selection of low memory and quality algorithms)
	app->ScaleBitmapL(KSourceBitmap);
	gConsole->Printf(KScaleBitmap);

	// Set Source to File and destination to descriptor and resize
	app->SetSourceDestinationandResizeL(KBitmapExif);
	gConsole->Printf(KSetSourceDestinationandResize);

	// Set Source to descriptor and destination to File and resize
	app->SettingWithUseOfPreserveImageDataL(KYuvBitmap,KYuvDestBitmap);
	gConsole->Printf(KSetSourceAndDestinationAndResize);

	// Adding thumbnail to JPEG file
	app->AddThumbnailToJpegFileL(KBitmapExif, KYuvDestBitmap);
	gConsole->Printf(KAddThumbnailToJpegFile);

	// Adding Exif data to JPEG file
	app->AddExifDataToJpegFileL(KSourceBitmap);
	gConsole->Printf(KExifAndThumbnailAdded);

	// Apply rotation operation while encoding bitmap to Jpeg
	app->EncodeBitmapToFileUsingOperationExtensionL(KBitmapRotateWhileEncodeToJpeg, KDestRotateFile);
	gConsole->Printf(KEncodeRotate, &KDestRotateFile);
	
	gConsole->Printf(KPressAKey);
	gConsole->Getch();
	
	// Spmo
	// Generating Spmo
	gConsole->Printf(KGeneratingSpmo);
	app->GeneratingSpmoL();

	// Generating Spmo iteratively
	gConsole->Printf(KGeneratingSpmoIteratively);
	app->GeneratingSpmoIterativelyL();

	gConsole->Printf(KPressAKey);
	gConsole->Getch();
	
	// Image Processor
	// Basic image processing
	_LIT(KFile1,"capsimageprocessorplugin.rsc");
	TInt imageProcessorPluginSupport;
	imageProcessorPluginSupport = file.FindByPath(KFile1(),&KPath());
	if(imageProcessorPluginSupport == KErrNone)
		{
		gConsole->Printf(KBasicImageProcessing);
		app->BasicImageProcessingL();
		// Basic image processing with effects applied
		gConsole->Printf(KBasicEffectImageProcessing);
		app->BasicEffectImageProcessingL();
	    // Image processing with undo
		gConsole->Printf(KEffectImageProcessingWithUndo);
		app->EffectImageProcessingWithUndoL();
		// Image processing with preview
		gConsole->Printf(KEffectImageProcessingWithPreview);
		app->EffectImageProcessingWithPreviewL();
		// Image processing with overlay
		gConsole->Printf(KEffectImageProcessingWithOverlay);
		app->EffectImageProcessingWithOverlayL();
		// Image processing with spmo
		gConsole->Printf(KImageProcessingWithSpmo);
		app->ImageProcessingWithSpmoL();
		}
	
	// Various Image Transform Functions
	gConsole->Printf(KImageTransform);
	// Squeeze a Jpg Image in a file to a file
	_LIT(KFile2,"capsimagetransformplugin.rsc");
	TInt imageTransformPluginSupport;
	imageTransformPluginSupport = file.FindByPath(KFile2(),&KPath());
	if(imageTransformPluginSupport == KErrNone)
		{
		gConsole->Printf(KSqueezeFileToFile);
		app->SqueezeJpgFileToFileL(KSourceJpgDatetree, KSqueezeDestJpgDatetreeFileToFile);
		// Squeeze a Jpg Image in a buffer to a buffer
		gConsole->Printf(KSqueezeBufferToBuffer);
		app->SqueezeJpgBufferToBufferL(KSourceJpgDatetree, KSqueezeDestJpgDatetreeBufferToBuffer);
		// Auto-Squeeze a Jpg Image in a file to a file
		gConsole->Printf(KAutoSqueezeFileToFile);
		app->AutoSqueezeJpgFileToFileL(KSourceJpgCapstest, KAutoSqueezeDestJpgCapstest);
		// Rotate a Jpg Image in a file to a file
		gConsole->Printf(KRotateFileToFile);
		app->RotateJpgFileToFileL(KSourceJpgCapstest, KRotate90DestJpgCapstest);
		// Overlay a Jpg Image in a buffer to a file to a file
		gConsole->Printf(KOverlayJpgDataFileToFile);
		app->OverlayJpgDataToJpgFileToFileL(KSourceJpgDatetree, KSourceJpgOverlay, KOverlayDestJpgDataFileToFile);
		// Overlay a Bitmap in a buffer to a file to a file
		gConsole->Printf(KOverlayBmpDataFileToFile);
		app->OverlayBmpDataToJpgFileToFileL(KSourceJpgCapstest, KSourceMbmOverlay, KOverlayDestBitmapFileToFile);
		// Overlay a Png Image in a file to a file to a file
		gConsole->Printf(KOverlayPngFileToFile);
		app->OverlayPngFileToJpgFileToFileL(KSourceJpgCapstest, KSourcePngOverlay, KOverlayDestPngFileToFile);
		}
	gConsole->Printf(KExitMsg);
	gConsole->Getch();
	fsSession.Close();
	CleanupStack::PopAndDestroy(3);// app, scheduler, gConsole
	}


GLDEF_C TInt E32Main()
	{
	__UHEAP_MARK;

	CTrapCleanup* cleanup = CTrapCleanup::New();
	if (cleanup == NULL)
		{
		return KErrNoMemory;
		}

	TRAPD(err, MainL());

	delete cleanup;
	__UHEAP_MARKEND;

	return err;
	}
