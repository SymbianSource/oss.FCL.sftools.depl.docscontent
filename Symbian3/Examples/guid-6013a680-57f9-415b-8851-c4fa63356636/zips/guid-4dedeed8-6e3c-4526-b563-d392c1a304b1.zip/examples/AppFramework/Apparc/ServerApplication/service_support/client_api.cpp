// Copyright (c) 2006-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//

#include "client_api.h"
#include "definitions.h"

// Constructor
EXPORT_C RServAppService::RServAppService()
{
}

// Sends a request for service to the server side.
// The message input parameter (contained in a descriptor)
// is wrapped into a TIpcArgs type message.		
EXPORT_C TInt RServAppService::Send(const TDesC & aMessage)
{
	return SendReceive(EServAppServExample,TIpcArgs(&aMessage));
}

// Returns the UID of the service the client has requested
TUid RServAppService::ServiceUid() const
{	
	return KServiceType;
}
