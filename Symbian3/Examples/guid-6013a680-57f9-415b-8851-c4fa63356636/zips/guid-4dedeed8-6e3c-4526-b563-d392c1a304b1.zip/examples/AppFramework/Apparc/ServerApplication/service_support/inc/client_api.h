// Copyright (c) 2006-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//

#ifndef __CLIENT_API_H
#define __CLIENT_API_H

//CLASS DECLARATION

#include <eikserverapp.h>


//RServAppService declaration

class RServAppService : public REikAppServiceBase /*derives from RApaAppServiceBase */
	{
	public:
		IMPORT_C RServAppService();
		
		IMPORT_C TInt Send(const TDesC & aMessage);  // simple method that poses a request to server
	private:
		TUid ServiceUid() const;
	};
	
#endif  //__CLIENT_API_H
