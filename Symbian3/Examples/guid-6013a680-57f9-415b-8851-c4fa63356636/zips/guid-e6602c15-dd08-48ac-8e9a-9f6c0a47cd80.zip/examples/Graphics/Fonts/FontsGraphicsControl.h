// Copyright (c) 2000-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//

#ifndef __FontsGraphicsControl_H
#define __FontsGraphicsControl_H

#include <coecntrl.h>
#include <s32file.h>
#include "CommonGraphicsControlFramework.h"

// sundry derived classes

class CHelloControl : public CGraphicExampleControl
	{
public:
	CHelloControl() { SetMaxPhases(7); };
	void UpdateModelL();
	void Draw(const TRect& aRect) const;
	};

class CFontControl : public CGraphicExampleControl
	{
public:
	CFontControl();
	~CFontControl() { };
	void UpdateModelL();
	void Draw(const TRect& aRect) const;
private:
	MGraphicsDeviceMap* iDeviceMap;
	TZoomFactor iZoomFactor;
	TInt iNumTypefaces;
	TBuf<19> iCurrentFont;
	};

#endif
