// libmexample.c
//
// Copyright (c) 2008-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//


//This example demonstrates the use of math library functions.
//In particular, the use of the gamma(double) function.

// Include files.
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

/**
Waits for a key press.
*/
void PressKey()
	{
	fflush(stdout);
	getchar();
	}
/**
Main function.
Displays the gamma of the value specified by the user.
*/
int main()
	{
	double inputValue = 0.0;
	double gammaValue = 0.0;

	printf("Welcome to the libm example!!!\n");
	printf("This example demonstrates the use of the gamma function from the math library.");

	printf("\n\nEnter an input value for the gamma function:");
	// Read input value for gamma function.
	scanf("%lf",&inputValue);
	//Call gamma function on read value.
	gammaValue = gamma(inputValue);
	printf("\nThe gamma of %lf is %lf\n",inputValue,gammaValue);
	PressKey();
	printf("\n Press Enter key to exit");
	PressKey();

   	return EXIT_SUCCESS;// Returns the success code.
	}
