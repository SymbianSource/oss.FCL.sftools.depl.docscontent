// Copyright (c) 2005-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//

#if (!defined __CONTACTVIEWS_H__)
#define __CONTACTVIEWS_H__

#include <cntdb.h>
#include <cntview.h>
#include <cntviewbase.h>


// CExampleViews is an active object and a contact view observer.
class CExampleViews : public CActive , public MContactViewObserver
	{
public:
	static CExampleViews* NewL(CContactDatabase& aDb);
	~CExampleViews();
	void Start();

private:
	CExampleViews(CContactDatabase& aDb);
	void ConstructL();

	// CActive implementation
	void RunL();
	void DoCancel();

	// MContactViewObserver implementation
	virtual void HandleContactViewEvent(const CContactViewBase& aView, const TContactViewEvent& aEvent);

	CContactFindView* CreateFindViewL();
	void HandleViewEventL(const CContactViewBase& aView);

private:
    // Pointer to the contact database
	CContactDatabase& iDb;
	// Fields to use in the views
	RContactViewSortOrder iSortOrder;
	// Pointer to the local view
	CContactLocalView* iLocalView;
	// Pointer to the find view 
	CContactFindView* iFindView;
	// Pointer to the filter view
	CContactFilteredView* iFilterView;
	// Used to test the number of views created
	TInt iNumViewsCreated;
	};


#endif // __CONTACTVIEWS_H__
