// Copyright (c) 2007-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//

#include <e32std.h>
#include <e32cons.h>
 

void SimpleL()
{  
  CActiveScheduler* scheduler = new CActiveScheduler;
  CActiveScheduler::Install(scheduler);
  CConsoleBase* theConsole = Console::NewL(_L("Dummy app"),TSize(KConsFullScreen,KConsFullScreen));
  CleanupStack::PushL(theConsole);
  theConsole->Printf(_L("---System Startup---\n"));
  theConsole->Printf(_L("---Dummy exe -------\n"));
  theConsole->Printf(_L("---Exiting now------\n"));
  CleanupStack::PopAndDestroy(theConsole);
  delete scheduler;
}

GLDEF_C TInt E32Main()
	{
	CTrapCleanup* cleanupStack=CTrapCleanup::New();
	TRAPD(err,SimpleL());
		_LIT(KTxtEGSYSSTART,"EGSYSSTART");
		__ASSERT_ALWAYS(!err,User::Panic(KTxtEGSYSSTART,err));
	delete cleanupStack;
	return KErrNone;
	}
