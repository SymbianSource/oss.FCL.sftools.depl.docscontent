// Copyright (c) 2001-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//

#ifndef CMEDIACLIENTDOCUMENT
#define CMEDIACLIENTDOCUMENT

#include <eikdoc.h>

#include "CMediaClientEngine.h"

/** Simple document class to own the engine */
class CMediaClientDocument : public CEikDocument
    {
public:
    // construct/destruct
/**
Allocates and constructs a new document.
* Construction and destruction
@return New document object
@param aApp Application
*/
	static CMediaClientDocument* NewL(CEikApplication& aApp);
/**
Destructor.
* Construction and destruction
*/
~CMediaClientDocument();


/**
Gets the application engine.

@return The application engine
*/
	CMediaClientEngine& Engine();

private:
/**
Constructor.
* Construction and destruction
@param aApp Application
*/
	CMediaClientDocument(CEikApplication& aApp);
/**
Second phase constructor.
* Construction and destruction
*/	void ConstructL();


/**
Creates an app UI.
From <code>CEikDocument</code>.
@return A new <code>CMediaClientAppUI</code> object
*/
	CEikAppUi*  CreateAppUiL();

private: 
	/** The application engine */
	CMediaClientEngine* iEngine; 
    };

#endif // CMEDIACLIENTDOCUMENT
