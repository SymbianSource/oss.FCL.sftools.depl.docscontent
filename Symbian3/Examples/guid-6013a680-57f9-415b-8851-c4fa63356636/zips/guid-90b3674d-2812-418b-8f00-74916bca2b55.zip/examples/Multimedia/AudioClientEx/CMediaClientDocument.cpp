// Copyright (c) 2001-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//

#include "CMediaClientDocument.h"
#include "CMediaClientAppUI.h"
#include "CMediaClientEngine.h"

#include <eikenv.h>
#include <eikproc.h>

// The document's only job is to own the engine

CMediaClientDocument* CMediaClientDocument::NewL(CEikApplication& aApp)
	{
	CMediaClientDocument* self=new (ELeave) CMediaClientDocument(aApp);
	CleanupStack::PushL(self);
	self->ConstructL();
	CleanupStack::Pop();
	return self;
	}

CMediaClientDocument::CMediaClientDocument(CEikApplication& aApp)
: CEikDocument(aApp)
    {
    }

void CMediaClientDocument::ConstructL()
	{
	iEngine = new (ELeave) CMediaClientEngine(CEikonEnv::Static()->FsSession());
	}

CMediaClientDocument::~CMediaClientDocument()
    {
	delete iEngine;
    }

CMediaClientEngine& CMediaClientDocument::Engine()
	{
	return *iEngine;
	}

//
// CreateAppUiL
//
// Called by the framework to get our AppUi object
CEikAppUi* CMediaClientDocument::CreateAppUiL() 
    {
    return new (ELeave) CMediaClientAppUi;
    }


