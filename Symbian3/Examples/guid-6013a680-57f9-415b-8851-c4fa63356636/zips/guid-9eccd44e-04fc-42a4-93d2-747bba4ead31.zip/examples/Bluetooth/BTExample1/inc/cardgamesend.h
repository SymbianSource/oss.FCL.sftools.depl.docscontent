// Copyright (c) 2006-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//

#ifndef CARDGAMESEND_H
#define CARDGAMESEND_H

#include <e32base.h>
#include <in_sock.h>

class CCardGameBase;

/**
 * CCardGameSend is an active object that has a reference to the RSocket of the network.
 * It calls SendTo on the socket and then calls back to the CCardGameBase object when 
 * the send has completed
 */
class CCardGameSend : public CActive
	{
public:
	static CCardGameSend* NewL(CCardGameBase& aParent, RSocket& aSocket);
	~CCardGameSend();
	void DoCancel();
	void RunL();
	void SendTo(TDesC8& aDes, TInetAddr aAddr);
	
private:
	CCardGameSend(CCardGameBase& aParent, RSocket& aSocket);

private:
	CCardGameBase& iParent;
	RSocket& iSocket;
	
	};
	
#endif // CARDGAMESEND_H
