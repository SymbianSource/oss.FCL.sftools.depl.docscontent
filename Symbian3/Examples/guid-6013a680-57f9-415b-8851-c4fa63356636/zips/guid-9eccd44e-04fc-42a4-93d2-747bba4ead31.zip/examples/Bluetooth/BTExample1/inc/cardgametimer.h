// Copyright (c) 2006-2009 Nokia Corporation and/or its subsidiary(-ies).
// All rights reserved.
// This component and the accompanying materials are made available
// under the terms of "Eclipse Public License v1.0"
// which accompanies this distribution, and is available
// at the URL "http://www.eclipse.org/legal/epl-v10.html".
//
// Initial Contributors:
// Nokia Corporation - initial contribution.
//
// Contributors:
//
// Description:
//

#ifndef CARDGAMETIMER_H
#define CARDGAMETIMER_H

#include <e32base.h> 

/**
 * CCardGameTimer is an active object that derives from CTimer. It acts as
 * a timer for events on the socket.
 */
class CCardGameBase;

class CCardGameTimer : public CTimer
	{
public:
	static CCardGameTimer* NewL(CCardGameBase& aParent);
	~CCardGameTimer();
	void RunL();
	void StartTimer(TInt aDuration);
	
private:
	CCardGameTimer(CCardGameBase& aParent);
	void ConstructL();

private:
	CCardGameBase& iParent;
	
	};
	
#endif // CARDGAMETIMER_H
